# WAVE_2_HOTFIX_8.2.7

> نسخه: 8.2.7  
> هدف: رفع دو ریشه‌ی اصلیِ ناهماهنگی در Wave 2

---

# مشکل‌های اصلی که پیدا شدند

## 1) عدد تسویه کارشناسان بیش از واقعیت بود

### علت
در flowهای ERP این اتفاق می‌افتاد:
- `do_action('cptt_after_expert_payout', ...)`
- و بعد دوباره یک `ledger_insert()` دیگر

یعنی یک تسویه واقعی، دو بار در `cptt_fin_ledger` نوشته می‌شد.

همین باعث می‌شد:
- dashboard
- summaries
- و بعضی backfillها

عدد بزرگ‌تر از واقعیت نشان دهند.

---

## 2) هزینه‌ی settlementهای تاریخی در P&L صفر می‌ماند

### علت
بعضی voucherهای historical backfill برای settlementهای کارشناس به‌اشتباه این‌طور ساخته شده بودند:
- بدهکار روی `expert_payable`
- بستانکار روی bank

این باعث می‌شد در صورت سود و زیان، هزینه واقعی وارد گروه هزینه نشود.

---

# اصلاح‌های انجام‌شده

## اصلاح 1 — حذف duplicate legacy write
در این دو مسیر:
- `ajax_settle_steps()`
- `ajax_settle_manual()`

نوشتن تکراری در `fin_ledger` حذف شد.

### rule جدید
همان hook رسمی legacy-compatibility writer کافی است و write دوم نباید انجام شود.

---

## اصلاح 2 — repair settlement voucherهای historical
voucherهای backfill شده‌ی historical settlement که از source:
- `legacy_core_ledger`
- با `ref_type = erp_settle`

بودند، repair می‌شوند تا:
- debit روی `expert_payroll`
- credit روی `bank_default`

باشد.

### نتیجه
هزینه settlement باید در statement chain بهتر دیده شود.

---

## اصلاح 3 — expert payout KPI بر اساس actual settlement total
کارت `تسویه کارشناسان` حالا از total واقعی settlementها نزدیک‌تر تغذیه می‌شود، نه از جمعِ inflated شده‌ی بعضی pathهای voucher/ledger تکراری.

---

# نکته مهم درباره صورت سود و زیان

طبق تصمیم ثبت‌شده:
- P&L استاندارد باقی می‌ماند
- cash-view / دریافتی واقعی جداست

پس:
- اگر P&L مبلغ شناسایی‌شده را نشان دهد، در این hotfix باگ محسوب نمی‌شود
- اما هزینه settlementهای کارشناس باید دیگر بهتر وارد expense chain شوند

---

# بعد از نصب 8.2.7 چه چیزهایی را تست کن؟

1. کارت `تسویه کارشناسان` در dashboard
2. صفحه `تسویه کارشناسان`
3. `صورت سود و زیان` برای هزینه‌های کارشناس
4. `مطالبات مشتریان` و `خزانه` برای اینکه چیزی دوباره به هم نریخته باشد

---

**پایان hotfix 8.2.7**
