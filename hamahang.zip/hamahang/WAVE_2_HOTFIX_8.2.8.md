# WAVE_2_HOTFIX_8.2.8

> نسخه: 8.2.8  
> نوع: hotfix Wave 2 برای مشکل چندکارشناس و جمع‌های settlement

---

# مشکل چه بود؟

از تست تو معلوم شد:
- وقتی یک مرحله چند کارشناس دارد، مبلغ همان مرحله ممکن بود برای هر کارشناس کامل تکرار شود
- در نتیجه جمع `تسویه کارشناسان` بیشتر از واقعیت می‌شد
- و pending settlement / expert balances هم باد می‌کردند

مثال تو:
- باید 13 میلیون می‌شد
- ولی 14 میلیون نشان داده می‌شد

---

# علت فنی

در بعضی summaryها و لیست‌ها، سیستم برای stepهای multi-expert:
- `expert_paid`
- و `remaining`

را برای هر assigned expert کامل تکرار می‌کرد.

یعنی یک pool مشترک step، چند بار شمرده می‌شد.

---

# چه چیزی اصلاح شد؟

## 1) توزیع step بین کارشناسان
یک helper جدید اضافه شد که برای هر step:
- assigned expertها را پیدا می‌کند
- distribution واقعی/ایمن‌تری از `due / paid / remaining` می‌سازد
- جلوی duplicate counting را می‌گیرد

## 2) snapshot پروژه
در `get_project_financial_snapshot()`
- expert due / expert paid از distribution ایمن‌تر خوانده می‌شوند

## 3) صفحه تسویه کارشناسان
در `build_experts_and_steps()`
- pendingBalance و paidBalance دیگر برای هر expert کورکورانه تکرار نمی‌شوند
- stepهای pending هم بر همان distribution جدید ساخته می‌شوند

## 4) party accounts / expert pending
در `build_party_accounts()`
- pending expert balance هم از distribution جدید می‌آید

## 5) total تسویه کارشناسان
در `actual_expert_payouts_total()`
- total از snapshot پروژه‌ها گرفته می‌شود، نه از جمع خامِ ledger rowهای تاریخی که ممکن بود duplicate یا noisy باشند

---

# نتیجه مورد انتظار بعد از نصب 8.2.8

1. اگر یک مرحله چند کارشناس دارد، مبلغ آن step دوبار/چندبار شمرده نشود
2. کارت `تسویه کارشناسان` به واقعیت نزدیک‌تر شود
3. pending settlementها و expert balances منطقی‌تر شوند
4. dashboard inflated settlement total نداشته باشد

---

# این نسخه چه چیزی را عمداً حل نمی‌کند؟

- cash view جداگانه برای P&L
- decommission کامل legacy
- final report cutover

این نسخه فقط برای بستن خطای multi-expert duplicate counting در Wave 2 است.

---

# بعد از نصب چه چیزی را تست کن؟

1. همان مثال multi-expert که قبلاً 14 می‌شد را دوباره ببین
2. کارت `تسویه کارشناسان` را در dashboard چک کن
3. صفحه `تسویه کارشناسان` را چک کن
4. اگر شد `حساب پروژه‌ها` را هم چک کن

---

**پایان hotfix 8.2.8**
