# PHASE_12_REPORT

> Phase 12 Execution Artifact  
> Program: ERP Refactor / Accounting Unification  
> Source references: `ACCOUNTING_SYSTEM_ANALYSIS.md`, `ERP_ARCHITECTURE.md`, `ERP_REFACTOR_ROADMAP.md`, `ERP_UI_ARCHITECTURE_CURRENT.md`, `PHASE_0_REPORT.md`, `PHASE_1_REPORT.md`, `PHASE_2_REPORT.md`, `PHASE_3_REPORT.md`, `PHASE_4_REPORT.md`, `PHASE_5_REPORT.md`, `PHASE_6_REPORT.md`, `PHASE_7_REPORT.md`, `PHASE_8_REPORT.md`, `PHASE_9_REPORT.md`, `PHASE_10_REPORT.md`, `PHASE_11_REPORT.md`  
> Additional binding decisions: user-approved target UI = ERP Accounting Panel, zero-variance rule, legacy freeze after CP-6  
> Mode: **No code change / No schema change in this turn / Final Cutover & Hardening Plan only**

---

# 0) اعلام صریح قبل از شروع

## 0.1 پاسخ کوتاه و ساده

**در این نوبت فقط فاز ۱۲ را به‌صورت گزارش نهایی اجرا کرده‌ام و هیچ کدی را تغییر نداده‌ام.**

یعنی الان:
- هیچ feature flagی حذف نشده
- هیچ cutover واقعی انجام نشده
- هیچ migrationی اجرا نشده
- هیچ route یا endpointی live عوض نشده
- هیچ rollback یا freeze واقعی اجرا نشده

## 0.2 اما اجرای واقعی Phase 12 چه می‌خواهد؟

اجرای واقعی این فاز دیگر کاملاً نزدیک به استقرار نهایی است و حتماً نیاز دارد به:
- اجرای واقعی migrationها و cutoverها
- تغییر کد
- تغییر schema
- اجرای feature flagها
- freeze window
- backup کامل
- تست staging نهایی
- runbook اجرایی
- تیم پشتیبانی آماده

### نتیجه عملی
**اجرای واقعی Phase 12 فقط باید روی staging/production-like environment و با backup کامل انجام شود.**

---

# 1) هدف این گزارش

این سند، شروع اجرایی **Phase 12 — Final Cutover & Hardening** است و فقط روی این موارد تمرکز دارد:

1. نهایی‌کردن برنامه‌ی **حذف feature flagها**
2. تعریف **freeze final data migration window**
3. تعریف **reconciliation نهایی**
4. تعریف **performance review**
5. تعریف **accounting audit review**
6. تعریف **regression test کامل**
7. نهایی‌سازی **runbookهای production support**
8. نهایی‌سازی **operational manuals**
9. تعریف **go / no-go criteria**
10. تعریف **rollback plan نهایی**
11. حفظ صریح این اصل که **خانه‌ی نهایی سیستم همان پنل حسابداری ERP** است
12. ثبت **Ambiguity Register فاز ۱۲** برای تصمیم‌گیری قبل از اجرای واقعی نهایی

> این سند عمداً هیچ تغییری در کد، schema، query اجرایی، migration واقعی یا رفتار runtime ایجاد نمی‌کند.

---

# 2) معنی Phase 12 به زبان ساده

اگر خیلی ساده بگوییم:

- فازهای قبل گفتند سیستم جدید باید چطور باشد
- این فاز می‌گوید **چطور با خیال راحت سیستم را نهایی کنیم**

یعنی این فاز قرار است مطمئن شود:
- داده‌ها درست‌اند
- گزارش‌ها دقیق‌اند
- سرعت سیستم قابل قبول است
- rollback داریم
- تیم پشتیبانی می‌داند اگر مشکلی پیش آمد چه کند
- و بعد تازه می‌گوییم: «حالا سیستم آماده‌ی نهایی شدن است»

---

# 3) اصول قطعی که Phase 12 روی آن‌ها بنا می‌شود

## 3.1 منبع حقیقت اصلی
- `Voucher`
- `VoucherRow`

## 3.2 Journal و GL
- جدول فیزیکی واقعی
- append-only
- projection
- rebuildable from vouchers

## 3.3 وضعیت posted
- `FINALIZED` = posted official accounting state

## 3.4 اصلاح سند posted
- اصل پیش‌فرض = `Reversal`
- `Unfinalize` فقط استثنایی و policy-driven

## 3.5 اختلاف مجاز
- **صفر**
- بدهکار = بستانکار دقیق
- report variance = صفر

## 3.6 UI هدف
- فقط **ERP Accounting Panel**
- route canonical:
  - `wp-admin/admin.php?page=cptt-finance-erp`

## 3.7 Legacy
- دیگر owner حقیقت حسابداری نیست
- در بهترین حالت فقط read-only / archive / compatibility موقت است

---

# 4) هدف نهایی Cutover در پایان برنامه

## 4.1 وضعیت هدف

در پایان Phase 12، سیستم باید به این شکل باشد:

```text
Business Event
↓
Canonical Command
↓
Voucher / VoucherRow
↓
Posting
↓
Journal / GL
↓
TB / P&L / BS / Dashboard
↓
ERP Accounting Panel
```

## 4.2 چیزهایی که باید بسته شده باشند

- dual ledger semantics
- client-side accounting calculations
- synthetic voucher generation
- legacy report truth ownership
- hook-based accounting ownership
- mixed-source financial reporting

## 4.3 چیزهایی که باید فعال و پایدار باشند

- voucher-first pipeline
- journal/gl projections
- zero-variance report chain
- ERP canonical UI
- integration layer canonical
- audit trail کامل
- rollback-ready support model

---

# 5) Entry Criteria برای شروع اجرای واقعی Phase 12

## 5.1 بدون این شرط‌ها، اجرای واقعی Phase 12 نباید شروع شود

### شرط 1 — Voucher Truth Stable
- voucher audit passed
- trace fields قابل اتکا هستند
- finalized vouchers مشخص‌اند

### شرط 2 — Journal/GL Stable
- جدول‌های فیزیکی Journal و GL آماده‌اند
- rebuild از voucherها موفق بوده
- append-only rule enforce شده

### شرط 3 — Historical Migration Stable
- historical classification done
- low-confidence rows archive-only شده‌اند
- deduplication بر اساس `sourceType + sourceId` مشخص و validate شده
- historical partial settlements only for actual paid amounts mapped شده‌اند

### شرط 4 — Report Cutover Stable
- Documents / Journal / GL / Subsidiary / TB / P&L / BS / Dashboard cutover plan passed
- variance = 0

### شرط 5 — UI Ready
- ERP panel contracts پایدارند
- frontend دیگر حسابداری را محاسبه نمی‌کند
- legacy pages read-only + `قدیمی` هستند

### شرط 6 — Legacy Writers Frozen
- بعد از CP-6
- `wp_cptt_fin_ledger` و `wp_cptt_ledger` دیگر accounting writer نیستند

### شرط 7 — Master Data Ready
- اطلاعات پایه critical همزمان migrate و validate شده‌اند

### شرط 8 — Integration Ready
- webhook/API/import/print/cron policy canonical شده

### شرط 9 — Backup and Runbook Ready
- backup کامل
- restore test known
- runbook نهایی آماده

### شرط 10 — Sign-Off آماده
- technical sign-off
- accounting sign-off
- operational sign-off

---

# 6) Feature Flag Removal Plan

## 6.1 اصل کلی

Feature flagها باید فقط وقتی حذف شوند که:
- مسیر جدید پایدار شده باشد
- rollback window معقول طی شده باشد
- dependency ناشناخته باقی نمانده باشد

## 6.2 هدف این فاز

حذف feature flagها باید:
- مرحله‌ای باشد
- نه همه با هم
- و بعد از اثبات پایداری انجام شود

## 6.3 خانواده‌ی flagها

### A) Report Source Flags
- `cpttf_reports_documents_v2`
- `cpttf_reports_journal_v2`
- `cpttf_reports_gl_v2`
- `cpttf_reports_subsidiary_v2`
- `cpttf_reports_tb_v2`
- `cpttf_reports_pl_v2`
- `cpttf_reports_bs_v2`
- `cpttf_dashboard_v2`

### B) Legacy Visibility Flags
- `cpttf_legacy_pages_readonly`
- `cpttf_legacy_pages_old_badge`

### C) UI Refactor Flags
- `cpttf_ui_documents_v2`
- `cpttf_ui_journal_v2`
- `cpttf_ui_gl_v2`
- `cpttf_ui_subsidiary_v2`
- `cpttf_ui_tb_v2`
- `cpttf_ui_pl_v2`
- `cpttf_ui_bs_v2`
- `cpttf_ui_dashboard_v2`
- `cpttf_ui_source_managed_runtime`

### D) Compatibility / Adapter Flags
- temporary adapter flags
- backward-compat response flags
- legacy projection bridge flags

## 6.4 ترتیب حذف پیشنهادی

### Wave F1 — Compatibility Flags
اول flagهای compatibility که دیگر استفاده نمی‌شوند حذف شوند.

### Wave F2 — Report Flags
وقتی reportها stable شدند، flagهای report source حذف شوند.

### Wave F3 — UI Flags
وقتی UI source-managed runtime پایدار شد، flagهای UI حذف شوند.

### Wave F4 — Legacy Visibility Flags
وقتی صفحه‌های قدیمی دیگر لازم نبودند، flagهای read-only/old-badge نیز حذف یا decommission شوند.

## 6.5 Rule مهم

حذف flag یعنی قبول می‌کنیم که rollback سریع flag-based دیگر برای آن بخش وجود ندارد.  
پس این کار باید آخر خط انجام شود، نه اول خط.

---

# 7) Freeze Final Data Migration Window

## 7.1 معنی ساده

Freeze window یعنی یک بازه‌ی نهایی که در آن:
- تغییرات بی‌ربط متوقف می‌شود
- داده‌ی مالی کنترل‌شده می‌شود
- migration و cutover با کمترین نویز اجرا می‌شود

## 7.2 انواع freeze در فاز نهایی

### A) Code Freeze
روی فایل‌های مالی/ERP/Integration/UI هدف

### B) Schema Freeze
روی جداول مالی و migration scripts

### C) Financial Write Freeze
در صورت نیاز برای بعضی عملیات حساس در لحظه cutover نهایی

### D) Legacy Write Freeze
نویسنده‌های قدیمی باید قبلاً قطع شده باشند و در این فاز تثبیت شوند

### E) Config Freeze
تغییرات دستی در mapping/account/fiscal settings در بازه نهایی محدود شود

## 7.3 Freeze Window پیشنهادی

### Pre-Freeze
- baseline final snapshot
- final backup
- final checklist review

### Active Freeze Window
- no unrelated deploy
- no schema drift
- no new ad-hoc financial patch
- no manual legacy accounting correction

### Post-Freeze Validation
- reconciliation
- performance checks
- production support readiness

## 7.4 Rule مهم

در freeze نهایی، هر تغییر باید یا:
- در runbook تعریف شده باشد
- یا متوقف شود

---

# 8) Final Reconciliation Plan

## 8.1 اصل اصلی

قبل از نهایی‌کردن سیستم، باید مطمئن شویم:
- عددها با هم می‌خوانند
- چیزی دوبار ثبت نشده
- چیزی از قلم نیفتاده
- ERP panel همان truth رسمی را نشان می‌دهد

## 8.2 سه لایه‌ی reconciliation نهایی

### Layer A — Accounting Integrity
- vouchers
- journal
- GL
- TB
- statements

### Layer B — Business Financial Views
- receivables
- payables
- treasury
- party balances
- project financial snapshots

### Layer C — Integration Outputs
- API outputs
- webhook payloads
- print/export results
- notifications triggered by canonical events

## 8.3 Final Reconciliation Rules

### Rule 1
`finalized voucher debit total == finalized voucher credit total`

### Rule 2
`journal debit total == finalized voucher debit total`

### Rule 3
`journal credit total == finalized voucher credit total`

### Rule 4
`GL debit total == journal debit total`

### Rule 5
`GL credit total == journal credit total`

### Rule 6
`TB total debit == TB total credit`

### Rule 7
`P&L profit = revenue - expense`

### Rule 8
`BS assets == liabilities + equity`

### Rule 9
`Dashboard KPI == official source report`

### Rule 10
`No duplicate accepted business events by sourceType + sourceId`

## 8.4 Rule بسیار مهم

**سقف اختلاف مجاز = صفر**

یعنی:
- نه تقریبی
- نه «تقریباً درست»
- نه «فعلاً قبول کنیم»

---

# 9) Performance Review Plan

## 9.1 هدف

سیستم فقط نباید درست باشد؛ باید قابل استفاده هم باشد.

## 9.2 حوزه‌های performance review

### A) ERP Panel Load
- load main ERP shell
- tab switching
- report initial load

### B) Documents Performance
- list load
- filter/search performance
- pagination

### C) Journal / GL / Subsidiary Performance
- date range queries
- account filter queries
- dimension filter queries
- running balance response time

### D) TB / P&L / BS Performance
- statement generation latency
- snapshot freshness behavior

### E) Dashboard Performance
- KPI load time
- chart/card stability

### F) Rebuild / Reproject Performance
- full rebuild time
- incremental rebuild time

### G) Export / Print Performance
- export generation time
- memory safety

## 9.3 Performance Rules

1. browser نباید payload عظیم خام بگیرد و خودش حسابداری بسازد
2. pagination باید server-side باشد
3. statementها باید deterministic و practical باشند
4. rebuild باید قابل اجرا و قابل پایش باشد

## 9.4 عددهای دقیق SLO
- **نیاز به بررسی بیشتر / نیاز به تصمیم قبل از اجرای واقعی**

### توضیح ساده
برای سرعت دقیق مثل «چند ثانیه قابل قبول است» هنوز باید عدد نهایی تعیین شود.

---

# 10) Accounting Audit Review Plan

## 10.1 هدف

قبل از اعلام نهایی موفقیت، باید از دید حسابداری هم بررسی شود، نه فقط فنی.

## 10.2 موارد audit review

### A) Voucher Traceability
- هر سند posted sourceType/sourceId دارد
- auto-generated voucherها `isAutoGenerated = true` دارند
- reversal chain روشن است

### B) Posting Integrity
- no direct write outside posting
- append-only respected
- no hidden accounting writer in legacy

### C) Fiscal Integrity
- lock behavior respected
- final close/open logic explainable

### D) Statement Integrity
- P&L and BS from official chain
- no client-side accounting truth

### E) Historical Migration Integrity
- low-confidence rows archive-only شده‌اند
- duplicate events avoided by `sourceType + sourceId`
- partial historical settlement only actual paid amount mapped

### F) UI Integrity
- ERP panel is canonical
- legacy pages not authoritative

## 10.3 Audit Output Artifacts

- accounting sign-off checklist
- sampled trace reports
- reversal validation report
- fiscal close/open validation report
- historical migration exception log

---

# 11) Full Regression Test Plan

## 11.1 هدف

همه‌ی جریان‌های مهم باید یک بار از اول تا آخر تست شوند تا مطمئن شویم refactor فقط report را درست نکرده، بلکه رفتار را هم نشکسته.

## 11.2 سناریوهای regression پیشنهادی

### Scenario 1 — Manual Voucher Lifecycle
- create draft
- approve (if manual)
- finalize/post
- appear in documents/journal/GL/TB

### Scenario 2 — Customer Receipt
- register receipt
- posted voucher RV
- receivable impact
- dashboard impact

### Scenario 3 — Expert Settlement
- settlement posted
- PV generated
- party/project impact

### Scenario 4 — Payable Payment
- payable payment
- PV generated
- payable balance updated

### Scenario 5 — Installment Receipt
- installment receipt
- RV generated
- installment balance updated

### Scenario 6 — Treasury Transfer
- TV generated
- no net treasury contradiction

### Scenario 7 — Direct Income / Expense
- inflow = RV
- outflow = PV
- report impact correct

### Scenario 8 — Invoice To Voucher
- invoice linked to voucher
- traceability preserved

### Scenario 9 — Fiscal Close / Reopen
- CV/OV chain correct
- locks respected

### Scenario 10 — Reversal
- posted voucher reversed
- journal/gl/report impact correct

### Scenario 11 — Legacy Read-Only Pages
- open legacy page
- see `قدیمی`
- no authoritative write behavior

### Scenario 12 — Integration Paths
- webhook payload correctness
- print/export correctness
- cron reminder correctness

## 11.3 Rule مهم

regression فقط UI تست نیست؛ باید شامل:
- data correctness
- report correctness
- integration correctness
- permissions
- audit trail

باشد.

---

# 12) Production Support Runbook Plan

## 12.1 هدف runbook

اگر بعد از cutover مشکلی پیش آمد، تیم باید دقیق بداند چه کار کند.

## 12.2 runbookهای لازم

### Runbook A — Final Cutover Execution
- step-by-step execution order
- responsible owner per step
- checkpoints
- stop conditions

### Runbook B — Rebuild / Reproject
- when to run
- prerequisites
- expected outputs
- validation after rebuild

### Runbook C — Reconciliation Failure
- what to check first
- which reports compare
- when to stop rollout

### Runbook D — Integration Failure
- webhook failures
- API contract failures
- import failures
- notification failures

### Runbook E — Rollback
- when to rollback
- how to rollback by layer
- what not to do manually

### Runbook F — Legacy Visibility / Redirect Issues
- if users cannot find destination
- if legacy read-only path still needed

## 12.3 Rule مهم

runbook باید با زبان ساده برای تیم اجرا و پشتیبانی هم قابل استفاده باشد، نه فقط برای معمار فنی.

---

# 13) Operational Manuals Plan

## 13.1 برای چه کسانی؟

### A) ادمین سیستم
- مسیر canonical کجاست
- legacy pageها چه وضعی دارند
- گزارش رسمی از کجا دیده می‌شود

### B) کاربر مالی / حسابدار
- ثبت سند
- اصلاح با reversal
- تفاوت draft و finalized
- مرجع نهایی گزارش‌ها

### C) تیم فنی / پشتیبانی
- rebuild/reproject
- feature flags
- rollback
- integration troubleshooting

## 13.2 Manualهای پیشنهادی

1. **راهنمای استفاده از پنل ERP مالی**
2. **راهنمای گزارش‌های رسمی**
3. **راهنمای اصلاح سند با Reversal**
4. **راهنمای legacy pages و معنی برچسب `قدیمی`**
5. **راهنمای پشتیبانی فنی و rollback**

## 13.3 Rule مهم

manualها باید روشن کنند:
- کدام صفحه مرجع نهایی است
- کدام صفحه فقط قدیمی/مقایسه‌ای است
- اصلاح سند چطور انجام می‌شود
- گزارش رسمی از کجا می‌آید

---

# 14) Go / No-Go Decision Framework

## 14.1 هدف

قبل از نهایی‌کردن، باید یک تصمیم روشن گرفته شود:
- **Go**
- یا **No-Go**

## 14.2 Go Criteria

### فقط اگر همه این‌ها برقرار باشند:
1. reconciliation کامل پاس شده باشد
2. variance = 0
3. report cutover پایدار باشد
4. ERP UI canonical surface بدون dependency قدیمی کار کند
5. legacy writers frozen باشند
6. integration tests پاس شده باشند
7. audit review sign-off شده باشد
8. rollback آماده و تست‌شده باشد
9. runbook و manual آماده باشد

## 14.3 No-Go Criteria

اگر هرکدام از این‌ها رخ دهد:
- variance غیرصفر
- duplicate sourceType/sourceId accepted
- unexplained mismatch in TB/P&L/BS
- ERP panel dependency on client-side accounting logic
- legacy writer still active in accounting path
- rollback unclear
- integration drift unresolved

## 14.4 ساده‌ترین قانون تصمیم

```text
اگر عددها دقیق نیستند = No-Go
اگر rollback روشن نیست = No-Go
اگر ERP پنل هنوز به منطق قدیمی وابسته است = No-Go
```

---

# 15) Final Rollback Plan

## 15.1 اصل کلی

Rollback نهایی باید لایه‌لایه باشد و truth ownership را تا حد ممکن به عقب برنگرداند.

## 15.2 Rollback Layers

### Layer 1 — Report/UI Rollback
- خاموش کردن report/UI feature flagها
- بازگشت read path موقت برای report surfaceها

### Layer 2 — Integration Rollback
- غیرفعال‌کردن webhook family یا API version جدید
- بازگرداندن adapter موقت

### Layer 3 — Projection Rollback
- discard/rebuild Journal/GL projections
- rebuild again from valid voucher truth

### Layer 4 — Migration Rollback
- restore DB snapshot if required
- revert historical backfill wave if checkpointed and possible

### Layer 5 — Final Emergency Stop
- stop final promotion
- keep ERP canonical goal, but pause rollout

## 15.3 چیزی که نباید در rollback رخ دهد

- patch دستی روی GL برای «درست کردن سریع»
- patch دستی روی Journal برای پنهان کردن اختلاف
- برگرداندن legacy به owner truth به‌صورت بی‌قاعده

## 15.4 Rule مهم

Rollback باید یا:
- با snapshot restore انجام شود
- یا با rebuild from voucher truth

نه با حدس و patch دستی.

---

# 16) Final Cutover Timeline پیشنهادی

## 16.1 T-7 تا T-3
- final audit
- final reconciliation rehearsal
- feature flag readiness check
- runbook review
- manual draft review

## 16.2 T-2 تا T-1
- freeze windows active
- final backup
- final go/no-go review
- sign-off collection

## 16.3 T0
- execute final cutover steps طبق runbook
- monitor checkpoints
- stop immediately on breach

## 16.4 T+1 تا T+3
- post-cutover monitoring
- variance verification
- user acceptance confirmation
- legacy visibility review

## 16.5 T+N
- feature flag removal waves
- adapter cleanup
- decommission completion

---

# 17) Post-Cutover Monitoring Plan

## 17.1 چه چیزهایی باید مانیتور شوند؟

- report generation errors
- webhook failures
- API contract errors
- print/export failures
- reconciliation drift
- duplicate event attempts
- rebuild errors
- user confusion on legacy vs ERP paths

## 17.2 Alert Priorities

### Priority 1
- debit/credit mismatch
- TB inequality
- statement mismatch
- duplicate accepted accounting event

### Priority 2
- ERP report load failures
- webhook delivery failures
- print/export failures

### Priority 3
- legacy page confusion
- stale dashboard freshness issues

---

# 18) روش تست معماری Phase 12

## 18.1 Review Checklist

برای پذیرش این Phase باید این سوال‌ها پاسخ روشن داشته باشند:

1. آیا entry criteria اجرای نهایی روشن شده‌اند؟
2. آیا feature flag removal plan مشخص شده؟
3. آیا freeze final window تعریف شده؟
4. آیا reconciliation نهایی با variance صفر تعریف شده؟
5. آیا performance review plan مشخص شده؟
6. آیا accounting audit review plan مشخص شده؟
7. آیا full regression plan مشخص شده؟
8. آیا runbookها و manualها فهرست شده‌اند؟
9. آیا go/no-go framework روشن شده؟
10. آیا rollback plan نهایی مشخص شده؟
11. آیا ambiguityهای Phase 12 صریح ثبت شده‌اند؟

## 18.2 سناریوهای تست پیشنهادی

- full accounting regression
- month-end / year-end scenario
- rebuild after cutover validation
- report variance final check
- ERP canonical UI walk-through
- integration end-to-end check
- rollback rehearsal on staging

---

# 19) ارزیابی انجام Taskهای Phase 12 نسبت به Roadmap

## 19.1 Taskهای Phase 12 در Roadmap

طبق `ERP_REFACTOR_ROADMAP.md`، Phase 12 شامل این موارد بود:
- نهایی‌کردن feature flag removals
- freeze final data migration window
- اجرای reconciliation final
- اجرای performance review
- اجرای accounting audit review
- اجرای regression test کامل
- نهایی‌سازی runbookهای production support
- نهایی‌سازی operational manuals

## 19.2 وضعیت این artefact

| Task | وضعیت |
|---|---|
| feature flag removal plan | ✅ انجام شد |
| final freeze window plan | ✅ انجام شد |
| final reconciliation plan | ✅ انجام شد |
| performance review plan | ✅ انجام شد |
| accounting audit review plan | ✅ انجام شد |
| full regression test plan | ✅ انجام شد |
| production support runbooks | ✅ فهرست و plan شد |
| operational manuals | ✅ فهرست و plan شد |
| go/no-go framework | ✅ انجام شد |
| rollback plan نهایی | ✅ انجام شد |
| ambiguity register | ✅ انجام شد |

## 19.3 Definition of Done Phase 12

Phase 12 زمانی Done تلقی می‌شود که:
1. final cutover criteria مشخص شده باشد ✅
2. hardening/reconciliation/performance/audit plan مشخص شده باشد ✅
3. rollback/runbook/manual plan مشخص شده باشد ✅
4. review ambiguityهای باز قبل از اجرای واقعی انجام شده باشد ⏳

### نتیجه
از منظر **مستندسازی معماری و برنامه‌ی نهایی Cutover & Hardening**، Phase 12 در این artefact **شروع و تدوین شده است**؛  
اما از منظر **اجرای واقعی نهایی** هنوز نیازمند تصمیم روی چند ambiguity اجرایی، performance threshold و sign-off ownership است.

---

# 20) Ambiguity Register فاز ۱۲

> این بخش باید قبل از اجرای واقعی نهایی مرور و تصمیم‌گیری شود.

## 20.1 thresholdهای دقیق performance/SLO چه باشند؟

### توضیح ساده
هنوز باید دقیق تصمیم بگیریم مثلاً هر گزارش یا هر rebuild حداکثر چقدر زمان مجاز دارد.

### وضعیت
**نیاز به تصمیم**

---

## 20.2 observation window قبل از حذف نهایی feature flagها چقدر باشد؟

### توضیح ساده
بعد از اینکه مسیر جدید کار کرد، چند روز/هفته صبر کنیم و بعد flagها را حذف کنیم؟

### وضعیت
**نیاز به تصمیم**

---

## 20.3 چه کسانی باید sign-off نهایی بدهند؟

### توضیح ساده
باید دقیق روشن شود چه نقش‌هایی اجازه دارند بگویند «سیستم آماده نهایی شدن است».

### وضعیت
**نیاز به تصمیم**

---

## 20.4 legacy read-only pageها در پایان نهایی کاملاً مخفی شوند یا مدتی reference بمانند؟

### توضیح ساده
باید تصمیم بگیریم بعد از نهایی شدن، صفحه‌های قدیمی فوراً ناپدید شوند یا مدتی برای مرجع بمانند.

### وضعیت
**نیاز به تصمیم**

---

## 20.5 final rollback horizon چقدر باشد؟

### توضیح ساده
تا چند وقت بعد از cutover نهایی، rollback کامل هنوز گزینه‌ی واقعی و پشتیبانی‌شده باشد؟

### وضعیت
**نیاز به تصمیم**

---

## 20.6 export/print cutover دقیقاً همزمان با report finalization انجام شود یا آخرین موج جداگانه داشته باشد؟

### توضیح ساده
باید تصمیم بگیریم چاپ و خروجی گزارش‌ها همان لحظه نهایی شوند یا در یک موج بعدی.

### وضعیت
**نیاز به تصمیم**

---

# 21) جمع‌بندی نهایی Phase 12

مهم‌ترین خروجی Phase 12 این است که از اینجا به بعد، برنامه فقط «معماری خوب» ندارد، بلکه **معیار نهایی‌کردن و ایمن‌کردن** هم دارد.

### نتیجه‌های کلیدی
- معیار شروع اجرای نهایی روشن شد
- plan حذف feature flagها مشخص شد
- freeze window نهایی تعریف شد
- reconciliation نهایی با variance صفر تعریف شد
- performance review و accounting audit review مشخص شد
- full regression plan تعریف شد
- runbookها و manualهای لازم فهرست شدند
- go/no-go framework و rollback plan نهایی مشخص شد
- ERP panel به‌عنوان خانه‌ی نهایی سیستم دوباره تثبیت شد

### اصل نهایی این فاز

```text
Do not finalize because the design looks good.
Finalize only when truth, reports, performance, support, and rollback are all ready.
```

و به زبان ساده‌تر:

```text
فقط چون نقشه خوب شده، کار را نهایی نمی‌کنیم.
وقتی نهایی می‌کنیم که
عددها درست باشند،
گزارش‌ها درست باشند،
سرعت قابل قبول باشد،
پشتیبانی آماده باشد،
و راه برگشت هم روشن باشد.
```

---

**پایان گزارش Phase 12**
