# PHASE_10_REPORT

> Phase 10 Execution Artifact  
> Program: ERP Refactor / Accounting Unification  
> Source references: `ACCOUNTING_SYSTEM_ANALYSIS.md`, `ERP_ARCHITECTURE.md`, `ERP_REFACTOR_ROADMAP.md`, `ERP_UI_ARCHITECTURE_CURRENT.md`, `PHASE_0_REPORT.md`, `PHASE_1_REPORT.md`, `PHASE_2_REPORT.md`, `PHASE_3_REPORT.md`, `PHASE_4_REPORT.md`, `PHASE_5_REPORT.md`, `PHASE_6_REPORT.md`, `PHASE_7_REPORT.md`, `PHASE_8_REPORT.md`, `PHASE_9_REPORT.md`  
> Additional binding decisions: user-approved UI target = ERP Accounting Panel  
> Mode: **No code change / No schema change in this turn / Legacy Decommission Plan only**

---

# 0) اعلام صریح قبل از شروع

## 0.1 پاسخ کوتاه و ساده

**در این نوبت فقط فاز ۱۰ را به‌صورت گزارش معماری و برنامه‌ی بازنشستگی Legacy اجرا کرده‌ام و هیچ کدی را تغییر نداده‌ام.**

یعنی الان:
- هیچ صفحه‌ای حذف نشده
- هیچ routeی redirect نشده
- هیچ endpointی خاموش نشده
- هیچ feature flagی تغییر نکرده
- هیچ جدول legacyای archive یا freeze نشده

## 0.2 اما اجرای واقعی این فاز چه می‌خواهد؟

اجرای واقعی Phase 10 حتماً نیاز دارد به:
- تغییر کد backend و frontend
- خاموش کردن بعضی مسیرهای قدیمی
- redirect کردن بعضی pageها
- read-only کردن دائمی بعضی صفحه‌ها
- حذف بعضی logicهای fallback
- تست staging و rollback plan واقعی

### نتیجه عملی
**اجرای واقعی Phase 10 فقط باید روی staging و با backup کامل انجام شود.**

---

# 1) هدف این گزارش

این سند، شروع اجرایی **Phase 10 — Legacy Decommission Plan** است و فقط روی این موارد تمرکز دارد:

1. تعیین لیست بخش‌هایی که باید **حذف کامل** شوند
2. تعیین لیست بخش‌هایی که باید **archive** شوند
3. تعیین لیست بخش‌هایی که باید **redirect** شوند
4. تعیین **deprecation timeline**
5. تعیین **communication plan** برای ادمین‌ها/کاربران
6. تعیین اینکه چه dependencyهایی باید قبل از خاموش‌کردن Legacy قطع شوند
7. هم‌راستا نگه داشتن decommission با این تصمیم قطعی که **UI نهایی همان ERP Accounting Panel** است
8. ثبت **Ambiguity Register فاز ۱۰** برای تصمیم‌گیری قبل از فاز بعد

> این سند عمداً هیچ تغییری در کد، schema، query اجرایی، migration واقعی یا رفتار runtime ایجاد نمی‌کند.

---

# 2) اصل بنیادین Phase 10

## 2.1 تعریف ساده

Legacy Decommission یعنی:
- چیزهایی که قبلاً لازم بوده‌اند ولی الان دیگر نباید صاحب منطق یا داده‌ی رسمی باشند، به‌تدریج از مدار اصلی خارج شوند.

## 2.2 اصل کلیدی

در این پروژه قرار نیست همه‌چیز قدیمی را ناگهانی پاک کنیم.  
بلکه قرار است:

```text
اول source رسمی جدید را پایدار کنیم
↓
بعد وابستگی‌ها را از قدیمی جدا کنیم
↓
بعد قدیمی را read-only / redirect / archive / remove کنیم
```

## 2.3 اصل نهایی

```text
ERP Panel stays.
Legacy loses ownership.
Then legacy is retired safely.
```

---

# 3) وضعیت مرجع معماری قبل از Decommission

قبل از اجرای واقعی Phase 10 این چیزها باید از قبل روشن شده باشند:

## 3.1 Truth و source رسمی
- SoT اصلی = `Voucher` + `VoucherRow`
- Journal = جدول فیزیکی projection
- GL = جدول فیزیکی projection رسمی مانده‌ها

## 3.2 UI هدف
- پنل نهایی = ERP Accounting Panel
- route اصلی = `admin.php?page=cptt-finance-erp`

## 3.3 وضعیت صفحه‌های قدیمی
- در دوره‌ی گذار فقط-خواندنی
- با برچسب `قدیمی`
- غیرمرجع

## 3.4 وضعیت cutover گزارش‌ها
طبق Phase 8 باید گزارش‌ها یکی‌یکی به source رسمی جدید سوییچ شده باشند یا آماده سوییچ باشند.

---

# 4) دسته‌بندی اجزای Legacy برای Decommission

برای اینکه بازنشستگی Legacy کنترل‌شده باشد، اجزا در 5 گروه دسته‌بندی می‌شوند:

## 4.1 Legacy UI Pages
مثل:
- dashboard مالی قدیمی
- receivables قدیمی
- payouts قدیمی
- treasury قدیمی
- ledger قدیمی
- transactions قدیمی
- categories قدیمی
- صفحه حسابداری کلاسیک در admin

## 4.2 Legacy Read Logic
مثل:
- client-side report aggregation
- mixed-source KPI calculation
- fallback readers
- legacy report queries

## 4.3 Legacy Write Logic
مثل:
- direct writes به `wp_cptt_fin_ledger`
- direct writes به `wp_cptt_ledger`
- adjustment/delete flowهای قدیمی
- hook-based accounting ownership

## 4.4 Legacy Compatibility Artifacts
مثل:
- synthetic / virtual voucher generation
- heuristic ledger↔voucher matching
- backfill/fallback readers
- response shape compatibility adapters

## 4.5 Legacy Storage Role
مثل:
- `wp_cptt_fin_ledger`
- `wp_cptt_ledger`
- بعضی option-based states که دیگر source اصلی نیستند

---

# 5) چیزهایی که باید حذف کامل شوند

## 5.1 Synthetic / Virtual Voucher Generation در Frontend

### چرا باید حذف شود؟
چون:
- سند حسابداری UI-only می‌سازد
- باعث divergence بین Documents و Journal می‌شود
- خلاف اصل Voucher-First است

### تصمیم
**حذف کامل**

### شرط حذف
- Documents cutover کامل شده باشد
- backend source رسمی آماده باشد

---

## 5.2 Client-Side Financial Report Calculation

### شامل چه چیزهایی است؟
- Journal flattening به‌عنوان source truth
- GL aggregation در مرورگر
- TB aggregation در مرورگر
- P&L formula در مرورگر
- BS formula در مرورگر
- KPIهای مالی mixed-source در مرورگر

### تصمیم
**حذف کامل**

### شرط حذف
- report sourceهای رسمی server-side آماده و stable باشند
- acceptance criteria با variance صفر پاس شده باشد

---

## 5.3 Dual Ledger Read Paths به‌عنوان Source رسمی

### شامل چه چیزهایی است؟
- هر مسیری که گزارش رسمی را از `wp_cptt_fin_ledger` یا `wp_cptt_ledger` می‌سازد

### تصمیم
**حذف کامل از مسیر رسمی گزارش‌گیری**

### توضیح مهم
ممکن است خود جدول‌ها برای archive/history بمانند، ولی **read path رسمی report** نباید به آن‌ها وصل باشد.

---

## 5.4 Legacy Adjustment / Delete Flows برای accounting posted behavior

### مثال‌ها
- `cptt_step_settlement_adjust`
- `cptt_manual_expert_payment_adjust`
- `cptt_fin_tx_delete` وقتی معنای accounting posted correction دارد

### تصمیم
**حذف کامل به‌عنوان مسیر اصلاح accounting**

### جایگزین
- `Reversal`
- در موارد استثنایی: `Unfinalize` policy-controlled

---

## 5.5 Hook-Based Transaction Ownership

### مثال‌ها
- `cptt_after_expert_payout` به‌عنوان owner
- `cptt_after_manual_expert_payment` به‌عنوان owner
- `_cptt_steps` observer به‌عنوان accounting writer

### تصمیم
**حذف کامل به‌عنوان transaction owner**

### توضیح
hook می‌تواند signal بماند، owner نه.

---

# 6) چیزهایی که باید Archive شوند

## 6.1 `wp_cptt_fin_ledger`

### نقش نهایی
- archive / historical reference
- migration input history
- compatibility reference محدود

### تصمیم
**archive شود، نه حذف فیزیکی فوری**

### دلیل
- historical value دارد
- ممکن است برای audit یا بررسی migration لازم شود

---

## 6.2 `wp_cptt_ledger`

### نقش نهایی
- archive / settlement history
- migration evidence
- historical reference

### تصمیم
**archive شود، نه حذف فیزیکی فوری**

---

## 6.3 Legacy Finance Pages

### شامل
- `page-dashboard.php`
- `page-receivables.php`
- `page-payouts.php`
- `page-transactions.php`
- `page-treasury.php`
- `page-ledger.php`
- `page-categories.php`

### تصمیم
**در فاز انتقال archive functional / read-only شوند**

### معنی archive functional
- در چرخه‌ی اصلی کسب‌وکار نباشند
- فقط برای reference و transition زنده بمانند
- معیار truth نباشند

---

## 6.4 Legacy JS/CSS Surfaces

### شامل
- `assets/js/finance.js`
- `assets/css/finance.css`

### تصمیم
**archive شوند وقتی pageهای legacy decommission شوند**

### توضیح
تا وقتی pageهای قدیمی زنده‌اند، این assetها لازم‌اند. بعد از خاموش شدن pageها، آن‌ها هم از مسیر اصلی خارج می‌شوند.

---

## 6.5 Compatibility Adapters که دیگر استفاده نمی‌شوند

### مثال‌ها
- temporary response adapters
- temporary legacy projection bridges
- temporary read-only wrappers

### تصمیم
بعد از cutover کامل، **archive و سپس remove** شوند.

---

# 7) چیزهایی که باید Redirect شوند

## 7.1 اصل کلی Redirect

هرجایی که صفحه قدیمی هنوز route یا منو دارد ولی معادل ERP آن آماده و stable است، بهتر است به صفحه canonical ERP هدایت شود.

## 7.2 مقصد canonical

مقصد اصلی redirectها باید همین باشد:
- `admin.php?page=cptt-finance-erp`

و اگر لازم شد با tab/filter مناسب باز شود.

---

## 7.3 Redirect Candidates

| Legacy Surface | مقصد پیشنهادی |
|---|---|
| dashboard مالی legacy | ERP Dashboard tab |
| receivables legacy | ERP receivables / party/project financial view |
| payouts legacy | ERP expert settlement / party financial view |
| transactions legacy | ERP treasury / income-expense canonical surface |
| treasury legacy | ERP treasury-related canonical surface |
| ledger legacy | ERP Journal / GL / Subsidiary tabs |
| accounting page کلاسیک | ERP accounting panel |

## 7.4 Rule مهم

Redirect فقط وقتی مجاز است که:
- ERP مقصد آماده باشد
- source رسمی جدید active باشد
- کاربران بتوانند همان کار اصلی را در مقصد انجام دهند یا بهتر بفهمند

---

# 8) چیزهایی که باید Keep شوند، اما دیگر Legacy Truth Owner نیستند

## 8.1 `class-cptt-payment.php`

### keep چرا؟
چون payment intake / gateway boundary هنوز operational value دارد.

### اما truth owner نیست
- accounting truth owner نیست
- receivable truth owner نیست

### تصمیم
**Keep operationally, decommission as accounting owner**

---

## 8.2 `class-cptt-expert.php`

### keep چرا؟
چون workflow عملیاتی پروژه و stepها هنوز لازم است.

### اما truth owner نیست
- project financial reporting owner نیست
- accounting balance owner نیست

### تصمیم
**Keep operationally, decommission financially**

---

## 8.3 Option-based transitional masters

### keep چرا؟
ممکن است بعضی master dataها هنوز تا پایان migration موجی استفاده شوند.

### تصمیم
**Keep temporarily until canonical storage fully stabilized**

---

# 9) Decommission Map نهایی برای اجزای اصلی

## 9.1 فایل/ماژول/مسیر → Fate

| Component | Fate نهایی | توضیح |
|---|---|---|
| synthetic voucher generation in frontend | Remove | مسیر کاملاً ناسازگار با معماری نهایی |
| client-side Journal/TB/P&L/BS calculations | Remove | باید server-side شوند |
| `wp_cptt_fin_ledger` as accounting source | Archive + Deprecate | history only |
| `wp_cptt_ledger` as accounting source | Archive + Deprecate | history only |
| legacy finance dashboard page | Redirect / Archive | ERP dashboard مقصد نهایی |
| legacy receivables page | Redirect / Archive | ERP read model مقصد نهایی |
| legacy payouts page | Redirect / Archive | ERP/party settlement مقصد نهایی |
| legacy ledger page | Redirect / Archive | ERP journal/GL مقصد نهایی |
| legacy transactions page | Redirect / Archive | ERP treasury canonical surface |
| legacy treasury page | Redirect / Archive | ERP treasury canonical surface |
| legacy categories page | Keep temporarily / Archive later | بستگی به fate categories |
| `assets/js/finance.js` | Archive then Remove | بعد از خاموشی pageهای legacy |
| `assets/css/finance.css` | Archive then Remove | بعد از خاموشی pageهای legacy |
| hook-based accounting ownership | Remove | signal-only یا حذف کامل |
| heuristic legacy backfill readers | Remove | rebuild رسمی جایگزین می‌شود |
| compatibility response adapters | Archive then Remove | فقط در migration window |

---

# 10) Decommission Timeline پیشنهادی

## 10.1 اصل کلی

بازنشستگی Legacy باید مرحله‌ای باشد، نه یک‌باره.

## 10.2 Wave Timeline

### Wave A — Freeze Legacy Ownership
- old accounting writers freeze شوند
- legacy pages read-only و `قدیمی` شوند
- report truth از legacy جدا شود

### Wave B — Redirect Canonical Reads
- dashboard / receivables / ledger / payouts / treasury مسیر canonical ERP بگیرند
- کاربران به ERP panel هدایت شوند

### Wave C — Remove Client-Side Accounting Logic
- formulaهای client-side حذف شوند
- synthetic vouchers حذف شوند
- source رسمی backend-only شود

### Wave D — Archive Legacy Runtime Surfaces
- legacy JS/CSS و page logic از مسیر روزمره خارج شوند
- فقط archive/reference باقی بمانند

### Wave E — Final Removal
- وقتی وابستگی ناشناخته‌ای نماند، remove نهایی انجام شود

---

# 11) Preconditions برای هر موج Decommission

## 11.1 موج A
قبل از Freeze Ownership:
- CP-6 passed
- legacy ledger write freeze approved
- ERP report sources ready

## 11.2 موج B
قبل از Redirect:
- ERP panel destination ready
- acceptance with variance zero passed
- read-only labels tested

## 11.3 موج C
قبل از Remove Client Logic:
- UI contracts stable
- backend responses complete
- no page depends on browser-side accounting formula

## 11.4 موج D
قبل از Archive Runtime:
- legacy pages no longer needed operationally
- admin acceptance complete

## 11.5 موج E
قبل از Final Removal:
- no known dependency remains
- staging usage validated
- rollback path no longer needed or alternative path stable

---

# 12) Communication Plan

## 12.1 هدف

وقتی مسیرهای قدیمی بازنشسته می‌شوند، اگر به کاربر/ادمین نگوییم چه اتفاقی افتاده، گیج می‌شوند.

## 12.2 مخاطب‌ها

### A) ادمین سیستم
باید بداند:
- کدام صفحات قدیمی شده‌اند
- مقصد جدید کجاست
- معیار گزارش رسمی چیست

### B) کاربر مالی / حسابدار
باید بداند:
- از کجا به بعد مرجع نهایی فقط ERP panel است
- صفحات قدیمی فقط reference هستند
- اصلاح سند posted باید reversal باشد، نه delete/adjust قدیمی

### C) توسعه‌دهنده / پشتیبان فنی
باید بداند:
- چه endpointهایی deprecated شده‌اند
- چه flagهایی فعال شده‌اند
- rollback کجاست

## 12.3 پیام‌های ساده‌ی لازم

### پیام 1
«از این تاریخ به بعد، گزارش‌های رسمی فقط از پنل ERP معتبر هستند.»

### پیام 2
«صفحه‌های قدیمی فقط برای مشاهده و مقایسه هستند و مرجع نهایی نیستند.»

### پیام 3
«اگر سندی اشتباه شد، اصلاح آن با سند برگشتی (Reversal) انجام می‌شود، نه حذف یا اصلاح قدیمی.»

### پیام 4
«ظاهر اصلی پنل ERP حفظ شده و مقصد نهایی همان پنل است.»

## 12.4 محل نمایش پیام‌ها
- admin notice
- badge `قدیمی` در صفحه‌های قدیمی
- tooltip/help text در ERP panel
- release notes / changelog
- runbook داخلی تیم

---

# 13) Legacy Pages Policy در دوره گذار

## 13.1 Rule اصلی

pageهای legacy در دوره‌ی گذار باید این سه ویژگی را با هم داشته باشند:
- read-only
- old-badged
- non-authoritative

## 13.2 چیزهایی که نباید در این pageها بماند
- create/update/delete accounting actions
- write owner behavior
- final report trust semantics

## 13.3 چیزهایی که می‌توانند موقتاً بمانند
- reference view
- historical comparison
- sanity-check / audit aid

## 13.4 Rule مهم

اگر صفحه‌ای هنوز write می‌کند، دیگر page گذار نیست؛ هنوز legacy owner است و نباید وارد decommission wave بعدی شود.

---

# 14) Risk Analysis فاز ۱۰

## 14.1 ریسک حذف زودهنگام Legacy
اگر زود حذف کنیم:
- بعضی flowهای عملیاتی می‌شکنند
- بعضی کاربرها مقصد جدید را پیدا نمی‌کنند
- rollback سخت می‌شود

## 14.2 ریسک نگه‌داشتن طولانی Legacy
اگر دیر حذف کنیم:
- کاربران دو مرجع مختلف می‌بینند
- confusion ایجاد می‌شود
- ممکن است دوباره legacy به‌عنوان truth استفاده شود

## 14.3 ریسک Redirect زودتر از readiness
اگر قبل از readiness redirect کنیم:
- کاربر به صفحه‌ای می‌رود که هنوز کار کامل او را انجام نمی‌دهد

## 14.4 ریسک remove کردن client-side logic قبل از تکمیل backend contracts
- UI ممکن است نصفه کار کند
- بعضی tableها خالی یا ناقص شوند

## 14.5 ریسک archive بدون label
اگر صفحه قدیمی فقط بماند ولی برچسب `قدیمی` نداشته باشد:
- کاربر آن را با مرجع نهایی اشتباه می‌گیرد

---

# 15) Rollback Plan برای Decommission

## 15.1 اصل کلی

Rollback در فاز decommission باید reversible و مرحله‌ای باشد.

## 15.2 Rollback Levels

### Level 1 — Undo Redirect
اگر مقصد ERP آماده نبود:
- redirect خاموش شود
- page قدیمی موقتاً read-only باقی بماند

### Level 2 — Re-enable Read-Only Legacy View
اگر compare یا operational visibility لازم شد:
- page قدیمی فقط برای view دوباره در دسترس باشد

### Level 3 — Re-enable Compatibility Adapter
اگر یک surface هنوز به response جدید عادت نکرده بود:
- adapter compatibility موقتاً برگردد

### Level 4 — Stop Decommission Wave
اگر dependency ناشناخته پیدا شد:
- موج decommission متوقف شود
- remove نهایی رخ ندهد

## 15.3 Rule مهم

Rollback نباید Legacy Truth Ownership را برگرداند، مگر در شرایط اضطراری و موقت.  
یعنی:
- view را شاید برگردانیم
- ولی truth ownership را نباید به حالت قدیم برگردانیم مگر آخرین راه‌حل موقت

---

# 16) روش تست معماری Phase 10

## 16.1 Review Checklist

برای پذیرش این Phase باید این سوال‌ها پاسخ روشن داشته باشند:

1. آیا لیست remove/archive/redirect مشخص شده؟
2. آیا مقصد canonical هر surface قدیمی مشخص شده؟
3. آیا deprecation timeline مرحله‌ای تعریف شده؟
4. آیا communication plan ساده و واضح مشخص شده؟
5. آیا policy صفحه‌های legacy در دوره گذار روشن شده؟
6. آیا precondition هر موج decommission مشخص شده؟
7. آیا rollback stageها تعریف شده‌اند؟
8. آیا target UI = ERP panel در کل طرح حفظ شده؟
9. آیا remove path برای client-side accounting logic مشخص شده؟
10. آیا ambiguityهای فاز ۱۰ صریح ثبت شده‌اند؟

## 16.2 سناریوهای تست پیشنهادی

- legacy dashboard opens as read-only and marked `قدیمی`
- redirect from legacy ledger page lands in ERP target surface
- no legacy accounting write action remains enabled
- ERP panel handles canonical workflow without needing legacy page
- rollback of one redirect wave works in staging

---

# 17) ارزیابی انجام Taskهای Phase 10 نسبت به Roadmap

## 17.1 Taskهای Phase 10 در Roadmap

طبق `ERP_REFACTOR_ROADMAP.md`، Phase 10 شامل این موارد بود:
- تعیین لیست بخش‌هایی که باید حذف کامل شوند
- تعیین لیست بخش‌هایی که باید archive شوند
- تعیین لیست بخش‌هایی که باید redirect شوند
- تعیین deprecation timeline
- تعیین communication plan برای users/admins

## 17.2 وضعیت این artefact

| Task | وضعیت |
|---|---|
| لیست remove | ✅ انجام شد |
| لیست archive | ✅ انجام شد |
| لیست redirect | ✅ انجام شد |
| deprecation timeline | ✅ انجام شد |
| communication plan | ✅ انجام شد |
| rollback structure | ✅ انجام شد |
| ambiguity register | ✅ انجام شد |

## 17.3 Definition of Done Phase 10

Phase 10 زمانی Done تلقی می‌شود که:
1. decommission map برای componentهای اصلی وجود داشته باشد ✅
2. legacy pages policy روشن باشد ✅
3. redirect/archive/remove strategy مشخص شده باشد ✅
4. communication plan مشخص شده باشد ✅
5. review ambiguityهای باز قبل از اجرای واقعی انجام شده باشد ⏳

### نتیجه
از منظر **مستندسازی معماری و برنامه‌ریزی بازنشستگی Legacy**، Phase 10 در این artefact **شروع و تدوین شده است**؛  
اما از منظر **اجرای واقعی** هنوز نیازمند تصمیم روی چند ambiguity عملیاتی و سطح visibility/remove timing است.

---

# 18) Ambiguity Register فاز ۱۰

> این بخش باید قبل از اجرای واقعی decommission یا قبل از فاز بعد مرور شود.

## 18.1 `page-categories.php` و `wp_cptt_fin_categories` دقیقاً چه fate نهایی دارند؟

### توضیح ساده
هنوز کاملاً روشن نیست categoryهای قدیمی فقط برچسب موقت هستند یا باید surface مشخصی در ERP داشته باشند.

### وضعیت
**نیاز به تصمیم**

---

## 18.2 آیا بعضی pageهای legacy بهتر است redirect شوند یا فقط hidden/read-only بمانند؟

### توضیح ساده
برای بعضی صفحه‌ها شاید redirect بهتر باشد، برای بعضی شاید hidden بهتر باشد.

### وضعیت
**نیاز به تصمیم اجرایی**

---

## 18.3 visibility صفحه‌های legacy read-only در محیط staging/production برای چه roleهایی باشد؟

### توضیح ساده
باید معلوم شود چه کسانی هنوز اجازه دیدن صفحه‌های قدیمی را داشته باشند.

### وضعیت
**نیاز به تصمیم**

---

## 18.4 communication به کاربران نهایی فقط admin notice باشد یا help panel / onboarding هم لازم است؟

### توضیح ساده
باید تصمیم بگیریم فقط یک پیام کافی است یا راهنمای بیشتر هم لازم داریم.

### وضعیت
**نیاز به تصمیم**

---

## 18.5 remove نهایی `assets/js/finance.js` و `assets/css/finance.css` در چه موجی انجام شود؟

### توضیح ساده
تا وقتی pageهای قدیمی زنده‌اند این فایل‌ها لازم‌اند، ولی زمان حذف نهایی باید دقیق شود.

### وضعیت
**نیاز به تصمیم اجرایی**

---

## 18.6 آیا بعضی compatibility adapterها باید یک release بیشتر زنده بمانند؟

### توضیح ساده
شاید بعضی adapterهای موقت را لازم باشد کمی بیشتر نگه داریم تا remove امن‌تر شود.

### وضعیت
**نیاز به تصمیم**

---

# 19) جمع‌بندی نهایی Phase 10

مهم‌ترین خروجی Phase 10 این است که از اینجا به بعد، Legacy نباید فقط «قدیمی» باشد؛ باید **برنامه‌ریزی‌شده و کنترل‌شده** از مدار اصلی خارج شود.

### نتیجه‌های کلیدی
- اجزای remove/archive/redirect مشخص شدند
- pageهای legacy به‌عنوان surface گذار تعریف شدند
- timeline مرحله‌ای decommission مشخص شد
- communication plan برای ادمین‌ها و کاربران تعریف شد
- rollback مرحله‌ای برای decommission طراحی شد
- target UI = ERP Accounting Panel دوباره تثبیت شد

### اصل نهایی این فاز

```text
Retire legacy gradually.
Do not let legacy stay authoritative.
Keep ERP as the final home.
```

و به زبان ساده‌تر:

```text
سیستم قدیمی را آرام‌آرام کنار می‌گذاریم،
نمی‌گذاریم دوباره مرجع اصلی شود،
و خانه‌ی نهایی همه‌چیز همان پنل ERP می‌ماند.
```

---

**پایان گزارش Phase 10**
