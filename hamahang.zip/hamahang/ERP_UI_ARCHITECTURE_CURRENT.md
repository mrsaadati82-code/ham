# معماری فعلی UI پنل مالی ERP

این فایل برای رفع سردرگمی مسیرها و فایل‌ها نوشته شده است.

## 1) صفحه‌ی واقعی ERP از کجا لود می‌شود؟

صفحه‌ی زیر:

`/wp-admin/admin.php?page=cptt-finance-erp`

از این فایل تغذیه می‌شود:

- `includes/class-cptt-finance-erp.php`

و این فایل در زمان اجرا فقط این assetها را enqueue می‌کند:

- `assets/finance-ui/fonts.css`
- `assets/finance-ui/app.css`
- `assets/finance-ui/app.js`

## 2) پس منبع اصلی UI فعلی چیست؟

در وضعیت فعلی پروژه، **رابط کاربری زنده‌ای که الان در ERP می‌بینید، عملاً همین سه فایل بالا است**؛
به‌خصوص:

- `assets/finance-ui/app.js`
- `assets/finance-ui/app.css`

یعنی اگر هدف این باشد که **همان UI فعلی** حفظ شود و فقط قابلیت‌ها/منطق‌ها روی همان اصلاح شوند،
مسیر واقعی همین‌ها هستند.

## 3) پوشه‌ی `ui-src/` چه بود؟

`ui-src/` یک تلاش برای نگه‌داشتن source های React/TypeScript برای بازسازی آینده بود، اما:

- در runtime وردپرس استفاده نمی‌شد
- از داخل PHP لود نمی‌شد
- ناقص بود
- source کامل UI فعلی را نداشت
- حتی فایل‌های کلیدی مثل `App.tsx` و پوشه‌های کامل component/context در آن موجود نبودند

پس این پوشه **source معتبر UI فعلی نبود** و بیشتر باعث چندمسیره شدن معماری می‌شد.

## 4) نتیجه‌ی بررسی

### لازم برای اجرا:
- `includes/class-cptt-finance-erp.php`
- `assets/finance-ui/app.js`
- `assets/finance-ui/app.css`
- `assets/finance-ui/fonts.css`

### لازم نبود / حذف شد:
- `ui-src/`

## 5) پیشنهاد ادامه‌ی کار

اگر تصمیم این است که UI دقیقاً شبیه صفحه‌ی فعلی بماند، ادامه‌ی توسعه باید بر این مبنا باشد:

1. **Backend / AJAX / منطق** در `includes/class-cptt-finance-erp.php`
2. **UI زنده ERP** در `assets/finance-ui/app.js` و `assets/finance-ui/app.css`
3. تا وقتی source کامل و واقعی همین UI بازسازی نشده، نباید دوباره یک مسیر موازی مثل `ui-src/` ساخته شود

## 6) جمع‌بندی یک‌خطی

**source زنده‌ی ERP فعلی = `assets/finance-ui/*` ، نه `ui-src/`.**
