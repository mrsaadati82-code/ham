# PHASE_4_REPORT

> Phase 4 Execution Artifact  
> Program: ERP Refactor / Accounting Unification  
> Source references: `ACCOUNTING_SYSTEM_ANALYSIS.md`, `ERP_ARCHITECTURE.md`, `ERP_REFACTOR_ROADMAP.md`, `PHASE_0_REPORT.md`, `PHASE_1_REPORT.md`, `PHASE_2_REPORT.md`, `PHASE_3_REPORT.md`  
> Mode: **No code change / No behavior change / Reporting Architecture Redesign only**

---

# 0) هدف این گزارش

این سند، شروع اجرایی **Phase 4 — Reporting Architecture Redesign** است و فقط روی این موارد تمرکز دارد:

1. تعیین **source رسمی هر report**
2. تعریف **read model strategy** برای reportها
3. تعیین سیاست **snapshot vs on-demand**
4. طراحی **API contract** برای لایه گزارش‌گیری
5. تعیین **caching policy**
6. تعریف **reconciliation rules** بین reportها
7. تعریف **فرمول‌های رسمی** برای report layer
8. تعیین dependency chain رسمی از `Voucher` تا reportها
9. ثبت ambiguityها و decision pointهای باز برای فازهای بعدی

> این سند عمداً هیچ تغییری در کد، schema، query، migration یا رفتار runtime ایجاد نمی‌کند.

---

# 1) وضعیت شروع Phase 4

## 1.1 مبنای شروع

Phase 4 بر اساس این artefactها ادامه پیدا می‌کند:
- `ACCOUNTING_SYSTEM_ANALYSIS.md`
- `ERP_ARCHITECTURE.md`
- `ERP_REFACTOR_ROADMAP.md`
- `PHASE_0_REPORT.md`
- `PHASE_1_REPORT.md`
- `PHASE_2_REPORT.md`
- `PHASE_3_REPORT.md`

## 1.2 وابستگی به Phase 3

طبق Roadmap، Phase 4 وابسته به Phase 3 است.  
از آنجا که در `PHASE_3_REPORT.md` این موارد formalize شده‌اند:
- posting pipeline رسمی
- تمایز Draft و Posted/Finalized
- جایگاه Journal و GL
- trigger مفهومی refresh گزارش‌ها
- traceability chain
- dimension propagation

این Phase 4 می‌تواند معماری گزارش‌گیری را روی sourceهای رسمی بعد از posting طراحی کند.

## 1.3 وضعیت نسخه و زیپ

این artefact صرفاً مستنداتی است و هیچ تغییر کدی در افزونه ایجاد نمی‌کند؛ بنابراین در این مرحله:
- version bump انجام نشده
- zip نصبی جدید ساخته نشده

---

# 2) اصل بنیادین Reporting Architecture

## 2.1 اصل اصلی

در معماری هدف، **هیچ گزارش مالی نباید مستقیماً از state عملیاتی خام یا محاسبات client-side ساخته شود**.

گزارش‌ها فقط باید از chain رسمی زیر تغذیه شوند:

```text
Posted Voucher
↓
Journal
↓
General Ledger
↓
Trial Balance
↓
Financial Statements / Read Models
↓
Dashboard / Print / API / UI
```

## 2.2 قواعد طلایی Report Layer

1. Frontend فقط **مصرف‌کننده‌ی read model** است
2. Report formulaها باید **server-side و deterministic** باشند
3. هر report فقط **یک source رسمی** دارد
4. هر عدد report باید تا `VoucherRow` قابل ردیابی باشد
5. `_cptt_steps`، `wp_cptt_fin_ledger` و `wp_cptt_ledger` نباید source نهایی reportهای رسمی باشند
6. source report نباید بر اساس حدس، heuristic یا synthetic object ساخته شود

## 2.3 معیار پذیرش معماری گزارش‌گیری

لایه گزارش‌گیری زمانی استاندارد است که:
- یک input حسابداری ثابت، همیشه یک output ثابت بدهد
- همه reportها از dependency chain رسمی پیروی کنند
- اختلاف بین Documents / Journal / GL / TB / P&L / BS با قوانین reconciliation قابل توضیح باشد
- dashboard فقط مصرف‌کننده‌ی outputهای report layer باشد

---

# 3) Source رسمی هر Report

## 3.1 جدول قطعی Source Mapping

| Report | Source رسمی | لایه مبنا |
|---|---|---|
| Documents | `Voucher` + `VoucherRow` | Posting Output |
| Journal | `JournalEntry` | Journal Layer |
| General Ledger | `GeneralLedgerEntry` | GL Layer |
| Subsidiary Ledger | `GeneralLedgerEntry` + dimensions | GL Layer |
| Trial Balance | `TrialBalanceRow` derived from GL | Trial Balance Layer |
| Income Statement | `IncomeStatementRow` derived from TB | Statement Layer |
| Balance Sheet | `BalanceSheetRow` derived from TB | Statement Layer |
| Cash Flow | posted cash-related entries derived from GL / Posted VoucherRows | Cash Flow Layer |
| Aging | receivable/payable balances + due references derived from GL and domain refs | Aging Layer |
| Dashboard KPIs | reporting read models only | Reporting Layer |
| Project Financial View | `ProjectFinancialSnapshot` | Reporting Layer |
| Party Financial View | `PartyFinancialReadModel` | Reporting Layer |
| Treasury Summary | `TreasuryBalanceReadModel` or GL cash-account views | Reporting Layer |

## 3.2 منابع غیرمجاز

این‌ها source نهایی report نیستند:
- `_cptt_steps`
- `wp_cptt_fin_ledger` به‌تنهایی
- `wp_cptt_ledger` به‌تنهایی
- payload خام frontend
- synthetic / virtual voucher ساخته‌شده در UI
- محاسبات ad-hoc در JavaScript client

## 3.3 نتیجه‌ی مهم

حتی اگر legacy data برای migration یا backfill استفاده شود، report layer نهایی باید فقط **خروجی accounting chain استاندارد** را مصرف کند، نه legacy sourceها را به‌طور مستقیم.

---

# 4) Read Model Strategy

## 4.1 تعریف Read Model

در این سند، `Read Model` به معنای مدل یا projectionی است که:
- از source رسمی حسابداری مشتق می‌شود
- برای query/reporting ساخته می‌شود
- مسئول business write نیست
- می‌تواند snapshot، materialized view، cached query result یا on-demand projection باشد

## 4.2 Read Modelهای اصلی Phase 4

### A) DocumentsReadModel
**Source:** `Voucher` + `VoucherRow`  
**هدف:** نمایش اسناد حسابداری، فیلتر، چاپ، export

### B) JournalReadModel
**Source:** `JournalEntry`  
**هدف:** دفتر روزنامه سطری با فیلتر و جمع کل

### C) GeneralLedgerReadModel
**Source:** `GeneralLedgerEntry`  
**هدف:** گردش حساب‌ها و running balance

### D) SubsidiaryLedgerReadModel
**Source:** `GeneralLedgerEntry` + dimensions  
**هدف:** دفتر معین بر اساس party/project/cost center/account

### E) TrialBalanceReadModel
**Source:** aggregation از `GeneralLedgerEntry`  
**هدف:** تراز آزمایشی رسمی

### F) IncomeStatementReadModel
**Source:** `TrialBalanceRow` + account nature mapping  
**هدف:** صورت سود و زیان رسمی

### G) BalanceSheetReadModel
**Source:** `TrialBalanceRow` + account nature mapping  
**هدف:** ترازنامه رسمی

### H) CashFlowReadModel
**Source:** cash-classified posted entries  
**هدف:** جریان نقدی

### I) AgingReadModel
**Source:** GL + due references + party balances  
**هدف:** سررسید مطالبات/بدهی‌ها

### J) DashboardFinancialSnapshot
**Source:** report layer outputs  
**هدف:** کارت‌ها و KPIهای داشبورد

### K) ProjectFinancialSnapshot
**Source:** accounting/reporting layer + dimensions  
**هدف:** وضعیت مالی پروژه بدون تکیه مستقیم بر `_cptt_steps`

### L) PartyFinancialReadModel
**Source:** GL + party dimensions + payables/installments/cheques linkage  
**هدف:** صورت‌حساب طرف حساب، مانده، سررسید، history

### M) TreasuryBalanceReadModel
**Source:** GL cash/bank accounts + treasury mapping  
**هدف:** مانده‌های خزانه و viewهای خلاصه treasury

---

# 5) Snapshot vs On-Demand Strategy

## 5.1 اصل کلی انتخاب Strategy

برای هر report باید مشخص شود:
- آیا query باید **on-demand** ساخته شود؟
- آیا بهتر است **snapshot/materialized read model** داشته باشد؟
- آیا strategy باید **hybrid** باشد؟

این تصمیم باید بر اساس این معیارها گرفته شود:
1. حجم داده
2. frequency of access
3. complexity of aggregation
4. tolerance for slight delay
5. auditability requirements
6. month-end / year-end load

## 5.2 Strategy Matrix

| Report | Strategy target | دلیل |
|---|---|---|
| Documents | On-Demand + cache | data document-oriented و page-based است |
| Journal | On-Demand + cache | line-level query و filter-heavy |
| General Ledger | On-Demand + cache | running balance نیازمند account/date filters است |
| Subsidiary Ledger | On-Demand + cache | dimension-heavy queries |
| Trial Balance | Snapshot preferred / On-Demand fallback | aggregation پرکاربرد و پایه‌ی statements |
| Income Statement | Snapshot from TB preferred | statement-level fast response needed |
| Balance Sheet | Snapshot from TB preferred | statement-level fast response needed |
| Cash Flow | Hybrid | aggregation پیچیده‌تر و مصرف دوره‌ای |
| Aging | Snapshot preferred | due-bucket logic و dashboard/report overlap |
| Dashboard | Snapshot strongly preferred | high-frequency reads |
| Project Financial Snapshot | Snapshot preferred | جایگزین duplicate logic و KPI-heavy |
| Party Financial View | Hybrid | query + snapshot depending on scale |
| Treasury Summary | Snapshot preferred | frequent dashboard/summary usage |

## 5.3 Documents Strategy

### توصیه
- query on-demand از `Voucher` و `VoucherRow`
- caching کوتاه‌مدت یا result caching بر اساس filter set

### دلیل
- اسناد نیازمند pagination، sorting و search هستند
- source آن‌ها document-centric است، نه aggregate-heavy

## 5.4 Journal Strategy

### توصیه
- query on-demand از `JournalEntry`
- cache per filter/page

### دلیل
- Journal line-oriented است
- user معمولاً روی بازه تاریخ، وضعیت، حساب، پروژه، شخص فیلتر می‌زند

## 5.5 General Ledger / Subsidiary Ledger Strategy

### توصیه
- query on-demand از `GeneralLedgerEntry`
- optional running-balance مساعدت‌گر یا cached opening balances

### دلیل
- نیاز به account-specific slicing
- dimension-based filtering
- range-specific running balance

## 5.6 Trial Balance Strategy

### توصیه
- `Snapshot preferred`
- `On-demand fallback` در صورت نیاز یا discrepancy review

### دلیل
- پایه‌ی رسمی statements است
- frequently reused by P&L, BS, dashboard
- نسبت به Journal/GL aggregation سنگین‌تر و پرتکرارتر است

## 5.7 Income Statement / Balance Sheet Strategy

### توصیه
- snapshot یا materialized statement projection بر پایه `TrialBalanceRow`

### دلیل
- statementها باید سریع، ثابت و audit-friendly باشند
- نباید هر بار از raw rows دوباره محاسبه شوند، مگر mode diagnostic

## 5.8 Cash Flow Strategy

### توصیه
- hybrid strategy

### توضیح
- برای بازه‌های کوچک و interactive: on-demand قابل قبول
- برای period close / dashboard / export بزرگ: snapshot یا precomputed projection توصیه می‌شود

## 5.9 Aging Strategy

### توصیه
- snapshot preferred with scheduled refresh or posting-trigger refresh

### دلیل
- bucketهای سررسید برای dashboard و reportها پرتکرارند
- محاسبه صرفاً on-demand در دیتای بزرگ می‌تواند سنگین شود

## 5.10 Dashboard Strategy

### توصیه
- snapshot strongly preferred

### دلیل
- dashboard high-read / low-write summary surface است
- نباید هر بار کل accounting chain را دوباره aggregate کند

## 5.11 Project / Party / Treasury Snapshots

### توصیه
- project: snapshot preferred
- party: hybrid
- treasury: snapshot preferred

### دلیل
- project financial view و treasury summaries معمولاً زیاد خوانده می‌شوند
- party statementها گاهی drill-down عمیق نیاز دارند، پس hybrid منطقی‌تر است

---

# 6) Report API Contract Blueprint

## 6.1 اصل کلی API Contract

API گزارش‌ها باید:
- server-side باشد
- deterministic باشد
- filter contract روشن داشته باشد
- pagination/sorting contract روشن داشته باشد
- metadata کافی برای traceability و export بدهد
- هیچ client-side formula اجباری باقی نگذارد

## 6.2 فیلترهای استاندارد مشترک

تقریباً همه reportها باید بتوانند این فیلترها را بپذیرند، هرجا معنایی داشته باشند:
- `fromDateFa`
- `toDateFa`
- `fiscalYearId`
- `companyId`
- `branchId`
- `status`
- `voucherType`
- `accountId`
- `projectId`
- `partyId`
- `partyRole`
- `costCenterId`
- `currencyCode?`
- `searchText?`
- `page`
- `pageSize`
- `sortBy`
- `sortDirection`

## 6.3 Documents API Contract

### Service owner
- `DocumentsReadService` یا equivalent documents query under voucher/reporting layer

### Request contract
- date filters
- fiscal filters
- status
- voucherType
- project/party/cost center
- search text
- pagination

### Response contract
- `items[]`
- `totalCount`
- `page`
- `pageSize`
- `aggregates`:
  - total vouchers on page / total vouchers filtered
  - total debit
  - total credit
- `trace`:
  - generatedAt
  - source = `Voucher/VoucherRow`

### Item shape مفهومی
- voucher header snapshot
- row count
- total debit / credit
- source trace fields
- status

## 6.4 Journal API Contract

### Source
- `JournalEntry`

### Response should include
- line items
- opening context if applicable
- debit total
- credit total
- pagination metadata
- trace metadata

### Item shape مفهومی
- postingDate
- voucherCode / voucherNo
- accountId / accountCode / accountName
- description
- debit
- credit
- dimensions

## 6.5 General Ledger API Contract

### Source
- `GeneralLedgerEntry`

### Request emphasis
- accountId is usually required or strongly recommended
- date range
- dimension filters

### Response should include
- opening balance
- entries[]
- running balance per line
- debit total
- credit total
- closing balance
- trace metadata

## 6.6 Subsidiary Ledger API Contract

### Source
- `GeneralLedgerEntry` + dimensions

### Request emphasis
- subsidiary account / detail account / party/project filter

### Response should include
- grouped lines
- opening balance
- running balance
- dimension context

## 6.7 Trial Balance API Contract

### Source
- `TrialBalanceRow`

### Response should include
- account rows
- debit total
- credit total
- balance per account
- balance nature or normalized amount
- generatedAt
- snapshotAsOf

## 6.8 Income Statement API Contract

### Source
- `IncomeStatementReadModel`

### Response should include
- revenues section
- expenses section
- gross / operating / net profit fields حسب policy target
- generatedAt
- source = `TrialBalance`

### نکته
جزئیات gross/operating/net profit بسته به chart and business policy در وضعیت فعلی **نیاز به بررسی بیشتر** دارد. حداقل `Revenue`, `Expense`, `Profit` باید رسمی باشد.

## 6.9 Balance Sheet API Contract

### Source
- `BalanceSheetReadModel`

### Response should include
- assets section
- liabilities section
- equity section
- equation check result
- generatedAt
- source = `TrialBalance`

## 6.10 Cash Flow API Contract

### Response should include
- opening cash
- inflows
- outflows
- closing cash
- classification buckets
- generatedAt

## 6.11 Aging API Contract

### Response should include
- party-level balances
- bucket totals:
  - current
  - 1–30
  - 31–60
  - 61–90
  - 90+
- receivable/payable separation
- generatedAt

## 6.12 Dashboard API Contract

### Response should include
- KPI cards
- source metadata per KPI
- freshness metadata
- snapshot timestamp
- optional drill-down links to report endpoints

## 6.13 Contract Rule مهم

هیچ endpoint گزارشی نباید front-end را مجبور کند:
- خودش debit/credit را group کند
- خودش code prefix را تفسیر کند
- خودش Trial Balance بسازد
- خودش P&L یا BS را محاسبه کند

---

# 7) Caching Policy

## 7.1 اصل کلی Cache

Cache در report layer باید:
- deterministic باشد
- invalidation روشن داشته باشد
- stale-but-explainable باشد
- audit trace را مخفی نکند

## 7.2 Cache Levels

### Level A — Query Result Cache
برای reportهای on-demand مانند:
- Documents
- Journal
- GL
- Subsidiary Ledger

### Level B — Snapshot Cache / Materialized Projection
برای reportهای summary مانند:
- Trial Balance
- Income Statement
- Balance Sheet
- Aging
- Dashboard
- Treasury Summary
- ProjectFinancialSnapshot

### Level C — Export Cache / Print Cache
برای PDF/Excel/print outputهای تکراری در بازه کوتاه

## 7.3 Cache Invalidation Triggers

Cache باید حداقل با این eventها invalidate یا mark-dirty شود:
- voucher posted
- voucher reversed
- voucher unfinalized (if allowed)
- fiscal year close
- fiscal year reopen
- payable payment posted
- installment receipt posted
- cheque accounting state causing posting
- invoice to voucher posted

## 7.4 Cache Key Dimensions

هر cache key باید حداقل این مؤلفه‌ها را در نظر بگیرد:
- report type
- date range / as-of date
- fiscalYearId
- companyId / branchId
- dimension filters
- page / pageSize / sort
- version of formula policy if needed

## 7.5 Freshness Policy پیشنهادی

| Report Type | Freshness target |
|---|---|
| Documents / Journal | near-real-time |
| GL / Subsidiary | near-real-time |
| Trial Balance | near-real-time or short-lag |
| P&L / BS | short-lag acceptable if snapshotized |
| Dashboard | short-lag acceptable if disclosed |
| Aging | short-lag acceptable |

## 7.6 Transparency Rule

اگر report snapshot-based است، response باید بتواند این metadata را برگرداند:
- `generatedAt`
- `asOf`
- `freshnessState`
- `sourceLayer`

---

# 8) Reconciliation Rules بین Reportها

## 8.1 هدف Reconciliation

Reconciliation rules برای این است که report layer فقط «زیبا» نباشد، بلکه **حسابداری‌پذیر و auditable** باشد.

## 8.2 Rule 1 — Documents vs Voucher Totals

```text
Sum(Debit of VoucherRows for posted vouchers in filter scope)
=
Sum(Credit of VoucherRows for posted vouchers in filter scope)
```

### نتیجه
اگر این برقرار نباشد، posting validity زیر سوال است.

## 8.3 Rule 2 — Journal vs Posted VoucherRows

```text
Journal debit total == Posted VoucherRow debit total
Journal credit total == Posted VoucherRow credit total
Journal line count == Posted VoucherRow count (در مدل 1↔1 فعلی)
```

## 8.4 Rule 3 — General Ledger vs Journal

```text
GL debit total == Journal debit total
GL credit total == Journal credit total
```

## 8.5 Rule 4 — Trial Balance vs GL

```text
TB debit total == GL debit total aggregated by account
TB credit total == GL credit total aggregated by account
TB total debit == TB total credit
```

## 8.6 Rule 5 — Income Statement vs Trial Balance

```text
Revenue = TB rows for revenue accounts
Expense = TB rows for expense accounts
Profit = Revenue - Expense
```

## 8.7 Rule 6 — Balance Sheet vs Trial Balance

```text
Assets = balances of asset accounts
Liabilities = balances of liability accounts
Equity = balances of equity accounts
Assets == Liabilities + Equity   [طبق policy period-close interpretation]
```

## 8.8 Rule 7 — Dashboard vs Report Layer

تمام KPIهای داشبورد باید با یکی از report sourceهای رسمی reconcile شوند.

### مثال
- revenue KPI ↔ Income Statement
- treasury balance KPI ↔ TreasuryBalanceReadModel / GL cash balances
- receivable KPI ↔ Aging / receivable balances
- payable KPI ↔ Aging / payable balances

## 8.9 Rule 8 — Project Financial Snapshot vs Accounting Layer

```text
ProjectFinancialSnapshot.customerOutstanding
must reconcile with
receivable balances filtered by project dimension
```

و همین‌طور:
- expert outstanding ↔ expert payable balances / payable projections
- collected amount ↔ receipt-related posted entries filtered by project

## 8.10 Rule 9 — Party Financial View vs GL

```text
Party statement ending balance
must reconcile with
GL balances filtered by partyId/partyRole
```

---

# 9) Official Formulas for Report Layer

## 9.1 اصل تغییر مهم نسبت به وضع موجود

در معماری هدف، formulaها نباید بر first digit code به‌عنوان source semantic نهایی متکی باشند.  
source semantic نهایی باید `accountNature` باشد.

### وضعیت انتقالی
تا قبل از canonical master data کامل، ممکن است `accountNature` از prefix derive شود؛ اما report layer باید آن را به‌عنوان **semantic field** مصرف کند، نه raw prefix logic.

## 9.2 Trial Balance Formula

برای هر حساب:

```text
debitTotal = Σ GL.debit
creditTotal = Σ GL.credit
closingBalance = debitTotal - creditTotal
```

## 9.3 Revenue Formula

برای همه accountهایی که `accountNature = revenue`:

```text
RevenueAmount = creditTotal - debitTotal
```

## 9.4 Expense Formula

برای همه accountهایی که `accountNature = expense`:

```text
ExpenseAmount = debitTotal - creditTotal
```

## 9.5 Profit Formula

```text
Profit = Revenue - Expense
```

## 9.6 Asset Formula

برای accountهایی که `accountNature = asset`:

```text
AssetAmount = closingBalance
```

## 9.7 Liability Formula

برای accountهایی که `accountNature = liability`:

```text
LiabilityAmount = -closingBalance
```

## 9.8 Equity Formula

برای accountهایی که `accountNature = equity`:

```text
EquityAmount = -closingBalance
```

## 9.9 Balance Sheet Equation

```text
Assets = Liabilities + Equity
```

## 9.10 Cash Flow Formula (مفهومی)

```text
OpeningCash
+ CashInflows
- CashOutflows
= ClosingCash
```

### Note
classification دقیق operating / investing / financing در وضعیت فعلی **نیاز به بررسی بیشتر** دارد.

## 9.11 Aging Formula (مفهومی)

برای هر party/balance item:
- amount در bucket بر اساس `dueDate` یا equivalent due reference قرار می‌گیرد
- overdue buckets باید mutually exclusive و collectively exhaustive باشند

## 9.12 Treasury Balance Formula

```text
TreasuryBalance(account)
= GL balance of linked treasury account(s)
```

نه:
- raw `fin_ledger` total به‌عنوان report final

---

# 10) Report Dependency Chain

## 10.1 Chain رسمی

```text
Voucher / VoucherRow
↓
JournalEntry
↓
GeneralLedgerEntry
↓
TrialBalanceRow
↓
IncomeStatementRow / BalanceSheetRow
↓
DashboardFinancialSnapshot / ProjectFinancialSnapshot / PartyFinancialReadModel
```

## 10.2 وابستگی هر Report

| Report | Depends On |
|---|---|
| Documents | Voucher/VoucherRow |
| Journal | JournalEntry |
| GL | GeneralLedgerEntry |
| Subsidiary | GeneralLedgerEntry + dimensions |
| TB | GL aggregation |
| P&L | TB |
| BS | TB |
| Dashboard | TB/P&L/BS/Aging/Treasury/Project snapshots |

## 10.3 Dependency Rule

هر report فقط مجاز است از **upstream رسمی خودش** تغذیه شود.  
مثلاً:
- P&L نباید مستقیم از VoucherRows ساخته شود
- Dashboard نباید مستقیم از `_cptt_steps` ساخته شود
- Balance Sheet نباید مستقیم از Journal یا frontend payload ساخته شود

---

# 11) Server-Side Determinism Rules

## 11.1 قاعده‌ی اصلی

یک input accounting scope ثابت باید همیشه output report ثابت بدهد.

## 11.2 عوامل لازم برای determinism

1. source رسمی یکتا
2. formula رسمی یکتا
3. dimension semantics روشن
4. date scope روشن
5. fiscal year scope روشن
6. posted-state-only rule روشن

## 11.3 Posted-State-Only Rule

برای reportهای رسمی:
- draft voucherها نباید source final report باشند
- فقط posted/finalized accounting state باید report را تغذیه کند

## 11.4 As-Of Rule

هر report باید بتواند scope زمانی خود را روشن کند:
- range-based (`from`, `to`)
- as-of-date
- fiscal-year scoped

---

# 12) Policy برای Export / Print / UI Consumption

## 12.1 Export Rule

Excel/PDF/CSV/Print باید دقیقاً از همان report layer رسمی تغذیه شوند، نه از query یا aggregation موازی.

## 12.2 Print Rule

Print output باید metadata کافی داشته باشد:
- generatedAt
- filters applied
- source layer
- fiscal year / date range
- totals

## 12.3 UI Consumption Rule

Frontend فقط باید:
- query parameters بفرستد
- response آماده‌ی report بگیرد
- render کند

Frontend نباید:
- rows را دوباره group کند
- totals را مستقل بسازد
- statement formulaها را اعمال کند

---

# 13) Diagnostic / Audit Mode Design

## 13.1 چرا لازم است؟

در refactorهای مالی، علاوه بر report normal mode، یک diagnostic mode برای reconciliation و audit مفید است.

## 13.2 قابلیت‌های مطلوب Diagnostic Mode

- نمایش `sourceLayer`
- نمایش `generatedAt`
- نمایش `snapshotAsOf`
- نمایش counts:
  - vouchers
  - rows
  - journal lines
  - GL lines
- نمایش reconciliation checks
- نمایش variance warnings

## 13.3 وضعیت فعلی

پیاده‌سازی actual diagnostic mode در این فاز انجام نمی‌شود؛ فقط به‌عنوان contract معماری پیشنهاد می‌شود.

---

# 14) Ambiguity Register برای Phase 4

## 14.1 Journal materialization
- اگر Journal table فیزیکی نشود، آیا query performance برای reportهای بزرگ کافی خواهد بود؟
- **نتیجه:** نیاز به بررسی بیشتر

## 14.2 GL materialization
- اگر GL table فیزیکی نشود، آیا Trial Balance / Statements در scale بالا performant خواهند بود؟
- **نتیجه:** نیاز به بررسی بیشتر

## 14.3 Statement granularity
- آیا P&L و BS فقط summary-level باشند یا account-detail/full-tree views نیز canonical شوند؟
- **نتیجه:** نیاز به بررسی بیشتر

## 14.4 Cash Flow classification depth
- آیا cash flow فقط inflow/outflow summary باشد یا full operating/investing/financing classification داشته باشد؟
- **نتیجه:** نیاز به بررسی بیشتر

## 14.5 Aging due reference model
- due reference canonical دقیق از کدام مدل/field می‌آید؟ payable/installment/invoice/cheque/custom due refs؟
- **نتیجه:** نیاز به بررسی بیشتر

## 14.6 Dashboard freshness tolerance
- چه مقدار lag برای snapshot dashboard قابل قبول است؟
- **نتیجه:** نیاز به بررسی بیشتر

## 14.7 Multi-currency reporting depth
- statementها و ledger reports باید single base currency باشند یا parallel display currency support داشته باشند؟
- **نتیجه:** نیاز به بررسی بیشتر

## 14.8 Project snapshot accounting formula depth
- پروژه‌ها باید فقط receivable/paid/profit snapshot داشته باشند یا WIP و profitability layers کامل‌تر هم canonical شوند؟
- **نتیجه:** نیاز به بررسی بیشتر

---

# 15) روش تست معماری Phase 4

## 15.1 Review Checklist

برای پذیرش این Phase باید این سوال‌ها پاسخ روشن داشته باشند:

1. آیا برای هر report یک source رسمی تعیین شده است؟
2. آیا read modelهای لازم مشخص شده‌اند؟
3. آیا strategy هر report بین snapshot/on-demand مشخص شده است؟
4. آیا API contractهای report layer طراحی شده‌اند؟
5. آیا caching/invalidation policy تعریف شده است؟
6. آیا reconciliation rules بین reportها مشخص شده است؟
7. آیا formulaهای رسمی report layer ثبت شده‌اند؟
8. آیا dependency chain رسمی از Voucher تا Dashboard روشن شده است؟
9. آیا determinism rule رسمی شده است؟
10. آیا ambiguityها صریح ثبت شده‌اند؟

## 15.2 Matrix Validation پیشنهادی

باید در فازهای اجرایی/تستی این کنترل‌ها بررسی شوند:
- Journal totals == posted VoucherRow totals
- GL totals == Journal totals
- TB debit == TB credit
- P&L = revenue - expense
- BS assets == liabilities + equity
- Dashboard KPIs == corresponding report outputs
- Project snapshot == accounting-filtered project balances
- Party snapshot == GL filtered balances

---

# 16) ارزیابی انجام Taskهای Phase 4 نسبت به Roadmap

## 16.1 Taskهای Phase 4 در Roadmap

طبق `ERP_REFACTOR_ROADMAP.md`، Phase 4 شامل این موارد بود:
- تعریف source رسمی هر report
- تعریف read modelهای لازم
- تعیین snapshot strategy یا on-demand strategy
- طراحی API contract برای report services
- طراحی caching policy
- تعریف reconciliation rules بین reports
- تعریف official formulas

## 16.2 وضعیت این artefact

| Task | وضعیت |
|---|---|
| source رسمی هر report | ✅ انجام شد |
| read modelهای لازم | ✅ انجام شد |
| snapshot vs on-demand strategy | ✅ انجام شد |
| API contract گزارش‌ها | ✅ در سطح معماری انجام شد |
| caching policy | ✅ انجام شد |
| reconciliation rules | ✅ انجام شد |
| official formulas | ✅ انجام شد |
| ambiguity register | ✅ انجام شد |

## 16.3 Definition of Done Phase 4

Phase 4 زمانی Done تلقی می‌شود که:
1. هر report فقط یک source رسمی داشته باشد ✅
2. dependency chain reportها رسمی شده باشد ✅
3. formulaهای report layer صریح شده باشند ✅
4. strategy snapshot/on-demand روشن شده باشد ✅
5. API contractهای report layer تعریف شده باشند ✅
6. review معماری/کسب‌وکار روی ambiguityهای باز انجام شده باشد ⏳

### نتیجه
از منظر **مستندسازی معماری**، Phase 4 در این artefact **شروع و تدوین شده است**؛  
اما از منظر **تصویب نهایی اجرایی** هنوز نیازمند review درباره materialization، scale، aging model و multi-currency depth است.

---

# 17) خروجی مورد انتظار برای Phase 5

Phase 5 باید مستقیماً بر اساس همین سند ادامه پیدا کند و این موارد را formalize کند:

1. شناسایی دقیق entry pointهای legacy
2. تعیین Keep / Wrap / Replace / Remove برای هر flow legacy
3. طراحی Anti-Corruption Layer
4. تعیین adapter strategy بین legacy و target services
5. تعیین storageهای transitional

## 17.1 وابستگی مستقیم Phase 5 به این سند
- چون report sourceهای رسمی اکنون مشخص شده‌اند، در Phase 5 می‌توان دقیق‌تر گفت:
  - کدام legacy read path باید حذف شود
  - کدام legacy report path باید wrap شود
  - کدام client-side aggregation باید remove شود

---

# 18) جمع‌بندی نهایی Phase 4

مهم‌ترین خروجی Phase 4 این است که از این نقطه به بعد، هیچ report مالی نباید «منبع مبهم» داشته باشد.

### نتیجه‌های کلیدی
- source رسمی همه reportهای اصلی تعیین شد
- read modelهای لازم تعریف شدند
- strategy snapshot/on-demand برای هر خانواده report مشخص شد
- API contractهای report layer در سطح معماری تعریف شدند
- caching/invalidation policy رسمی شد
- reconciliation matrix بین reportها تعریف شد
- formulaهای رسمی از prefix-based raw logic به semantic `accountNature` منتقل شدند

### اصل نهایی این فاز

```text
No Financial Report Without Official Source
```

و به زبان عملیاتی:

```text
One Posted Accounting Chain
↓
One Reporting Layer
↓
Deterministic Reports
↓
Consistent Dashboard
```

---

**پایان گزارش Phase 4**
