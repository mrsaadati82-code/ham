# ACCOUNTING_SYSTEM_ANALYSIS

> وضعیت تحلیل: **Reverse Engineering / Audit Documentation**
>
> دامنه‌ی تحلیل: سیستم حسابداری موجود در پروژه‌ی `ccptt` بر اساس **کد فعلی موجود در workspace**.
>
> محدودیت‌ها:
> - این تحلیل فقط مبتنی بر **کد و ساختار فایل‌ها** است.
> - هیچ Query در محیط واقعی WordPress اجرا نشده است.
> - هیچ Migration در این تحلیل اجرا نشده است.
> - فایل `assets/finance-ui/app.js` **bundle minified** است؛ بخش frontend ERP از روی آن Reverse Engineer شده و بعضی نام‌ها در آن **غیرمعنادار / Minified** هستند.
> - هرجا قطعیت پایین باشد، صراحتاً با «**نامشخص**» یا «**نیاز به بررسی بیشتر**» مشخص شده است.

---

## 0) خلاصه اجرایی (Executive Summary)

سیستم حسابداری پروژه **تک‌منبعی (Single Source of Truth)** نیست و در وضعیت فعلی از چند لایه‌ی داده و چند مسیر محاسباتی موازی تشکیل شده است:

1. **لایه‌ی پروژه / واقعیت کسب‌وکار**
   - `wp_posts` با `post_type = cptt_project`
   - `post_meta['_cptt_steps']`
   - اطلاعات اولیه‌ی مالی پروژه (cost / paid / expert_paid / exp_to_expert / extra_finance) عملاً اینجاست.

2. **لایه‌ی لجر مالی مدرن**
   - `wp_cptt_fin_accounts`
   - `wp_cptt_fin_categories`
   - `wp_cptt_fin_ledger`
   - این لایه بیشتر برای خزانه، درآمد/هزینه، انتقال، اقساط، پرداختنی‌ها و داشبورد مالی legacy استفاده می‌شود.

3. **لایه‌ی اسناد ERP**
   - `wp_cptt_erp_vouchers`
   - `wp_cptt_erp_voucher_rows`
   - گزارش‌های استاندارد ERP (اسناد، دفتر روزنامه، دفتر کل، معین، تراز آزمایشی، سود و زیان، ترازنامه) عمدتاً بر این لایه بنا شده‌اند.

4. **لایه‌ی لجر قدیمی پروژه/تسویه**
   - `wp_cptt_ledger`
   - برای `expert_payout`, `expert_manual_payout`, `customer_card_payment` و بعضی عملیات کلاسیک استفاده می‌شود.

5. **لایه‌های Option-based / Array-based**
   - Companies, Branches, Fiscal Years, Cost Centers, COA, Locks, Permissions, Rates, Webhooks, Recurring, …
   - عمدتاً در `wp_options` ذخیره می‌شوند.

### نتیجه‌ی معماری
- **Journal** جدول مستقل ندارد؛ یک **View / Derived Report** روی `VoucherRow` هاست.
- **Ledger** در پروژه دو معنا دارد:
  - `wp_cptt_fin_ledger` = لجر مالی مدرن
  - `wp_cptt_ledger` = لجر قدیمی پروژه/تسویه
- **Trial Balance / Income Statement / Balance Sheet** جدول یا View SQL مستقل ندارند؛ در frontend ERP به‌صورت **client-side aggregation** روی voucher rows محاسبه می‌شوند.
- سیستم به استاندارد دوبل‌انتری نزدیک شده، اما هنوز از نظر معماری، **چندمنبعی** است.

---

# 1) ساختار پروژه (Accounting-Related File Inventory)

## 1.1 فایل‌های اصلی شناسایی‌شده

| مسیر فایل | وظیفه | وابسته به | توسط چه چیزی استفاده می‌شود |
|---|---|---|---|
| `client-project-tracker.php` | Bootstrap افزونه، `require_once` کلاس‌ها، activation/deactivation hooks، versioning | تمام کلاس‌های include شده | WordPress plugin loader |
| `includes/class-cptt-core.php` | هسته‌ی دامنه: CPTها، متاها، جدول‌های پایه، `cptt_ledger`, `cptt_invoices`, `activity_log`, Jalali helpers | WordPress core APIs | Admin, Expert, Payment, Finance ERP, Finance |
| `includes/class-cptt-admin.php` | صفحه‌ی کلاسیک «حساب و کتاب»، تسویه‌ی مرحله‌ای، quick pay کلاسیک، متاباکس‌های پروژه، نگهداری `_cptt_steps` | `CPTT_Core`, `CPTT_Expert`, `CPTT_Bale` | داشبورد ادمین کلاسیک، `CPTT_Finance_ERP` (از hookها)، `CPTT_Finance` (از hookها) |
| `includes/class-cptt-expert.php` | داشبورد کارشناس، مدیریت پروژه از دید کارشناس، ویرایش `_cptt_steps`, آمار کارشناس | `CPTT_Core` | Frontend/expert dashboard |
| `includes/class-cptt-finance.php` | زیرسیستم مالی legacy/standalone: accounts, categories, finance ledger, dashboard, receivables, treasury, transactions, payouts | `CPTT_Core`, `CPTT_Currency` | منوهای `cptt-finance-*`, همچنین ERP bridge از tableهای آن استفاده می‌کند |
| `includes/class-cptt-finance-erp.php` | هسته‌ی ERP حسابداری: vouchers, rows, COA, reports, locks, FY close, mapping, invoices ERP, APIs, bridge React | `CPTT_Finance`, `CPTT_Core`, `CPTT_Admin`, `CPTT_Currency` | صفحه‌ی `admin.php?page=cptt-finance-erp`, REST API, cron, چاپ، integration pages |
| `includes/class-cptt-currency.php` | مدیریت واحد نمایش پول (Display-only)، تبدیل و format | WordPress options | Finance legacy، ERP، UIها |
| `includes/class-cptt-payment.php` | سیستم پرداخت/رسید، apply payment به پروژه، receipt approval | `CPTT_Core`, `CPTT_Bale` | صفحه پرداخت‌ها، فرآیند پرداخت عمومی، پروژه‌ها |
| `includes/finance/page-dashboard.php` | UI PHP صفحه‌ی legacy dashboard مالی | `CPTT_Finance` | `CPTT_Finance::render_dashboard_page()` |
| `includes/finance/page-receivables.php` | UI PHP صفحه‌ی مطالبات مشتریان legacy | `CPTT_Finance`, `CPTT_Core` | `CPTT_Finance::render_receivables_page()` |
| `includes/finance/page-payouts.php` | UI PHP صفحه‌ی تسویه کارشناسان legacy | `CPTT_Core`, `CPTT_Finance` | `CPTT_Finance::render_payouts_page()` |
| `includes/finance/page-transactions.php` | UI PHP صفحه‌ی درآمد/هزینه legacy | `CPTT_Finance` | `CPTT_Finance::render_transactions_page()` |
| `includes/finance/page-treasury.php` | UI PHP صفحه‌ی خزانه‌داری legacy | `CPTT_Finance` | `CPTT_Finance::render_treasury_page()` |
| `includes/finance/page-ledger.php` | UI PHP صفحه‌ی گردش حساب legacy | `CPTT_Finance`, `CPTT_Core` | `CPTT_Finance::render_ledger_page()` |
| `includes/finance/page-categories.php` | UI PHP صفحه‌ی دسته‌بندی‌های مالی | `CPTT_Finance` | `CPTT_Finance::render_categories_page()` |
| `assets/js/finance.js` | JS صفحات legacy مالی (CRUD، chart، datepicker، transfer، transaction modal) | DOM صفحات `includes/finance/*`, localized object `CPTT_FIN` | صفحات legacy `cptt-finance-*` |
| `assets/css/finance.css` | CSS صفحات legacy مالی | — | صفحات legacy `cptt-finance-*` |
| `assets/finance-ui/app.js` | Bundle minified رابط ERP (React/Tailwind)؛ شامل screens، filters، formulas report، journal, vouchers, treasury, receivables, … | `window.CPTTF_ERP`, AJAX endpoints backend | صفحه‌ی ERP جدید |
| `assets/finance-ui/app.css` | CSS bundle ERP | — | صفحه‌ی ERP جدید |
| `assets/finance-ui/fonts.css` | فونت‌های مورد استفاده در ERP | asset fonts | صفحه‌ی ERP جدید |

## 1.2 فایل‌های کمکی ولی مؤثر بر حسابداری

| مسیر فایل | نقش در سیستم حسابداری |
|---|---|
| `includes/class-cptt-analytics.php` | گزارش بهره‌وری کارشناسان و بعضی تحلیل‌های مبتنی بر `_cptt_steps` |
| `includes/class-cptt-bale.php` | اعلان‌های مالی / ارتباطی (مشتری/کارشناس) در بعضی eventهای مالی |
| `includes/class-cptt-reminders.php` | یادآوری‌ها؛ مستقیم منبع حسابداری نیست، ولی با due date ها همپوشانی دارد |

## 1.3 جمع‌بندی لایه‌ها

### لایه legacy مالی
- `class-cptt-finance.php`
- `includes/finance/page-*.php`
- `assets/js/finance.js`
- `assets/css/finance.css`

### لایه ERP مالی
- `class-cptt-finance-erp.php`
- `assets/finance-ui/app.js`
- `assets/finance-ui/app.css`
- `assets/finance-ui/fonts.css`

### لایه هسته پروژه/تسویه
- `class-cptt-core.php`
- `class-cptt-admin.php`
- `class-cptt-expert.php`
- `class-cptt-payment.php`

---

# 2) مدل‌های داده (Data Models)

> **مهم:** بعضی مدل‌ها جدول مستقل دارند، بعضی فقط `option array` هستند، بعضی فقط **Derived/Virtual Model** هستند.

## 2.1 Account (Legacy Treasury Account)

**منبع:** `wp_cptt_fin_accounts`  
**تعریف:** `CPTT_Finance::install_tables()`

| فیلد | نوع داده | توضیح |
|---|---|---|
| `id` | BIGINT UNSIGNED PK AI | شناسه حساب |
| `name` | VARCHAR(190) | نام حساب |
| `type` | VARCHAR(20) | `cash` / `bank` |
| `bank_name` | VARCHAR(190) NULL | نام بانک |
| `account_number` | VARCHAR(60) NULL | شماره حساب |
| `iban` | VARCHAR(40) NULL | شبا |
| `card_number` | VARCHAR(40) NULL | کارت |
| `initial_balance` | DECIMAL(20,2) | مانده اولیه |
| `currency` | VARCHAR(10) | پیش‌فرض `IRT` |
| `color` | VARCHAR(20) | رنگ UI |
| `icon` | VARCHAR(20) | آیکن |
| `status` | TINYINT | 1 فعال / 0 غیرفعال |
| `meta` | LONGTEXT NULL | متادیتا |
| `created_by` | BIGINT | کاربر ایجادکننده |
| `created_at` | INT | timestamp |

**کلیدها / ایندکس‌ها**
- `PRIMARY KEY (id)`
- `KEY type_idx (type)`
- `KEY status_idx (status)`

**روابط**
- یک Account ← چند `FinanceLedgerRow`
- map به CoA از طریق `OPT_TREASURY_COA_MAP` یا fallback mapping

**نحوه استفاده**
- خزانه‌داری legacy
- ERP treasuryAccounts bootstrap
- انتخاب حساب بانکی در دریافت/پرداخت/اقساط/پرداختنی‌ها
- Bank reconciliation
- cash flow

---

## 2.2 AccountType

**در سیستم فعلی یک مدل واحد و صریح ندارد.** سه مفهوم موازی وجود دارد:

### الف) نوع حساب خزانه
- در `wp_cptt_fin_accounts.type`
- مقادیر: `cash`, `bank`

### ب) نوع node در CoA
- در مدل CoA option/table row representation
- مقادیر: `group`, `general`, `subsidiary`, `detail`

### ج) گروه حسابداری بر اساس prefix کد حساب
- `1` = دارایی جاری
- `2` = دارایی غیرجاری
- `3` = بدهی
- `4` = حقوق صاحبان سهام
- `5` = درآمد
- `6` = هزینه

**نتیجه:**  
`AccountType` به‌صورت domain model صریح و واحد وجود ندارد؛ **نامشخص / پراکنده** است.

---

## 2.3 Chart of Accounts (COA Node)

**منبع:** `wp_options` → `cpttf_erp_coa_nodes`  
**fallback:** `default_coa()` در `CPTT_Finance_ERP`

| فیلد | نوع داده | توضیح |
|---|---|---|
| `id` | string | شناسه منطقی مثل `a1_2_1` |
| `code` | string | کد حساب |
| `name` | string | نام حساب |
| `type` | string | `group/general/subsidiary/detail` |
| `parentId` | string/null | والد در درخت |
| `balance` | number | مانده محاسبه‌ای (در runtime) |

**کلیدها**
- کلید دیتابیسی مستقل ندارد (option array)

**روابط**
- tree parent-child
- `VoucherRow.accountId` به `COA.id` اشاره می‌کند
- `map_account()` روی این model resolve می‌شود

**نحوه استفاده**
- اسناد حسابداری ERP
- دفتر روزنامه/کل/معین/تراز/P&L/BS
- mapping حساب‌های پیش‌فرض
- FY closing/opening

---

## 2.4 Voucher

**منبع اصلی:** `wp_cptt_erp_vouchers`  
**fallback legacy:** `wp_options` → `cpttf_erp_vouchers`

| فیلد | نوع داده | توضیح |
|---|---|---|
| `id` | VARCHAR(64) PK | شناسه سند |
| `voucher_number` | BIGINT | شماره عددی |
| `voucher_code` | VARCHAR(64) | کد نمایشی سند |
| `voucher_type` | VARCHAR(16) | `JV/RV/PV/TV/CV/OV` |
| `date_fa` | VARCHAR(40) | تاریخ شمسی |
| `description` | TEXT | شرح سند |
| `status` | VARCHAR(32) | وضعیت سند |
| `company_id` | VARCHAR(64) | شرکت |
| `branch_id` | VARCHAR(64) | شعبه |
| `fiscal_year_id` | VARCHAR(64) | سال مالی |
| `currency` | VARCHAR(16) | ارز |
| `exchange_rate` | DECIMAL | نرخ تبدیل |
| `created_by` | VARCHAR(190) | ثبت‌کننده |
| `approved_by_accountant` | VARCHAR(190) | تأیید حسابدار |
| `approved_by_manager` | VARCHAR(190) | تأیید مدیر مالی |
| `approved_by_ceo` | VARCHAR(190) | تأیید مدیرعامل |
| `is_auto_generated` | TINYINT | خودکار یا دستی |
| `source_type` | VARCHAR(64) | منبع کسب‌وکاری |
| `ref_type` | VARCHAR(64) | نوع مرجع |
| `ref_id` | BIGINT | شناسه مرجع |
| `created_at` | INT | timestamp |

**ایندکس‌ها** (طبق migration)
- `PRIMARY KEY (id)`
- `KEY voucher_number_idx`
- `KEY voucher_code_idx`
- `KEY voucher_type_idx`
- `KEY status_idx`
- `KEY date_idx`
- `KEY ref_idx (ref_type, ref_id)`
- `KEY fy_idx`

**روابط**
- Voucher 1→N VoucherRow
- Voucher → FiscalYear / Company / Branch (logical relation)

**نحوه استفاده**
- اسناد حسابداری ERP
- مبنای اصلی reportهای ERP
- basis برای COA balances
- basis برای FY close/opening
- source برای trial balance / P&L / BS / journal / ledgers

---

## 2.5 VoucherItem / VoucherRow

**منبع:** `wp_cptt_erp_voucher_rows`

| فیلد | نوع داده | توضیح |
|---|---|---|
| `id` | BIGINT PK AI | شناسه ردیف |
| `voucher_id` | VARCHAR(64) | FK منطقی به Voucher.id |
| `row_no` | INT | شماره ردیف |
| `account_id` | VARCHAR(64) | شناسه CoA |
| `account_name` | VARCHAR(190) | نام snapshot شده |
| `debit` | DECIMAL(20,2) | مبلغ بدهکار |
| `credit` | DECIMAL(20,2) | مبلغ بستانکار |
| `description` | TEXT | شرح ردیف |
| `project_id` | BIGINT NULL | پروژه |
| `customer_id` | BIGINT NULL | مشتری |
| `expert_id` | BIGINT NULL | کارشناس |
| `cost_center_id` | VARCHAR(64) NULL | مرکز هزینه |

**ایندکس‌ها**
- `PRIMARY KEY (id)`
- `KEY voucher_idx (voucher_id)`
- `KEY account_idx (account_id)`
- `KEY project_idx (project_id)`
- `KEY customer_idx (customer_id)`
- `KEY expert_idx (expert_id)`
- `KEY cost_center_idx (cost_center_id)`

**روابط**
- هر VoucherItem متعلق به یک Voucher است
- به CoA node اشاره می‌کند
- ممکن است به Project / Customer / Expert / CostCenter متصل باشد

**نحوه استفاده**
- همه reportهای ERP روی همین ردیف‌ها می‌چرخند
- party statement از همین rowها می‌سازد
- P&L / BS / trial / journal / ledger all derive from rows

---

## 2.6 Journal

**مدل فیزیکی مستقل ندارد.**  
**نوع مدل:** Derived / Report Model

**تعریف عملیاتی در UI ERP:**
- در `assets/finance-ui/app.js`، component minified `pj`
- هر VoucherRow flatten می‌شود و همراه با فیلدهای سند (`voucherCode`, `voucherNumber`, `date`, `vDescription`, `status`) نمایش داده می‌شود

**منبع داده**
- `vouchers` payload از `ajax_full_bootstrap()` / `ajax_bootstrap_reports()`
- که خودش از `get_vouchers()` می‌آید

**رابطه**
- `Journal = Flatten(Voucher × VoucherRow)`

---

## 2.7 JournalItem

**جدول مستقل ندارد.**  
**نوع مدل:** Derived Row

فیلدهای JournalItem در frontend:
- `date`
- `voucherCode` یا `voucherNumber`
- `vDescription`
- `accountName`
- `description`
- `debit`
- `credit`
- (implicitly inherited ids مثل project/customer/expert در row اصلی)

---

## 2.8 Ledger

در سیستم فعلی **دو مدل Ledger** وجود دارد:

### 2.8.1 Finance Ledger (مدرن)
**جدول:** `wp_cptt_fin_ledger`

| فیلد | نوع |
|---|---|
| `id` | BIGINT PK AI |
| `account_id` | BIGINT |
| `type` | VARCHAR(30) |
| `direction` | TINYINT (+1 / -1) |
| `amount` | DECIMAL(20,2) |
| `category_id` | BIGINT |
| `project_id` | BIGINT |
| `step_id` | VARCHAR(64) |
| `customer_id` | BIGINT |
| `expert_id` | BIGINT |
| `ref_type` | VARCHAR(40) |
| `ref_id` | BIGINT |
| `linked_id` | BIGINT |
| `date_at` | INT |
| `date_fa` | VARCHAR(40) |
| `description` | TEXT |
| `created_by` | BIGINT |
| `created_at` | INT |

**ایندکس‌ها**
- `account_idx`
- `type_idx`
- `date_idx`
- `project_idx`
- `customer_idx`
- `expert_idx`
- در ERP migration همچنین تلاش برای افزودن `voucher_id` به ledger legacy دیده می‌شود، اما در `cptt_fin_ledger` چنین ستونی در schema اولیه‌ی کلاس Finance تعریف نشده است.

**کاربرد**
- خزانه
- درآمد/هزینه legacy
- transfer
- bank reconciliation
- monthly series legacy
- category breakdown

### 2.8.2 Core Ledger (قدیمی / project settlement ledger)
**جدول:** `wp_cptt_ledger`

| فیلد | نوع |
|---|---|
| `id` | BIGINT PK AI |
| `project_id` | BIGINT |
| `step_id` | VARCHAR(80) |
| `user_id` | BIGINT |
| `type` | VARCHAR(50) |
| `amount` | DECIMAL(18,2) |
| `note` | TEXT |
| `created_by` | BIGINT |
| `created_at` | DATETIME |

**ایندکس‌ها**
- `KEY project_id`
- `KEY user_id`
- `KEY type`

**کاربرد**
- expert payouts
- manual expert payment
- customer card payment
- activity/history logic

**تحلیل مهم**
- وجود دو ledger هم‌زمان، یکی از محورهای اصلی complexity سیستم است.

---

## 2.9 Trial Balance

**مدل فیزیکی ندارد.**  
**نوع مدل:** Derived Report

**در frontend ERP (component minified `vj`)** از مجموع debit/credit بر اساس `VoucherRow.accountId` ساخته می‌شود.

**فیلدهای خروجی report**
- `code`
- `name`
- `debit`
- `credit`
- `balance = debit - credit`

---

## 2.10 Income Statement

**مدل فیزیکی ندارد.**  
**نوع مدل:** Derived Report

**در frontend ERP (component minified `jj`)**:
- Revenue = sum over rows where first char of account code is `5` / `۵` → `credit - debit`
- Expense = sum over rows where first char of code is `6` / `۶` → `debit - credit`
- Profit = Revenue - Expense

**تحلیل:** Report از grouping accounting code prefix استفاده می‌کند، نه table مستقل.

---

## 2.11 Balance Sheet

**مدل فیزیکی ندارد.**  
**نوع مدل:** Derived Report

**در frontend ERP (component minified `bj`)**:
- Assets = groups `1` and `2` based on `(debit - credit)`
- Liabilities = group `3` based on `-(debit - credit)`
- Equity = group `4` based on `-(debit - credit)`

**فرمول UI:**
- `assets`
- `liabilities`
- `equity`
- نمایش عبارت: `دارایی = بدهی + سرمایه`

---

## 2.12 Fiscal Year

**منبع:** `wp_options` → `cpttf_erp_fiscal_years`

| فیلد | نوع | توضیح |
|---|---|---|
| `id` | string | شناسه سال مالی |
| `companyId` | string | شناسه شرکت |
| `name` | string | نام سال مالی |
| `startDate` | string | شروع شمسی |
| `endDate` | string | پایان شمسی |
| `status` | string | `OPEN` / `CLOSED` |
| `closedAt` | string? | زمان بستن |
| `closedBy` | string? | بستن توسط |
| `reopenedAt` | string? | بازگشایی |
| `reopenedBy` | string? | بازگشایی توسط |

**نحوه استفاده**
- numbering code prefix
- period locking
- FY close/opening vouchers
- filters و صفحات FY admin / ERP

---

## 2.13 Cost Center

**منبع:** `wp_options` → `cpttf_erp_cost_centers`

| فیلد | نوع |
|---|---|
| `id` | string |
| `name` | string |
| `type` | `PROJECT/UNIT/TEAM/BRANCH` |
| `code` | string |
| `budget` | float |

**کاربرد**
- بودجه vs واقعی
- select در فرم‌ها
- `VoucherRow.costCenterId`
- dashboard client-side budget consumption placeholder

---

## 2.14 Project

**منبع اصلی:** `wp_posts` با `post_type='cptt_project'`

**Metaهای مالی مهم**
- `_cptt_client_user_id`
- `_cptt_steps`
- `_cptt_is_settled`
- `_cptt_product_id`
- `_cptt_expert_user_ids`
- `_cptt_deadline_at`
- `_cptt_last_update`
- `_cptt_wc_cat_ids`
- `_cptt_project_notes`

**مدل step داخل `_cptt_steps`** (مهم‌ترین operational financial structure)
- `id`
- `title` / گاهی `name`
- `desc`
- `status` (`todo/current/done`)
- `cost`
- `paid`
- `expert_share`
- `exp_to_expert`
- `expert_paid`
- `admin_received`
- `settled` / `step_settled`
- `settle_at`, `settle_at_fa`, `settled_by`
- `assigned_expert_id`
- `assigned_expert_ids[]`
- `expert_settlements[]`
- `extra_finance[]` with `cost`, `paid`
- `checklist[]`
- `user_tasks[]`
- `due_at`, `due_at_fa`

**کاربرد**
- مرجع عملیاتی محاسبات مطالبات، سود، پرداخت کارشناس، پروژه، dashboard

---

## 2.15 Customer

**منبع:** `wp_users`

**فیلدهای مورد استفاده‌ی مالی**
- `ID`
- `display_name`
- `user_email`
- متاها: `billing_phone`, `cptt_phone`, `mobile`, `_cptt_bale_chat_id`

**روابط**
- Project via `_cptt_client_user_id`
- VoucherRow.customer_id
- FinanceLedger.customer_id
- InstallmentPlan.customer_id
- Invoice.customer_id

---

## 2.16 Supplier

**مدل مستقل ندارد.**  
**نمایش در سیستم:** داخل `Payable` به صورت `partyType = supplier`

**فیلدهای موثر**
- `party_type`
- `party_name`
- `party_id` (ممکن است 0 باشد)

**نتیجه:** Supplier first-class entity نیست.

---

## 2.17 Currency

**منبع:** `wp_options` → `cptt_currency_settings`

| فیلد | نوع |
|---|---|
| `unit` | `toman/rial/usd/eur` |
| `usd_rate` | float |
| `eur_rate` | float |
| `decimals` | int |

**نکته‌ی معماری**
- مقادیر DB در توضیح کلاس `CPTT_Currency` «پایه = تومان» معرفی شده‌اند
- این لایه Display-only است، نه full multi-currency ledger accounting
- در ERP Phase 8، model جداگانه‌ی `OPT_CURRENCY_RATES` نیز وجود دارد

---

## 2.18 Company / Branch

**منبع:** `wp_options`
- `cpttf_erp_companies`
- `cpttf_erp_branches`

**Default shape**

### Company
- `id`
- `name`
- `registrationNumber`
- `logoColor`

### Branch
- `id`
- `companyId`
- `name`
- `code`

---

## 2.19 Invoice (ERP)

**منبع:** `wp_cptt_erp_invoices`

| فیلد | نوع |
|---|---|
| `id` | VARCHAR(64) PK |
| `number` | VARCHAR |
| `type` | `invoice/quote/proforma` |
| `customer_id` | BIGINT |
| `customer_name` | VARCHAR |
| `project_id` | BIGINT |
| `project_name` | VARCHAR |
| `issue_date` | VARCHAR |
| `due_date` | VARCHAR |
| `subtotal` | DECIMAL |
| `discount` | DECIMAL |
| `tax_rate` | DECIMAL |
| `tax_amount` | DECIMAL |
| `total` | DECIMAL |
| `currency` | VARCHAR |
| `status` | `draft/sent/paid/cancelled/partial` |
| `notes` | TEXT |
| `voucher_id` | VARCHAR |
| `created_by` | VARCHAR |
| `created_at` | INT |

**Rows table:** `wp_cptt_erp_invoice_rows`
- `invoice_id`
- `row_no`
- `title`
- `description`
- `quantity`
- `unit_price`
- `amount`

---

## 2.20 Payable

**منبع:** `wp_cptt_erp_payables`

| فیلد | نوع |
|---|---|
| `id` | VARCHAR |
| `party_type` | string |
| `party_id` | int |
| `party_name` | string |
| `amount` | float |
| `paid_amount` | float |
| `issue_date` | string |
| `due_date` | string |
| `project_id` | int |
| `description` | string |
| `status` | string |
| `created_at_fa` | string |
| `created_at` | int |

**Derived field در runtime:** `remain = amount - paidAmount`

---

## 2.21 InstallmentPlan / InstallmentRow

**منبع:**
- `wp_cptt_erp_installments`
- `wp_cptt_erp_installment_rows`

### Plan fields
- `id`
- `customer_id`
- `customer_name`
- `project_id`
- `project_name`
- `total_amount`
- `installments_count`
- `interval_days`
- `first_due_date`
- `description`
- `created_at_fa`
- `created_at`

### Row fields
- `plan_id`
- `no`
- `due_date`
- `amount`
- `paid_amount`
- `paid_date`
- `status`

---

## 2.22 Cheque

**منبع:** `wp_cptt_erp_cheques`

| فیلد | نوع |
|---|---|
| `id` | VARCHAR |
| `kind` | `receivable/payable` |
| `number` | string |
| `sayyadi` | string |
| `bank` | string |
| `branch` | string |
| `amount` | float |
| `issue_date` | string |
| `due_date` | string |
| `party_type` | string |
| `party_id` | int |
| `party_name` | string |
| `project_id` | int |
| `treasury_account_id` | string |
| `status` | string |
| `description` | string |
| `attachment_id` | string |
| `created_at_fa` | string |
| `created_at` | int |

---

## 2.23 Audit Log

**منبع:** `wp_cptt_erp_audit`

| فیلد | نوع |
|---|---|
| `id` | BIGINT PK |
| `user_id` | BIGINT |
| `user_name` | VARCHAR |
| `action_type` | VARCHAR |
| `entity_type` | VARCHAR |
| `entity_id` | VARCHAR |
| `before_data` | LONGTEXT |
| `after_data` | LONGTEXT |
| `created_at` | INT |
| `date_fa` | VARCHAR |

---

# 3) جریان ثبت سند (End-to-End Voucher Flow)

## 3.1 جریان دستی: کاربر روی «ثبت سند» در ERP کلیک می‌کند

### مرحله 1 — باز شدن UI ثبت سند
- **فایل:** `assets/finance-ui/app.js`
- **Component reverse engineered:** بخش `اسناد حسابداری` (تابع minified در bundle؛ نام semantic در source در دسترس نیست)
- **ورودی:** کلیک روی دکمه `ثبت سند جدید`
- **خروجی:** Modal/Form state local شامل:
  - `date`
  - `description`
  - `rows[]` با `accountId`, `debit`, `credit`, `description`

### مرحله 2 — Validation سمت client
- **فایل:** `assets/finance-ui/app.js`
- **منطق:** جمع بدهکار و بستانکار بررسی می‌شود (`It` در bundle)
- **ورودی:** rows فرم
- **خروجی:** اگر unequal → toast/خطا و ارسال انجام نمی‌شود

### مرحله 3 — ارسال AJAX
- **فایل:** `assets/finance-ui/app.js`
- **Bridge:** `wpCall` داخل bundle (معادل source قدیمی `wpBridge.ts`)
- **Endpoint:** `cpttf_erp_voucher_save`
- **Payload:**
  - `voucher` JSON
  - `nonce`

### مرحله 4 — احراز مجوز و nonce
- **فایل:** `includes/class-cptt-finance-erp.php`
- **کلاس:** `CPTT_Finance_ERP`
- **تابع:** `check_perm('voucher_create')`
- **ورودی:** request POST + nonce + current user
- **خروجی:** ادامه / 403 / 401 / 429

### مرحله 5 — Validation backend
- **فایل:** `includes/class-cptt-finance-erp.php`
- **تابع:** `ajax_voucher_save()` → `validate_voucher_rows()`
- **ورودی:** `voucher.rows`
- **خروجی:**
  - `ok=true` یا
  - خطا: منفی بودن، توازن نداشتن، accountId خالی، جمع صفر

### مرحله 6 — کنترل قفل دوره
- **فایل:** `includes/class-cptt-finance-erp.php`
- **تابع:** `reject_if_locked(voucher.date, 'ثبت سند')`
- **ورودی:** تاریخ شمسی سند
- **خروجی:**
  - ادامه
  - یا 423 Locked

### مرحله 7 — ساخت شیء Voucher
- **فایل:** `includes/class-cptt-finance-erp.php`
- **تابع:** `ajax_voucher_save()`
- **ورودی:** voucher خام frontend
- **خروجی:** آرایه normalized voucher شامل id / voucherNumber / metadata

### مرحله 8 — ذخیره در DB
- **فایل:** `includes/class-cptt-finance-erp.php`
- **تابع:** `insert_voucher_into_table($voucher)`
- **جداول:**
  - `wp_cptt_erp_vouchers`
  - `wp_cptt_erp_voucher_rows`
- **خروجی:** record persisted

### مرحله 9 — پاسخ به frontend
- **فایل:** `includes/class-cptt-finance-erp.php`
- **تابع:** `ajax_voucher_save()`
- **خروجی:**
  - `id`
  - `voucherNumber`

### مرحله 10 — نمایش در اسناد و گزارش‌ها
- **فایل backend:** `ajax_full_bootstrap()` / `ajax_bootstrap_reports()`
- **تابع:** `get_vouchers()` → `read_vouchers_from_table()`
- **خروجی:** payload vouchers با rows

### مرحله 11 — استفاده در صفحات گزارشی ERP
- **فایل frontend:** `assets/finance-ui/app.js`
- **Components reverse engineered:**
  - `pj` → Journal
  - `mh` → General/Subsidiary Ledger
  - `vj` → Trial Balance
  - `jj` → Income Statement
  - `bj` → Balance Sheet
- **ورودی:** `vouchers`, `accounts`
- **خروجی:** رندر reportها

---

## 3.2 جریان خودکار: رویداد کسب‌وکاری باعث ساخت سند می‌شود

### نمونه‌ها
- `ajax_project_quick_pay()` → RV
- `ajax_ie_save()` → RV/PV
- `ajax_installment_pay()` → RV
- `ajax_payable_pay()` → PV
- `ajax_treasury_deposit()` → RV
- `ajax_treasury_withdraw()` → PV
- `ajax_treasury_transfer()` → TV
- `auto_voucher_expert_payout()` → PV
- `auto_voucher_manual_payment()` → PV
- `ajax_fy_close_execute()` → CV / OV

### مسیر مشترک
Business Action → `gen_voucher()` → `insert_voucher_into_table()` → bootstrap/report payloads → report rendering

---

# 4) منطق محاسبات (Calculation Logic Inventory)

## 4.1 جمع بدهکار / جمع بستانکار

### `validate_voucher_rows($rows)`
- **فایل:** `class-cptt-finance-erp.php`
- **کار:** جمع total debit و total credit برای validation

### `project_voucher_total($voucher)`
- **فایل:** `class-cptt-finance-erp.php`
- **کار:** جمع debit rowها برای تخمین مبلغ سند
- **نکته:** برای سند متوازن، این برابر total credit نیز هست

### frontend `vj` (Trial Balance)
- **فایل:** `assets/finance-ui/app.js`
- **کار:** sum debit / credit per accountId

### frontend `pj` (Journal)
- **فایل:** `assets/finance-ui/app.js`
- **کار:** sum total journal debit / credit در footer

---

## 4.2 مانده حساب / Running Balance

### `CPTT_Finance::account_balance($account_id)`
- **فرمول:** `initial_balance + SUM(direction * amount)`
- **منبع:** `wp_cptt_fin_ledger`
- **استفاده:** treasury, dashboard legacy

### `CPTT_Finance::account_balance_at($account_id, $ts)`
- **فرمول:** `initial_balance + SUM(direction * amount WHERE date_at <= ts)`
- **استفاده:** legacy ledger running balance

### `get_coa_with_balances()`
- **فرمول:** aggregate row-wise `(debit - credit)` سپس roll-up به parent chain
- **منبع:** VoucherRows
- **استفاده:** CoA live balances, reports bootstrap

### frontend `mh` (دفتر کل/معین)
- **فرمول:**
  - `debit += row.debit`
  - `credit += row.credit`
  - `balance = debit - credit`
- **ویژگی:** parent chain roll-up برای general/subsidiary

### frontend `vj` (Trial Balance)
- **فرمول:** `balance = debit - credit`
- **نمایش:** اگر مثبت → بدهکار (`بد`)؛ اگر منفی → بستانکار (`بس`)

### `ajax_bank_recon()`
- **فرمول summary:**
  - `total_debit = SUM(direction > 0 ? amount : 0)`
  - `total_credit = SUM(direction < 0 ? amount : 0)`
  - `unrecon_balance = (total_debit-total_credit) - (recon_debit-recon_credit)`

---

## 4.3 مانده افتتاحیه / اختتامیه

### `fy_permanent_balances($fy)`
- **فایل:** `class-cptt-finance-erp.php`
- **فرمول:** تا پایان سال، فقط گروه‌های 1..4، sum `(debit-credit)`
- **استفاده:** سند افتتاحیه OV

### `ajax_fy_close_execute()`
- **Closing logic:**
  - درآمدها zero-out debit
  - هزینه‌ها zero-out credit
  - profit/loss به retained earnings
- **استفاده:** بستن سال مالی

---

## 4.4 درآمد / هزینه / سود / زیان

### `compute_kpis()`
- **فایل:** `class-cptt-finance.php`
- **فرمول‌ها:**
  - `total_revenue = sum(_cptt_steps[].paid)`
  - `total_invoiced = sum(_cptt_steps[].cost)`
  - `receivables = total_cost - total_paid`
  - `expert_payouts = sum(_cptt_steps[].expert_paid)`
  - `gross_profit = total_paid - expert_payouts`
- **منبع:** `_cptt_steps`
- **نکته:** این سود = gross profit ساده است، نه P&L کامل voucher-based

### `monthly_series()`
- **فایل:** `class-cptt-finance.php`
- **فرمول:**
  - ledger incomes/expenses by month
  - + project paid as income
  - + expert_paid as expense
- **نکته:** ترکیبی از دو منبع (`cptt_fin_ledger` + `_cptt_steps`)

### `category_breakdown($type)`
- **فایل:** `class-cptt-finance.php`
- **فرمول:** `SUM(l.amount) GROUP BY category_id`
- **منبع:** `wp_cptt_fin_ledger`

### `compute_pl_range($from, $to)`
- **فایل:** `class-cptt-finance-erp.php`
- **فرمول:**
  - revenue from group 5 → `credit - debit`
  - expense from group 6 → `debit - credit`
  - profit = revenue - expense
- **منبع:** VoucherRows

### `fy_pl_summary($fy)`
- **فایل:** `class-cptt-finance-erp.php`
- **همان منطق P&L** در سطح fiscal year، با جزئیات per account

### frontend `jj` (Income Statement)
- **فایل:** `assets/finance-ui/app.js`
- **منطق:** همان rule code-prefix 5/6 روی vouchers/accounts

---

## 4.5 مطالبات / بدهی باقی‌مانده / Outstanding

### `build_receivables()`
- **فایل:** `class-cptt-finance-erp.php`
- **فرمول:** `remain = max(0, cost - paid)` per project
- **منبع:** `_cptt_steps + extra_finance`

### `project_financial_data($project_id)`
- **فایل:** `class-cptt-admin.php`
- **فرمول:**
  - `cost = sum(step.cost)`
  - `paid = sum(step.paid)`
  - `remain = cost - paid`
  - `percent = paid / cost`
- **منبع:** `_cptt_steps`

### `project_remaining($project_id)`
- **فایل:** `class-cptt-payment.php`
- **فرمول:** `sum(max(0, cost - paid))`
- **منبع:** `_cptt_steps`

### `build_experts_and_steps()`
- **فایل:** `class-cptt-finance-erp.php`
- **فرمول:**
  - `remain = max(0, exp_to_expert - expert_paid)`
  - `pendingBalance += remain`
  - `paidBalance += expert_paid`

### `get_payables_recomputed()`
- **فایل:** `class-cptt-finance-erp.php`
- **فرمول:** `remain = max(0, amount - paidAmount)`

### `get_installment_plans_recomputed()`
- **فایل:** `class-cptt-finance-erp.php`
- **فرمول:**
  - `status = paid / overdue / unpaid`
  - based on `paidAmount` vs `amount` + `dueDate < today`

---

## 4.6 سودآوری پروژه

### `render_accounting_page()` کلاسیک
- **فایل:** `class-cptt-admin.php`
- **فرمول:** `gross_profit = totalPaid - expert_paid_sum`

### `build_projects_full()` ERP
- **فیلد خروجی:** `expertPaid`, `totalCost`, `totalPaid`, `totalExtraCost`, `totalExtraPaid`
- سود نهایی در UI از این data ساخته می‌شود

### `ajax_wip_report()`
- **فایل:** `class-cptt-finance-erp.php`
- **فرمول:**
  - `billed = sum(cost)`
  - `completed = sum(cost of completed steps)`
  - `collected = sum(paid)`
  - `over_under = billed - completed`

---

# 5) گزارش‌ها (Reports Audit)

> در این پروژه، reportها دو دسته‌اند:
> 1. **ERP standard reports** در `assets/finance-ui/app.js`
> 2. **Advanced Reports** در `class-cptt-finance-erp.php` (PHP page)
>
> درخواست کاربر برای این بخش روی reportهای استاندارد ERP تمرکز دارد.

## 5.1 اسناد حسابداری

### لایه UI
- **فایل:** `assets/finance-ui/app.js`
- **منبع داده:** `vouchers`
- **فیلترها:**
  - جستجو شرح
  - شماره سند
  - وضعیت سند
  - نوع سند
  - بازه تاریخ
  - پروژه
  - شخص

### منبع داده backend
- **Endpoint:** `cpttf_erp_full_bootstrap` / `cpttf_erp_bootstrap_reports` / `cpttf_erp_vouchers_list`
- **تابع:** `get_vouchers()` → `read_vouchers_from_table()`

### Queryها
- `SELECT * FROM wp_cptt_erp_vouchers ORDER BY created_at DESC, voucher_number DESC`
- `SELECT * FROM wp_cptt_erp_voucher_rows WHERE voucher_id IN (...) ORDER BY voucher_id, row_no`
- و در وضعیت فعلی workspace: merge با `build_virtual_legacy_vouchers()` برای legacy

### شرط‌ها
- در UI همه statusها دیده می‌شوند؛ filter روی status در client-side است

---

## 5.2 دفتر روزنامه (Journal)

### لایه UI
- **فایل:** `assets/finance-ui/app.js`
- **Component minified:** `pj`

### منبع داده
- `vouchers`
- flatten شدن `VoucherRow`ها

### Query مستقیم SQL در report؟
- **خیر**
- از payload vouchers استفاده می‌کند

### فیلترها
- search text در accountName/description/voucherCode/voucherNumber
- فیلترهای بالادستی shell:
  - from date
  - to date
  - status
  - project
  - cost center
  - person

### وضعیت سند
- داده‌ی row شامل `status` دارد ولی display اصلی Journal بیشتر row-centric است

### سال مالی
- مستقیم filter ندارد؛ indirect اگر voucher payload محدود شده باشد

### پروژه / شخص / نوع سند
- از shell filter اعمال می‌شود (`xj` component)

---

## 5.3 دفتر کل (General Ledger)

### لایه UI
- **فایل:** `assets/finance-ui/app.js`
- **Component minified:** `mh` with `mode='general'`

### منبع داده
- `vouchers`
- `accounts`

### Query SQL مستقیم
- **خیر** (client-side aggregation)

### منطق
- flatten rows into grouped structure by account and parent chain
- فقط حساب‌های `type=general` یا `group` در dropdown

### فیلترها
- انتخاب حساب کل
- فیلترهای shell report:
  - date range
  - status
  - project
  - cost center
  - person

---

## 5.4 دفتر معین (Subsidiary Ledger)

### لایه UI
- **فایل:** `assets/finance-ui/app.js`
- **Component minified:** `mh` with `mode='subsidiary'`

### منبع داده
- `vouchers`
- `accounts`

### Query مستقیم SQL
- **خیر**

### منطق
- فقط `subsidiary` و `detail` در dropdown
- roll-up بر اساس parent chain موجود در account tree

### فیلترها
- مثل دفتر کل

---

## 5.5 تراز آزمایشی (Trial Balance)

### لایه UI
- **فایل:** `assets/finance-ui/app.js`
- **Component minified:** `vj`

### منبع داده
- `vouchers`
- `accounts`

### Query مستقیم
- **خیر**

### منطق محاسبه
- group by `accountId`
- `debit += row.debit`
- `credit += row.credit`
- `balance = debit - credit`
- footer:
  - total debit
  - total credit
  - if equal → `✓ متوازن`

### فیلترها
- بالادستی shell reports

---

## 5.6 صورت سود و زیان (Income Statement)

### لایه UI
- **فایل:** `assets/finance-ui/app.js`
- **Component minified:** `jj`

### منبع داده
- `vouchers`
- `accounts`

### Query مستقیم SQL
- **خیر**

### منطق
- برای هر row:
  - account code first char = 5 → revenue += credit - debit
  - account code first char = 6 → expense += debit - credit
- profit = revenue - expense

### فیلترها
- بالادستی shell

### وابستگی مهم
- اگر `accountId` row در `accounts` resolve نشود، این report آن row را نادیده می‌گیرد
- این یکی از دلایل مهم صفر شدن P&L در سناریوهای synthetic/legacy بوده است

---

## 5.7 ترازنامه (Balance Sheet)

### لایه UI
- **فایل:** `assets/finance-ui/app.js`
- **Component minified:** `bj`

### منبع داده
- `vouchers`
- `accounts`

### Query مستقیم SQL
- **خیر**

### منطق
- group 1,2 → assets += debit - credit
- group 3 → liabilities -= (debit - credit)
- group 4 → equity -= (debit - credit)

### فیلترها
- بالادستی shell

### وابستگی مهم
- مثل Income Statement وابسته به resolve شدن `accountId -> account.code`

---

## 5.8 گزارش‌های پیشرفته (ضمیمه)

این گزارش‌ها خارج از scope اصلی سؤال بودند اما برای معماری حسابداری مهم‌اند:
- Cash Flow → `ajax_cash_flow()`
- Period Compare → `ajax_period_compare()`
- Budget vs Actual → `ajax_budget_actual()`
- Aging Custom → `ajax_aging_custom()`
- Aging Cheques → `ajax_aging_cheques()`
- WIP → `ajax_wip_report()`
- Bank Recon → `ajax_bank_recon()`

همه در `class-cptt-finance-erp.php` و در صفحه PHP `render_reports_page()` هستند.

---

# 6) وضعیت اسناد و وضعیت‌های مالی (Statuses)

## 6.1 وضعیت Voucher

| وضعیت | محل استفاده | توضیح |
|---|---|---|
| `DRAFT` | manual voucher save, documents UI | پیش‌نویس |
| `ACCOUNTANT_APPROVED` | workflow approvals | تأیید حسابدار |
| `MANAGER_APPROVED` | workflow approvals | تأیید مدیر مالی |
| `FINALIZED` | report inclusion, FY logic, print, journal, balances | نهایی |

> `Pending`, `Posted`, `Deleted`, `Archived` برای voucher به‌صورت status رسمی در ERP table مشاهده نشد.

## 6.2 وضعیت Fiscal Year
- `OPEN`
- `CLOSED`

## 6.3 وضعیت Installment Row
- `unpaid`
- `paid`
- `overdue`

## 6.4 وضعیت Payable
- `open`
- `partially_paid`
- `paid`
- `overdue`

## 6.5 وضعیت Invoice
- `draft`
- `sent`
- `paid`
- `cancelled`
- `partial`

## 6.6 وضعیت Cheque
### دریافتی
- `received`
- `in_collection`
- `collected`
- `bounced`
- `transferred`
- `cancelled`

### پرداختی
- `issued`
- `awaiting_due`
- `paid`
- `cancelled_pay`

## 6.7 وضعیت Project / Step
### Project
- `_cptt_is_settled` → boolean (0/1)

### Step execution status
- `todo`
- `current`
- `done`

### Step settlement status
- `settled` (bool)
- `step_settled` (bool)

---

# 7) فرمول‌های مالی (Financial Formulas)

## 7.1 Asset / Liability / Equity

### frontend Balance Sheet (`bj`)
- `Assets = Σ(debit-credit) for groups 1,2`
- `Liabilities = Σ(-(debit-credit)) for group 3`
- `Equity = Σ(-(debit-credit)) for group 4`

**فایل:** `assets/finance-ui/app.js`

---

## 7.2 Revenue / Expense / Profit

### frontend Income Statement (`jj`)
- `Revenue = Σ(credit-debit) where account.code starts with 5`
- `Expense = Σ(debit-credit) where account.code starts with 6`
- `Profit = Revenue - Expense`

### backend `compute_pl_range()` / `fy_pl_summary()`
- همان فرمول

---

## 7.3 Trial Balance
- `Balance = Debit - Credit`
- `Grand total debit == grand total credit`

---

## 7.4 Receivable
- `Receivable(project) = max(0, totalCost - totalPaid)`
- `Receivable(customer) = Σ Receivable(projects of customer)`

---

## 7.5 Payable
- `PayableRemain = max(0, amount - paidAmount)`

---

## 7.6 Gross Profit (legacy dashboards)
- `GrossProfit = totalPaid - expertPayouts`
- **منبع:** `_cptt_steps`
- **نکته:** این با P&L voucher-based یکی نیست

---

## 7.7 WIP
- `Billed = Σ step.cost (+ extra_finance.cost)`
- `Collected = Σ step.paid (+ extra_finance.paid)`
- `Completed = Σ cost of completed steps`
- `OverUnder = Billed - Completed`

---

## 7.8 Collection Ratio
- `CollectionRatio = total_revenue / total_invoiced * 100`
- **فایل:** `build_financial_health()`

---

## 7.9 Bank Reconciliation
- `Unreconciled = (TotalDebit - TotalCredit) - (ReconDebit - ReconCredit)`

---

# 8) محل‌های محاسبه مبلغ (Amount Surfaces)

| مفهوم | محل/تابع | توضیح |
|---|---|---|
| `Debit` | VoucherRow, validate_voucher_rows, trial balance, journal, ledgers | ردیف سند |
| `Credit` | VoucherRow, validate_voucher_rows, trial balance, journal, ledgers | ردیف سند |
| `Balance` | account_balance, account_balance_at, get_coa_with_balances, trial balance, balance sheet | مانده حساب |
| `Opening Balance` | account_balance_at(ts=0), fy_permanent_balances, fy_close_preview | مانده افتتاحیه |
| `Closing Balance` | cash flow closing, fy_permanent_balances, balance sheet | اختتامیه |
| `Running Balance` | legacy ledger page, party statement print | مانده جاری |
| `Outstanding` | build_experts_and_steps, get_project_financial_snapshot | مانده بدهی به کارشناس |
| `Remaining` | build_receivables, project_financial_data, project_remaining, payables, installments | باقیمانده وصول/پرداخت |
| `Profit` | compute_kpis.gross_profit, compute_pl_range, fy_pl_summary, frontend `jj` | چند منطق مختلف |
| `Loss` | fy_pl_summary / compute_pl_range / frontend `jj` when profit < 0 | زیان |
| `Amount` | all ledger/voucher models | مبلغ پایه |

---

# 9) Duplicate Logic / منطق‌های تکراری

## 9.1 محاسبه وضعیت مالی پروژه

| تابع | فایل | منبع |
|---|---|---|
| `project_financial_data()` | `class-cptt-admin.php` | `_cptt_steps` |
| `get_project_financial_snapshot()` | `class-cptt-finance-erp.php` | `_cptt_steps` |
| `build_projects_full()` | `class-cptt-finance-erp.php` | `_cptt_steps` |
| `build_receivables()` | `class-cptt-finance-erp.php` | `_cptt_steps` |
| `project_remaining()` | `class-cptt-payment.php` | `_cptt_steps` |
| `compute_kpis()` | `class-cptt-finance.php` | `_cptt_steps` |

**تحلیل:** همه این‌ها به‌شکل‌های مختلف cost/paid/expert_paid را از `_cptt_steps` محاسبه می‌کنند.

## 9.2 محاسبه سود

| تابع | نوع سود |
|---|---|
| `compute_kpis()` | gross profit ساده = paid - expert_paid |
| `compute_pl_range()` | voucher-based accounting profit |
| `fy_pl_summary()` | voucher-based FY profit |
| frontend `jj` | voucher-based P&L |
| `build_financial_health()` | monthly net profit از `monthly_series()` |
| کلاسیک `render_accounting_page()` | gross profit بر اساس paid - expert_paid |

## 9.3 محاسبه مانده حساب

| تابع | فایل |
|---|---|
| `account_balance()` | `class-cptt-finance.php` |
| `account_balance_at()` | `class-cptt-finance.php` |
| `get_coa_with_balances()` | `class-cptt-finance-erp.php` |
| frontend `mh` / `vj` / `bj` | `assets/finance-ui/app.js` |

## 9.4 تاریخ/تبدیل جلالی

| تابع | فایل |
|---|---|
| `CPTT_Core::parse_jalali_datetime()` | core |
| `CPTT_Finance::parse_jalali_local()` | finance |
| `fa_to_gregorian_ts()` | finance-erp |
| `fa_date_cmp()` | finance-erp |
| `fa_date_of()` | finance-erp (helper داخلی) |

## 9.5 synthetic / virtual voucher logic
- frontend bundle `assets/finance-ui/app.js` قبلاً synthetic می‌ساخت
- backend current workspace also has `build_virtual_legacy_vouchers()`
- این بخش ذاتاً duplicate/parallel semantics دارد

---

# 10) Single Source of Truth (SoT)

## 10.1 پاسخ کوتاه
**Single Source of Truth واحد وجود ندارد.**

## 10.2 برای هر حوزه، مرجع اصلی چیست؟

| حوزه | مرجع اصلی فعلی |
|---|---|
| ساختار پروژه و مرحله | `_cptt_steps` در post meta |
| مطالبات مشتری | `_cptt_steps` |
| بدهی/پرداخت به کارشناس | `_cptt_steps` + `wp_cptt_ledger` |
| حساب خزانه | `wp_cptt_fin_accounts` + `wp_cptt_fin_ledger` |
| اسناد حسابداری رسمی ERP | `wp_cptt_erp_vouchers` + `wp_cptt_erp_voucher_rows` |
| گزارش‌های استاندارد ERP | `vouchers + voucher_rows + COA` |
| dashboard مالی legacy | ترکیبی: `_cptt_steps` + `wp_cptt_fin_ledger` |
| invoice ERP | `wp_cptt_erp_invoices` + rows |
| party statement | عمدتاً voucher rows، ولی برای expertها همچنین `wp_cptt_ledger` |

## 10.3 جریان مفهومی فعلی (نه ایده‌آل)

```text
Project / _cptt_steps
 ├─> Receivables / Gross Profit / Project KPIs
 ├─> Step Settlement Logic
 ├─> Some automatic vouchers generated into ERP vouchers
 ├─> Some legacy payouts written to wp_cptt_ledger
 └─> Some cash movements written to wp_cptt_fin_ledger

ERP Vouchers / Voucher Rows
 ├─> Documents UI
 ├─> Journal
 ├─> General Ledger
 ├─> Subsidiary Ledger
 ├─> Trial Balance
 ├─> Income Statement
 └─> Balance Sheet

Finance Ledger (wp_cptt_fin_ledger)
 ├─> Treasury pages
 ├─> Monthly legacy dashboard
 ├─> Category breakdown
 ├─> Bank reconciliation
 └─> Some backfill / virtual voucher logic

Core Ledger (wp_cptt_ledger)
 ├─> Expert payout history
 ├─> Manual expert payment history
 └─> Some virtual/backfill voucher logic
```

**جمع‌بندی SoT:**
- برای **Operational Business Reality** → `_cptt_steps`
- برای **Formal Accounting Reports** → `Voucher + VoucherRows`
- برای **Cash/Treasury Reality** → `cptt_fin_ledger`
- برای **Legacy settlement history** → `cptt_ledger`

---

# 11) Eventها (Business Events)

## 11.1 رویدادهای ثبت سند / تغییر مالی

| رویداد | فایل/تابع | اثر |
|---|---|---|
| ثبت سند دستی | `ajax_voucher_save()` | ذخیره Voucher + Rows |
| تأیید سند | `ajax_voucher_approve()` | تغییر status workflow |
| حذف سند | `ajax_voucher_delete()` | حذف Voucher/Rows |
| برگشت سند | `ajax_voucher_reverse()` / `gen_reverse_voucher()` | سند معکوس |
| بازکردن سند نهایی | `ajax_voucher_unfinalize()` | FINALIZED → DRAFT |
| ثبت درآمد/هزینه | `ajax_ie_save()` | finance ledger + voucher |
| حذف درآمد/هزینه | `ajax_ie_delete()` | delete ledger row + reverse voucher |
| دریافت از مشتری | `ajax_project_quick_pay()` | update `_cptt_steps` + finance ledger + voucher |
| تسویه مرحله کارشناس | `ajax_step_settle()` (admin کلاسیک) | update `_cptt_steps` + core ledger + hooks |
| تسویه از ERP | `ajax_settle_steps()` | update `_cptt_steps` + finance ledger + hooks |
| پرداخت دستی کارشناس | `ajax_manual_expert_payment()` / `ajax_settle_manual()` | core/finance ledger + hooks |
| انتقال بین حساب‌ها | `ajax_treasury_transfer()` / `ajax_transfer()` | finance ledger ± voucher |
| پرداخت بدهی | `ajax_payable_pay()` | payables + finance ledger + PV |
| دریافت قسط | `ajax_installment_pay()` | installments + finance ledger + RV |
| صدور سند از فاکتور | `ajax_invoice_to_voucher()` | invoice.voucher_id |
| بستن سال مالی | `ajax_fy_close_execute()` | CV/OV + lock |
| بازکردن سال مالی | `ajax_fy_reopen()` | unlock |

## 11.2 رویدادهای domain hooks داخلی

| Hook/Event | Producer | Consumer |
|---|---|---|
| `cptt_after_expert_payout` | `CPTT_Admin::ajax_step_settle`, `CPTT_Finance_ERP::ajax_settle_steps` | `CPTT_Finance::log_expert_payout`, `CPTT_Finance_ERP::auto_voucher_expert_payout` |
| `cptt_after_manual_expert_payment` | `CPTT_Admin::ajax_manual_expert_payment`, `CPTT_Finance_ERP::ajax_settle_manual` | `CPTT_Finance::log_manual_payment`, `CPTT_Finance_ERP::auto_voucher_manual_payment` |
| `updated_post_meta/_cptt_steps` | WP core meta system | `CPTT_Finance_ERP::on_project_meta_changed` |
| `added_post_meta/_cptt_steps` | WP core meta system | `CPTT_Finance_ERP::on_project_meta_changed` |

---

# 12) Hook / Observer / Listener / Middleware / Service / Repository

## 12.1 Hookها (WP Hooks)

### backend listeners
- `admin_menu` → register menus (Finance / ERP / Admin)
- `admin_init` → migrations, cron schedule, project sync
- `admin_enqueue_scripts` → enqueue CSS/JS
- `wp_ajax_*` → تقریباً تمام عملیات مالی
- `rest_api_init` → REST routes ERP
- `updated_post_meta` / `added_post_meta` → project accounting sync
- `cpttf_erp_daily_cron` / `cpttf_erp_hourly_cron` → cron jobs
- `cptt_after_expert_payout` / `cptt_after_manual_expert_payment` → voucher/ledger hooks
- activation/deactivation hooks in `client-project-tracker.php`

## 12.2 Observer ها
- **WP metadata change observation** via `updated_post_meta` / `added_post_meta`
- **Frontend legacy finance.js** uses `MutationObserver` only for binding Jalali datepickers on modal DOM changes
- ERP React bundle behavior داخلی reactive است، اما source class-based observer مستقلی دیده نشد (minified)

## 12.3 Listener ها (Frontend)

### Legacy finance.js
- click listeners برای:
  - transaction CRUD
  - account CRUD
  - transfer modal
  - category CRUD
- input listeners برای money formatting
- accordion/list toggles
- resize listeners برای charts

### ERP frontend bundle
- tab changes
- report filters
- voucher modal actions
- dropdowns / pagination / export / print builders
- به‌دلیل minification، listenerهای دقیق فقط مفهومی استخراج شده‌اند

## 12.4 Middleware
- **به‌معنای معماری کلاسیک middleware وجود ندارد**
- نزدیک‌ترین معادل:
  - `check_perm()`
  - `reject_if_locked()`
  - `rate_limit_check()`
  - `validate_uploaded_file()`

## 12.5 Service ها
- `CPTT_Finance`
- `CPTT_Finance_ERP`
- `CPTT_Currency`
- `CPTT_Payment`
- `CPTT_Core`
- `CPTT_Admin`
- `CPTT_Expert`

> این‌ها Repository/Service Layer formal ندارند، بلکه Singletonهای WP-style هستند.

## 12.6 Repository ها
- **Repository pattern رسمی وجود ندارد**
- دسترسی به داده مستقیماً داخل کلاس‌ها و توابع با `$wpdb`, `get_post_meta`, `get_option` انجام می‌شود

---

# 13) وابستگی فایل‌ها (Dependency Graph)

## 13.1 گراف سطح بالا

```text
client-project-tracker.php
 ├─> class-cptt-core.php
 ├─> class-cptt-admin.php
 ├─> class-cptt-expert.php
 ├─> class-cptt-currency.php
 ├─> class-cptt-payment.php
 ├─> class-cptt-finance.php
 └─> class-cptt-finance-erp.php
```

## 13.2 Finance legacy

```text
class-cptt-finance.php
 ├─> class-cptt-core.php   (Jalali / projects / steps)
 ├─> class-cptt-currency.php
 ├─> includes/finance/page-dashboard.php
 ├─> includes/finance/page-receivables.php
 ├─> includes/finance/page-payouts.php
 ├─> includes/finance/page-transactions.php
 ├─> includes/finance/page-treasury.php
 ├─> includes/finance/page-ledger.php
 ├─> includes/finance/page-categories.php
 ├─> assets/css/finance.css
 └─> assets/js/finance.js
```

## 13.3 ERP subsystem

```text
class-cptt-finance-erp.php
 ├─> class-cptt-finance.php        (tbl_accounts / ledger / category APIs)
 ├─> class-cptt-core.php           (jalali helpers / project data)
 ├─> class-cptt-admin.php          (shared settlement hooks / project structure)
 ├─> class-cptt-currency.php       (display label)
 ├─> assets/finance-ui/app.js      (UI consumer)
 ├─> assets/finance-ui/app.css
 └─> assets/finance-ui/fonts.css
```

## 13.4 Project-accounting interaction

```text
class-cptt-admin.php
 ├─> writes _cptt_steps
 ├─> writes _cptt_is_settled
 ├─> do_action(cptt_after_expert_payout)
 └─> do_action(cptt_after_manual_expert_payment)

class-cptt-finance.php
 ├─> listens to cptt_after_expert_payout
 └─> listens to cptt_after_manual_expert_payment

class-cptt-finance-erp.php
 ├─> listens to same hooks
 └─> also observes _cptt_steps meta changes
```

## 13.5 Payment flow dependency

```text
class-cptt-payment.php
 ├─> class-cptt-core.php (ledger_add, activity_log)
 ├─> _cptt_steps (apply_payment_to_project)
 ├─> cptt_payment_receipt CPT
 └─> optionally Bale notifications
```

---

# 14) Flow Diagram (نمودار متنی جریان سیستم)

## 14.1 Create Voucher (Manual ERP)

```text
User clicks "ثبت سند جدید" (ERP UI)
↓
Frontend form state (rows/date/description)
↓
Client-side debit/credit validation
↓
AJAX: cpttf_erp_voucher_save
↓
check_perm('voucher_create')
↓
validate_voucher_rows()
↓
reject_if_locked(date)
↓
insert_voucher_into_table()
↓
wp_cptt_erp_vouchers
+
wp_cptt_erp_voucher_rows
↓
ajax_full_bootstrap / ajax_bootstrap_reports
↓
Frontend vouchers payload
↓
Documents / Journal / GL / Subsidiary / Trial Balance / P&L / Balance Sheet
```

## 14.2 Auto Voucher from Business Event

```text
Business Action (income / expense / quick pay / payable pay / installment pay / treasury transfer / expert payout ...)
↓
Operational data update
   (_cptt_steps or ledger tables or payables/installments/...)
↓
gen_voucher()
↓
insert_voucher_into_table()
↓
Voucher + VoucherRows become available to ERP reports
↓
Reports recalculate on next bootstrap/render
```

## 14.3 Project Payment (Card receipt approved)

```text
Customer submits receipt
↓
Receipt approved in Payment module
↓
CPTT_Core::ledger_add(type=customer_card_payment)
↓
apply_payment_to_project()
↓
update _cptt_steps[].paid
↓
update _cptt_is_settled
↓
(no guaranteed ERP voucher in same flow unless separate sync/backfill layer catches it)
```

## 14.4 Expert Settlement (Classic)

```text
Admin settles project step in classic accounting page
↓
update _cptt_steps expert_paid / step_settled
↓
CPTT_Core::ledger_add(type=expert_step_settlement or expert_step_partial)
↓
do_action('cptt_after_expert_payout')
↓
CPTT_Finance::log_expert_payout() -> cptt_fin_ledger
+
CPTT_Finance_ERP::auto_voucher_expert_payout() -> ERP voucher
```

## 14.5 Reports pipeline (current real architecture)

```text
Project meta (_cptt_steps)
 ├─> Legacy KPIs / Receivables / Gross Profit / Payout summaries
 ├─> Some operational actions
 └─> Some sync / auto-voucher routines

Finance ledger (cptt_fin_ledger)
 ├─> Treasury / Monthly Chart / Categories / Bank Recon
 └─> Some virtual/backfill voucher generation

Core ledger (cptt_ledger)
 ├─> Settlement history / payment history
 └─> Some virtual/backfill voucher generation

ERP vouchers + rows
 ├─> Documents
 ├─> Journal
 ├─> General Ledger
 ├─> Subsidiary Ledger
 ├─> Trial Balance
 ├─> Income Statement
 └─> Balance Sheet
```

---

# 15) مشکلات احتمالی (فقط شناسایی، بدون اصلاح)

## 15.1 چندمنبعی بودن داده‌ها
- `_cptt_steps`
- `wp_cptt_fin_ledger`
- `wp_cptt_ledger`
- `wp_cptt_erp_vouchers`
- `wp_options` arrays

## 15.2 نبود Single Source of Truth واحد
- Reality of project receivable/payable در `_cptt_steps`
- Formal accounting report basis در voucher rows
- Cash basis در finance ledger
- Settlement history in core ledger

## 15.3 منطق‌های محاسباتی تکراری
- project cost/paid/remain در چند کلاس و چند تابع
- profit در چند تعریف مختلف
- balance در چند مسیر مختلف

## 15.4 گزارش‌های ERP client-side هستند
- Journal / GL / Subsidiary / Trial / P&L / BS در frontend aggregation انجام می‌شوند
- خطر divergence اگر payload ناقص یا synthetic باشد

## 15.5 Reportها از Ledger تولید نمی‌شوند
- بر خلاف الگوی کلاسیک حسابداری، reportهای استاندارد ERP مستقیماً از **VoucherRows** تولید می‌شوند، نه از Journal table یا Ledger table مستقل

## 15.6 Journal جدول مستقل ندارد
- Journal صرفاً flatten view روی VoucherRows است
- بنابراین پاسخ به پرسش «Ledger از Journal تغذیه می‌شود؟» در این معماری منفی است

## 15.7 Ledger دوگانه
- `cptt_fin_ledger`
- `cptt_ledger`

## 15.8 مفهوم "voucher_id" یکنواخت نیست
- برخی مسیرها ref_type/ref_id دارند
- برخی backfill/virtual logicها بر اساس matching heuristic کار می‌کنند
- FK فیزیکی صریح بین ledger و voucher در همه جا وجود ندارد

## 15.9 مدل Supplier مستقل نیست
- فقط رشته/enum داخل payable است

## 15.10 Customer هم profile-first نیست
- بیشتر به‌صورت wp_user + project relation تعریف شده

## 15.11 Currency architecture دوگانه است
- `CPTT_Currency` display-only
- `OPT_CURRENCY_RATES` در ERP phase 8 برای تبدیل نرخ‌ها
- full accounting multi-currency ledger پیاده‌سازی نشده

## 15.12 Status semantics چندلایه‌اند
- voucher status
- FY status
- payable status
- installment status
- cheque status
- project settled
- step status
- step settlement status

## 15.13 استفاده زیاد از Option arrays
- COA
- Cost centers
- FYs
- Locks
- Companies
- Branches
- Recurring
- Rates
- Permissions
- …

این برای auditability و transactional consistency نسبت به table-backed domain model ضعیف‌تر است.

## 15.14 نبود Repository / Query abstraction
- SQLها مستقیماً در کلاس‌ها و توابع پراکنده‌اند
- تغییر schema یا behavior پرریسک‌تر می‌شود

## 15.15 virtual / synthetic / backfill logic
- وجود چند لایه برای «جبران داده‌ی ناقص تاریخی» خودش ریسک پیچیدگی بالاست

## 15.16 Dead / Weakly-used code محتمل
- برخی مسیرهای fallback legacy (`OPT_VOUCHERS`, legacy readers)
- بعضی admin pages که بعد از ERP هنوز موازی هستند
- برخی virtual voucher/backfill paths که ممکن است در بعضی deployments دیگر لازم نباشند

## 15.17 query diversity برای مفاهیم مشابه
- مطالبات مشتری از `_cptt_steps`
- party statement از voucher rows (+ sometimes cptt_ledger)
- monthly charts از finance ledger + project meta
- bank reconciliation از finance ledger

## 15.18 گزارش سود و زیان و ترازنامه وابسته به account code prefix هستند
- اگر CoA codeها تغییر کنند و prefix convention نقض شود، report semantics آسیب می‌بیند

---

# 16) جدول نهایی جمع‌بندی

| بخش | فایل | کلاس/ماژول | تابع/نقطه کلیدی | منبع داده | وضعیت |
|---|---|---|---|---|---|
| Bootstrap افزونه | `client-project-tracker.php` | — | require/activation hooks | — | فعال |
| هسته پروژه | `class-cptt-core.php` | `CPTT_Core` | `ledger_add`, `activity_log`, meta registration | `wp_cptt_ledger`, post meta | فعال |
| حسابداری کلاسیک | `class-cptt-admin.php` | `CPTT_Admin` | `render_accounting_page`, `ajax_step_settle`, `ajax_quick_pay` | `_cptt_steps`, `wp_cptt_ledger` | فعال |
| داشبورد کارشناس | `class-cptt-expert.php` | `CPTT_Expert` | `collect_dashboard_stats` | `_cptt_steps` | فعال |
| مالی legacy | `class-cptt-finance.php` | `CPTT_Finance` | `account_balance`, `compute_kpis`, `monthly_series`, `ledger_insert` | `wp_cptt_fin_*`, `_cptt_steps` | فعال |
| خزانه legacy UI | `page-treasury.php` | function | `cpttf_render_treasury` | `wp_cptt_fin_accounts`, `wp_cptt_fin_ledger` | فعال |
| درآمد/هزینه legacy UI | `page-transactions.php` | function | `cpttf_render_transactions` | `wp_cptt_fin_ledger` | فعال |
| مطالبات legacy UI | `page-receivables.php` | function | `cpttf_render_receivables` | `_cptt_steps` | فعال |
| گردش حساب legacy UI | `page-ledger.php` | function | `cpttf_render_ledger` | `wp_cptt_fin_ledger` | فعال |
| تسویه legacy UI | `page-payouts.php` | function | `cpttf_render_payouts` | `_cptt_steps`, `expert_settlements` | فعال |
| دسته‌ها legacy UI | `page-categories.php` | function | `cpttf_render_categories` | `wp_cptt_fin_categories` | فعال |
| ارز | `class-cptt-currency.php` | `CPTT_Currency` | `format`, `from_base`, `to_base` | option `cptt_currency_settings` | فعال |
| پرداخت | `class-cptt-payment.php` | `CPTT_Payment` | `apply_payment_to_project`, receipt approval | `_cptt_steps`, `wp_cptt_ledger` | فعال |
| ERP backend | `class-cptt-finance-erp.php` | `CPTT_Finance_ERP` | `ajax_voucher_save`, `gen_voucher`, `read_vouchers_from_table`, reports, FY, locks | vouchers/rows + options + ledgers | فعال |
| ERP frontend | `assets/finance-ui/app.js` | bundle minified | `pj/mh/vj/jj/bj/...` | bootstrap payloads | فعال |
| ERP styles | `assets/finance-ui/app.css` | CSS | — | — | فعال |
| Legacy finance JS | `assets/js/finance.js` | JS module | CRUD/forms/charts/datepicker | AJAX + DOM | فعال |
| Legacy finance CSS | `assets/css/finance.css` | CSS | — | — | فعال |

---

# 17) ارزیابی معماری (Architectural Assessment)

## آیا ساختار سیستم از استانداردهای حسابداری تبعیت می‌کند؟
**تا حدی بله، اما نه به‌صورت خالص و یکنواخت.**

- وجود Voucher و VoucherRows، دوبل‌انتری، Trial Balance، P&L، Balance Sheet و FY Close نشان می‌دهد که ERP layer به سمت استاندارد حسابداری حرکت کرده است.
- اما چون داده‌های عملیاتی پروژه و خزانه و تسویه در چند منبع موازی قرار دارند، معماری هنوز کاملاً استاندارد و یکپارچه نیست.

## آیا Journal منبع اصلی ثبت اسناد است؟
**خیر.**

- Journal table یا model مستقل وجود ندارد.
- Journal یک **report/view** است که از VoucherRows flatten می‌شود.

## آیا Ledger از Journal تغذیه می‌شود؟
**خیر.**

- در این پروژه Ledger و Journal دو مسیر متفاوت‌اند.
- `wp_cptt_fin_ledger` و `wp_cptt_ledger` مستقیماً توسط business actions پر می‌شوند.
- Journal از VoucherRows ساخته می‌شود.

## آیا گزارش‌ها از Ledger تولید می‌شوند یا مستقیماً از Journal؟
### گزارش‌های استاندارد ERP:
- **نه از Ledger**، نه از Journal table مستقل
- بلکه **مستقیماً از VoucherRows** (client-side aggregation)

### گزارش‌های legacy مالی:
- treasury / monthly / category breakdown / bank recon بیشتر از `wp_cptt_fin_ledger`

### برخی dashboard/KPIها:
- مستقیماً از `_cptt_steps`

## آیا چند مسیر مختلف برای محاسبات وجود دارد؟
**بله، به‌وضوح.**

حداقل این مسیرها موازی‌اند:
- `_cptt_steps`
- `wp_cptt_fin_ledger`
- `wp_cptt_ledger`
- `wp_cptt_erp_vouchers + rows`
- virtual/backfill voucher layer

## آیا احتمال وجود باگ منطقی در ساختار سیستم وجود دارد؟
**بله، بالا.**

دلایل:
- چند منبع داده برای یک مفهوم واحد
- duplicate logic در محاسبات
- reportهای client-side
- reliance on account code prefixes
- legacy + ERP coexistence
- hook-based synchronization به‌جای transactional core domain pipeline واحد

## آیا معماری فعلی مقیاس‌پذیر است؟
**در سطح متوسط.**

نکات مثبت:
- ERP vouchers/rows table-backed شده‌اند
- indexes اضافه شده‌اند
- audit table وجود دارد
- chunked bootstrap endpoints وجود دارند

نکات منفی:
- frontend هنوز همه‌چیز را بیشتر client-side aggregate می‌کند
- option arrays هنوز زیادند
- چند ledger موازی و چند منبع محاسبه scalability منطقی/تحلیلی را سخت می‌کند

## آیا بخشی نیاز به یکپارچه‌سازی دارد؟
**بله، به‌شدت.**

اولویت‌های یکپارچه‌سازی از منظر معماری:
1. تعیین SoT واحد برای reality مالی پروژه
2. تعیین SoT واحد برای cash ledger
3. اتصال صریح ledger ↔ voucher (FK/semantic link)
4. تبدیل Journal/Trial/P&L/BS به server-side report service یا حداقل report query layer واحد
5. حذف duplicate project financial aggregation logic
6. کم‌کردن reliance on option arrays برای domain-heavy models

---

# نتیجه نهایی Audit

سیستم حسابداری فعلی، یک **معماری هیبریدی و لایه‌لایه** است که از نظر امکانات غنی است، اما از نظر معماری داده و مسیر محاسبات **کاملاً یکپارچه نیست**.

### نقاط قوت
- ERP voucher model نسبتاً کامل
- دوبل‌انتری و reportهای اصلی موجود
- mapping، FY close، locks، audit، invoice, cheque, payable, installment موجود
- legacy finance subsystem برای خزانه و عملیات روزانه فعال است

### نقاط ریسک
- نبود Single Source of Truth واحد
- دو ledger مجزا
- محاسبات تکراری فراوان
- reportهای client-side بر پایه‌ی payload
- Journal به‌عنوان view، نه register مستقل
- وابستگی reportها به prefix کد حساب

### قضاوت معماری
این سیستم برای **استفاده عملی** قابل بهره‌برداری است، اما برای **Audit-grade accounting architecture** هنوز نیازمند **یکپارچه‌سازی مفهومی و داده‌ای** است.

---

## پیوست: فهرست مهم‌ترین توابع برای ردیابی سریع

### ERP backend
- `ajax_full_bootstrap()`
- `ajax_bootstrap_reports()`
- `get_vouchers()`
- `read_vouchers_from_table()`
- `gen_voucher()`
- `validate_voucher_rows()`
- `gen_reverse_voucher()`
- `get_coa_with_balances()`
- `compute_pl_range()`
- `fy_pl_summary()`
- `fy_permanent_balances()`
- `ajax_cash_flow()`
- `ajax_period_compare()`
- `ajax_budget_actual()`
- `ajax_aging_custom()`
- `ajax_wip_report()`
- `ajax_bank_recon()`
- `build_receivables()`
- `build_projects_full()`
- `build_settlement_history()`
- `build_incomes_expenses()`
- `build_party_accounts()`

### Legacy finance
- `account_balance()`
- `account_balance_at()`
- `ledger_insert()`
- `compute_kpis()`
- `monthly_series()`
- `top_customers_series()`
- `category_breakdown()`

### Project/admin layer
- `project_financial_data()`
- `ajax_quick_pay()`
- `ajax_step_settle()`
- `ajax_manual_expert_payment()`
- `apply_payment_to_project()`
- `project_remaining()`

---

**پایان گزارش**
