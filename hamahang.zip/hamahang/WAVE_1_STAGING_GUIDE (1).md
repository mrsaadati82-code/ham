# WAVE_1_STAGING_GUIDE

> راهنمای ساده اجرای Wave 1 روی staging  
> وضعیت: برای اجرای واقعی — نه برای production مستقیم

---

# 1) هدف Wave 1

در Wave 1 این چیزها وارد سیستم می‌شوند:

- نسخه جدید افزونه
- schema version جدید
- جدول فیزیکی `Journal`
- جدول فیزیکی `General Ledger`
- مکانیزم `rebuild / reproject` از روی `Voucher` و `VoucherRow`
- جلوگیری از delete سند finalized
- جلوگیری از unfinalize سندی که وارد Journal/GL شده

---

# 2) قبل از نصب روی staging

حتماً این کارها انجام شود:

- backup کامل دیتابیس
- backup فایل‌های افزونه
- ثبت baseline اعداد فعلی:
  - تعداد voucherها
  - جمع بدهکار/بستانکار voucherها
  - اسکرین‌شات Documents / Journal / GL / TB / P&L / BS
- ثبت نسخه فعلی افزونه قبل از نصب

---

# 3) فایل اجرایی این Wave

فایل zip این release باید نصب شود:

- `client-project-tracker-8.1.1.zip`

---

# 4) بعد از نصب روی staging چه اتفاقی باید بیفتد

در اولین load ادمین:
- migration runner اجرا می‌شود
- جدول‌های جدید ساخته می‌شوند
- voucherها به‌عنوان truth بررسی می‌شوند
- Journal و GL از روی voucherهای finalized rebuild می‌شوند

---

# 5) چیزهایی که باید چک شوند

## 5.1 ساخت جدول‌ها
باید وجود داشته باشند:
- `{$wpdb->prefix}cptt_erp_journal`
- `{$wpdb->prefix}cptt_erp_gl`

## 5.2 schema version
باید option version جدید ثبت شده باشد:
- `cpttf_erp_db_version = 4.0.0`

## 5.3 projection state
باید rebuild state ثبت شده باشد:
- `cpttf_erp_projection_state`

## 5.4 اعداد اصلی
باید این‌ها درست باشند:
- voucher debit total = voucher credit total
- journal debit total = voucher debit total
- journal credit total = voucher credit total
- GL debit total = journal debit total
- GL credit total = journal credit total

---

# 6) تست رفتاری ساده بعد از نصب

## تست 1
یک سند draft دستی بساز
- باید در voucher table ذخیره شود
- نباید در Journal/GL بیاید

## تست 2
همان سند را finalized کن
- باید projection آن در Journal/GL ساخته شود

## تست 3
روی سند finalized دکمه delete را تست کن
- باید اجازه حذف ندهد

## تست 4
روی سند finalized که وارد Journal/GL شده unfinalize را تست کن
- باید اجازه بازکردن ندهد
- پیام بدهد که از Reversal استفاده شود

## تست 5
یک سند auto-generated ایجاد شود
- باید مستقیم `FINALIZED` باشد
- باید در Journal/GL materialize شود

---

# 7) اگر مشکلی دیدی

## حالت 1
جدول‌ها ساخته نشده‌اند
- migration اجرا نشده یا fail شده

## حالت 2
Journal/GL ساخته شده ولی countها صفر است
- voucher truth finalized شاید وجود ندارد یا rebuild fail شده

## حالت 3
جمع‌ها برابر نیستند
- migration را ادامه نده
- cutover گزارش‌ها را شروع نکن
- اول discrepancy را بررسی کن

---

# 8) rollback ساده Wave 1

اگر Wave 1 fail شد:
- از backup staging برگرد
- release را promote نکن
- روی data live هیچ کاری انجام نده

### rule مهم
GL و Journal را با patch دستی «سریع درست» نکن.  
یا باید rebuild کنی، یا باید restore کنی.

---

# 9) نتیجه مطلوب Wave 1

Wave 1 وقتی موفق است که:
- جدول‌های Journal و GL ساخته شده باشند
- rebuild از روی voucherها انجام شده باشد
- جمع‌ها دقیق برابر باشند
- ERP هنوز نشکسته باشد
- هنوز cutover گزارش‌ها شروع نشده باشد

---

**پایان راهنمای Wave 1**
