# PHASE_11_REPORT

> Phase 11 Execution Artifact  
> Program: ERP Refactor / Accounting Unification  
> Source references: `ACCOUNTING_SYSTEM_ANALYSIS.md`, `ERP_ARCHITECTURE.md`, `ERP_REFACTOR_ROADMAP.md`, `ERP_UI_ARCHITECTURE_CURRENT.md`, `PHASE_0_REPORT.md`, `PHASE_1_REPORT.md`, `PHASE_2_REPORT.md`, `PHASE_3_REPORT.md`, `PHASE_4_REPORT.md`, `PHASE_5_REPORT.md`, `PHASE_6_REPORT.md`, `PHASE_7_REPORT.md`, `PHASE_8_REPORT.md`, `PHASE_9_REPORT.md`, `PHASE_10_REPORT.md`  
> Additional binding decisions: user-approved UI target = ERP Accounting Panel  
> Mode: **No code change / No schema change in this turn / Integration & Externalization Plan only**

---

# 0) اعلام صریح قبل از شروع

## 0.1 پاسخ کوتاه و ساده

**در این نوبت فقط فاز ۱۱ را به‌صورت گزارش معماری اجرا کرده‌ام و هیچ کدی را تغییر نداده‌ام.**

یعنی الان:
- هیچ REST API جدیدی ساخته نشده
- هیچ webhook جدیدی فعال نشده
- هیچ cron job جدیدی عوض نشده
- هیچ اعلان جدیدی ارسال نمی‌شود
- هیچ import/export واقعی تغییر نکرده
- هیچ کلید API یا policy امنیتی تغییر نکرده

## 0.2 اما اجرای واقعی این فاز چه می‌خواهد؟

اجرای واقعی Phase 11 حتماً نیاز دارد به:
- تغییر کد backend
- تعریف contractهای API جدید
- versioning endpointها در صورت نیاز
- بازنویسی بعضی webhook pathها
- هم‌راستا کردن اعلان‌ها با eventهای رسمی
- تغییر cronها و import/exportها
- تست staging برای integrationها

### نتیجه عملی
**اجرای واقعی Phase 11 فقط باید روی staging و با backup کامل انجام شود.**

---

# 1) هدف این گزارش

این سند، شروع اجرایی **Phase 11 — Integration & Externalization Plan** است و فقط روی این موارد تمرکز دارد:

1. تعیین مسیر نهایی **Webhook Event**ها از posting pipeline
2. تعیین **REST API Contract** نهایی بر پایه read modelهای رسمی
3. تعیین policy اعلان‌ها بر پایه **event bus واحد**
4. تعیین **Import Strategy**
5. تعیین **Print Strategy**
6. تعیین **Cron Strategy**
7. تعیین اصول امنیت، versioning و backward compatibility در integration layer
8. هم‌راستا نگه داشتن integrationها با این تصمیم قطعی که **UI نهایی همان ERP Accounting Panel** است
9. ثبت **Ambiguity Register فاز ۱۱** برای تصمیم‌گیری قبل از فاز بعد

> این سند عمداً هیچ تغییری در کد، schema، query اجرایی، migration واقعی یا رفتار runtime ایجاد نمی‌کند.

---

# 2) اصل بنیادین Integration Layer

## 2.1 اصل اصلی

Integration Layer نباید مسیر موازی داده بسازد.

یعنی:
- webhook نباید ledger جدا بسازد
- API نباید truth موازی بسازد
- cron نباید منطق حسابداری موازی اجرا کند
- import نباید bypass pipeline باشد
- print نباید از source غیررسمی تغذیه شود

## 2.2 قاعده‌ی نهایی

همه integrationها باید از این chain تبعیت کنند:

```text
Business Input / External Trigger
↓
Canonical Service Command
↓
Voucher / VoucherRow
↓
Posting
↓
Journal / GL / Read Models
↓
API / Webhook / Notification / Print / Export
```

## 2.3 معنی ساده

هر چیزی که از سیستم بیرون می‌رود یا از بیرون وارد سیستم می‌شود، باید از مسیر رسمی حسابداری عبور کند، نه از راه‌های قدیمی و پراکنده.

---

# 3) Inventory کلی Integration Surfaceهای فعلی

## 3.1 REST / AJAX / External-ish Surfaces

در وضعیت فعلی پروژه این surfaceها وجود دارند:
- ERP AJAX endpointها
- بعضی REST routeهای ERP
- payment callbackها
- cron hookها
- Bale / notification paths
- import/export/print semantics در بعضی pageها
- option-based webhook/api key configuration surfaces

## 3.2 Cron Surfaceها

از تحلیل قبلی:
- `cpttf_erp_daily_cron`
- `cpttf_erp_hourly_cron`

## 3.3 Payment Callback Surfaceها

از payment module:
- `admin_post_cptt_online_callback`
- `admin_post_nopriv_cptt_online_callback`

## 3.4 Notification Surfaceها

در پروژه مسیرهای اعلان/ارتباطی وجود دارند، مثل:
- `CPTT_Bale`
- اعلان‌های مالی مرتبط با receipt/project/expert

## 3.5 Print / Export Surfaceها

در ERP و بعضی بخش‌های مالی، print/export behavior وجود دارد، ولی در معماری فعلی هنوز لازم است source آن‌ها رسمی و واحد شود.

## 3.6 نتیجه

Integration Surface فعلی وجود دارد، ولی policy آن هنوز canonical و یکپارچه نیست.  
Phase 11 باید همین را formalize کند.

---

# 4) Webhook Event Policy

## 4.1 اصل اصلی

Webhook باید **مصرف‌کننده‌ی event رسمی بعد از posting** باشد، نه producer حقیقت موازی.

## 4.2 Rule مهم

Webhook خروجی فقط از این eventهای رسمی مجاز است:
- Voucher Posted
- Voucher Reversed
- Fiscal Year Closed
- Fiscal Year Reopened
- Payable Paid
- Installment Received
- Cheque Status Changed with accounting effect
- Invoice Converted To Voucher

## 4.3 چیزی که ممنوع است

Webhook نباید از این‌ها مستقیم تغذیه شود:
- `_cptt_steps` raw mutation
- `wp_cptt_fin_ledger`
- `wp_cptt_ledger`
- client-side UI state
- synthetic voucher logic

## 4.4 مدل پیشنهادی Eventها

### Eventهای canonical خروجی
- `voucher.posted`
- `voucher.reversed`
- `payable.paid`
- `installment.received`
- `fiscal_year.closed`
- `fiscal_year.reopened`
- `cheque.accounting_changed`
- `invoice.voucher_created`

## 4.5 Payload Policy

هر webhook payload باید حداقل این فیلدها را داشته باشد:
- `eventName`
- `eventId`
- `occurredAt`
- `sourceType`
- `sourceId`
- `voucherId?`
- `voucherType?`
- `fiscalYearId?`
- `companyId?`
- `branchId?`
- `correlationId?`
- `causationId?`

## 4.6 Delivery Rule

Webhook delivery باید:
- idempotent باشد
- retry-safe باشد
- failure logging داشته باشد
- مسیر موازی truth نسازد

## 4.7 Webhook Consumer Rule

اگر external consumer خواست چیزی را برگرداند یا sync کند، آن ورودی دوباره باید وارد **command layer** شود، نه اینکه مستقیم ledger/report را تغییر دهد.

---

# 5) REST API Strategy

## 5.1 اصل اصلی

REST API نهایی باید فقط روی **read modelهای رسمی** و **commandهای رسمی** بنا شود.

## 5.2 تفکیک مهم

### A) Read APIs
برای گرفتن گزارش‌ها، snapshotها، statementها، party/project/treasury views

### B) Command APIs
برای عملیات‌های رسمی مثل:
- create voucher draft
- post voucher
- reverse voucher
- register receipt
- register settlement
- pay payable
- receive installment

## 5.3 Rule مهم

APIهای read نباید truth بسازند.  
APIهای command هم نباید bypass pipeline باشند.

## 5.4 Read API Source Policy

| API family | Source رسمی |
|---|---|
| Documents API | Voucher/VoucherRow |
| Journal API | Journal table |
| GL API | GL table |
| Subsidiary API | GL + dimensions |
| TB API | TB read model |
| P&L API | statement read model |
| BS API | statement read model |
| Dashboard API | official reporting read models |
| Party Financial API | PartyFinancialReadModel |
| Project Financial API | ProjectFinancialSnapshot |
| Treasury Summary API | TreasuryBalanceReadModel |

## 5.5 Command API Policy

Command API باید فقط command canonical بگیرد و نتیجه‌ی رسمی برگرداند.

### مثال‌ها
- `CreateDraftVoucher`
- `ApproveVoucher`
- `PostVoucher`
- `ReverseVoucher`
- `RegisterCustomerReceipt`
- `RegisterExpertSettlement`
- `RegisterTreasuryInflow`
- `RegisterTreasuryOutflow`
- `TransferBetweenTreasuryAccounts`
- `PayPayable`
- `ReceiveInstallment`

## 5.6 API Versioning Policy

چون پروژه در دوره‌ی گذار است، APIها باید version-aware باشند.

### Rule پیشنهادی
- breaking contractها version شوند
- read API responseها metadata version داشته باشند
- legacy-compatible response adapterها time-boxed باشند

### مثال مفهومی
- `v1` = legacy compatibility
- `v2` = canonical read model contract

> این naming فقط مفهومی است؛ implementation واقعی در این نوبت انجام نمی‌شود.

## 5.7 Security Rule

APIها باید حداقل این policyها را رعایت کنند:
- capability/permission check
- nonce/session policy برای admin-side actions
- API key policy برای external consumers
- audit trail برای financial commands
- rate-limit where relevant

---

# 6) Notification / Event Bus Policy

## 6.1 مسئله فعلی

در پروژه اعلان‌ها در بعضی flowها وجود دارند، ولی هنوز از event bus واحد و canonical تغذیه نمی‌شوند.

## 6.2 تصمیم Phase 11

اعلان‌ها باید از **event bus واحد** تغذیه شوند.

## 6.3 Event Bus Rule

هر اعلان باید به یک event رسمی وصل باشد، نه به mutationهای پراکنده.

### مثال
- receipt approved → after canonical receipt posting or state transition
- expert settlement done → after canonical settlement event
- payable paid → after payable payment command success
- installment overdue reminder → from read model / scheduler
- fiscal close notice → after official close event

## 6.4 Notification Categories

### A) Transactional Notifications
مرتبط با عملیات مالی رسمی

### B) Informational Notifications
مرتبط با dashboard/reminder/status

### C) Reminder Notifications
موارد زمان‌محور مثل سررسیدها

## 6.5 Rule مهم

اعلان نباید producer truth باشد.  
اعلان فقط بازتاب event رسمی است.

## 6.6 Delivery Channels

کانال‌ها می‌توانند شامل این‌ها باشند:
- admin notice
- in-app notification
- Bale
- SMS / پیامک (اگر در scope deployment باشد)
- email (اگر در scope deployment باشد)

### اما همه باید از event bus واحد تغذیه شوند.

---

# 7) Import Strategy

## 7.1 اصل کلی

Import نباید bypass accounting pipeline باشد.

## 7.2 سه نوع Import مجاز

### Type A — Import To Operational Draft
برای داده‌هایی که هنوز accounting-ready نیستند.

### Type B — Import To Voucher Draft
برای داده‌هایی که accounting semantics روشن دارند ولی قبل از posting باید review شوند.

### Type C — Import To Canonical Business Command
برای بعضی importهای ساختاریافته که مستقیم به command رسمی تبدیل می‌شوند.

## 7.3 چیزی که ممنوع است

Import مستقیم به این‌ها ممنوع است:
- Journal table
- GL table
- Trial Balance
- Statement read modelها

## 7.4 Import Validation Rules

هر import باید حداقل این validateها را داشته باشد:
- schema validation
- account resolution validation
- party resolution validation
- fiscal date validation
- duplicate detection by `sourceType + sourceId`
- amount validation
- currency consistency validation if relevant

## 7.5 Import Result Policy

خروجی import باید یکی از این‌ها باشد:
- accepted as draft
- accepted as command queue
- rejected with reason
- partial accepted + review queue

## 7.6 Historical Import Rule

برای historical importها:
- low-confidence data = archive-only
- duplicate prevention = `sourceType + sourceId`
- variance tolerance = zero for official accounting acceptance

---

# 8) Print Strategy

## 8.1 اصل کلی

Print باید فقط از **report layer رسمی** یا **voucher document source رسمی** بیاید.

## 8.2 چیزی که ممنوع است

Print نباید از این‌ها تغذیه شود:
- client aggregation
- browser cached unofficial totals
- legacy mixed-source page state

## 8.3 Print Source Mapping

| Print Surface | Source رسمی |
|---|---|
| Voucher print | Voucher/VoucherRow |
| Journal print | Journal read model/table |
| GL print | GL read model/table |
| Subsidiary print | GL + dimensions |
| TB print | TB read model |
| P&L print | statement read model |
| BS print | statement read model |
| Dashboard print/export | official dashboard read models |

## 8.4 Print Metadata Rule

هر print/export باید metadata کافی داشته باشد:
- generatedAt
- sourceLayer
- filters applied
- fiscal scope
- page/report version
- totals

## 8.5 UI Rule

دکمه‌های print/export در ERP panel فقط trigger هستند؛ source رسمی backend است.

---

# 9) Cron Strategy

## 9.1 اصل کلی

Cron نباید منطق حسابداری موازی بسازد.  
Cron فقط می‌تواند:
- command زمان‌دار رسمی بسازد
- reminder/read model refresh انجام دهد
- rebuild/reproject schedule شده را اجرا کند
- maintenance غیرحسابداری انجام دهد

## 9.2 Cron Families

### A) Recurring Financial Commands
اگر recurring financial logic وجود دارد، باید وارد voucher pipeline شود.

### B) Reminder Cron
مثل overdue reminderها که باید از read modelهای رسمی استفاده کنند.

### C) Projection Maintenance Cron
مثل rebuild/reproject validation یا scheduled refresh.

### D) Integration Retry Cron
برای webhook retry / notification retry / import queue retry.

## 9.3 Rule مهم

cron نباید:
- مستقیم GL بنویسد خارج از posting/rebuild رسمی
- truth جدید بسازد بدون command رسمی
- legacy ledgerها را دوباره truth owner کند

## 9.4 Existing Cron Alignment

cronهای فعلی مثل:
- `cpttf_erp_daily_cron`
- `cpttf_erp_hourly_cron`

باید در target architecture نقش‌شان شفاف شود:
- reminder
- maintenance
- rebuild support
- integration retry

نه accounting truth owner.

---

# 10) Integration Security & Governance

## 10.1 اصل کلی

Integrationها چون از بیرون سیستم هم داده می‌گیرند/می‌دهند، باید governance روشن داشته باشند.

## 10.2 Governance Rules

1. هیچ integration truth موازی نسازد
2. همه commandهای مالی audit trail داشته باشند
3. همه external callbackها idempotent باشند
4. همه webhook deliveryها log شوند
5. API keyها و secretها rotation-friendly باشند
6. read vs write capability از هم جدا باشد

## 10.3 Idempotency Rule for Integrations

برای integrationهای خارجی، deduplication باید بر پایه business key رسمی باشد:
- `sourceType + sourceId`
- plus provider event id if applicable

## 10.4 Audit Rule

برای هر integration write باید حداقل ثبت شود:
- actor/source system
- time
- command type
- accepted/rejected status
- resulting voucher id if any

---

# 11) Backward Compatibility Policy

## 11.1 اصل کلی

در دوره‌ی گذار، بعضی integrationها ممکن است هنوز contract قدیمی را انتظار داشته باشند.

## 11.2 Rule پیشنهادی

Backward compatibility باید:
- time-boxed باشد
- explicit باشد
- documented باشد
- behind adapter/versioning باشد

## 11.3 چیزی که نباید رخ دهد

- contract قدیمی برای همیشه بماند
- adapter موقت تبدیل به مسیر اصلی شود
- compatibility path truth موازی بسازد

## 11.4 Compatibility Surfaces

این‌ها محتمل‌ترین جاهای compatibility هستند:
- بعضی AJAX responseها
- legacy page response shapes
- webhook payload consumer expectations
- import templateها

---

# 12) Externalization Strategy

## 12.1 معنی Externalization در این فاز

یعنی چیزهایی که به بیرون سیستم expose می‌شوند، باید روی model رسمی expose شوند.

## 12.2 چیزهایی که می‌توانند externalized شوند

- report read APIs
- print/export outputs
- webhook events
- reminder/notification outputs
- import endpoints/templates

## 12.3 چیزهایی که نباید externalized شوند

- raw legacy ledger semantics
- browser-side accounting formulas
- `_cptt_steps` as financial truth
- synthetic voucher semantics

---

# 13) Integration Layer Contract Map

## 13.1 Read Contract Families

| Contract Family | Owner | Source |
|---|---|---|
| Documents Read | reporting/read layer | Voucher/VoucherRow |
| Journal Read | reporting/read layer | Journal table |
| GL Read | reporting/read layer | GL table |
| TB Read | reporting/read layer | TB read model |
| Statement Read | reporting/read layer | statement read models |
| Dashboard Read | reporting/read layer | KPI read models |
| Party / Project / Treasury Read | reporting/read layer | official read models |

## 13.2 Command Contract Families

| Contract Family | Owner | Output |
|---|---|---|
| Voucher Commands | application services | Voucher + Posting |
| Receipt Commands | `CustomerReceiptService` | Voucher/Posting |
| Settlement Commands | `ExpertSettlementService` | Voucher/Posting |
| Treasury Commands | `TreasuryTransactionService`, `TreasuryTransferService` | Voucher/Posting |
| Payable Commands | `PayableService`, `PayablePaymentService` | domain + Voucher/Posting |
| Installment Commands | `InstallmentPlanService`, `InstallmentReceiptService` | domain + Voucher/Posting |
| Fiscal Commands | `FiscalYearClosingService` | close/open voucher chain |

## 13.3 Notification/Event Contract Families

| Contract Family | Source Event | Consumer |
|---|---|---|
| Transaction Notifications | posted/reversed/payment events | user/admin/external channels |
| Reminder Notifications | cron + read models | user/admin |
| Webhook Deliveries | canonical events | external systems |

---

# 14) ارتباط فاز ۱۱ با ERP UI

## 14.1 Rule اصلی

این فاز قرار نیست UI جدید خارج از ERP panel بسازد.

## 14.2 نتیجه

Integration layer باید در خدمت این‌ها باشد:
- ERP panel data feeds
- ERP exports/prints
- ERP-triggered commands
- external consumers of official data

## 14.3 چیزی که نباید رخ دهد

- APIهای موازی که UI دیگری را truth owner کنند
- webhookهایی که bypass ERP/reporting truth باشند
- import/exportهایی که source رسمی را دور بزنند

---

# 15) Risk Analysis فاز ۱۱

## 15.1 ریسک API contract شکسته
اگر APIها زود version نشوند یا adapter نداشته باشند:
- بعضی مصرف‌کننده‌ها می‌شکنند

## 15.2 ریسک webhook truth drift
اگر webhook از source غیررسمی تغذیه شود:
- external system data drift می‌گیرد

## 15.3 ریسک import bypass
اگر import مستقیم Journal/GL را پر کند:
- کل معماری Voucher-First خراب می‌شود

## 15.4 ریسک cron parallel logic
اگر cron همچنان منطق financial write موازی داشته باشد:
- hidden divergence ایجاد می‌شود

## 15.5 ریسک notification ownership ambiguity
اگر اعلان از mutation خام تغذیه شود نه از event رسمی:
- پیام اشتباه یا duplicate ارسال می‌شود

---

# 16) Rollback Plan برای Integration Cutover

## 16.1 اصل کلی

Rollback integration باید contract-by-contract باشد.

## 16.2 Rollback Levels

### Level 1 — Disable New Read Contract
read API جدید خاموش شود و path قبلی موقتاً برگردد

### Level 2 — Disable New Webhook Family
یک family از webhookها غیرفعال شود

### Level 3 — Re-enable Compatibility Adapter
adapter version قدیمی موقتاً برگردد

### Level 4 — Stop New Import Path
import جدید متوقف و queueها hold شوند

### Level 5 — Stop Integration Cutover Wave
اگر discrepancy شدید بود، موج integration متوقف شود

## 16.3 Rule مهم

Rollback نباید SoT را عوض کند.  
یعنی integration rollback شاید contract را برگرداند، ولی نباید truth ownership را به legacy برگرداند.

---

# 17) روش تست معماری Phase 11

## 17.1 Review Checklist

برای پذیرش این Phase باید این سوال‌ها پاسخ روشن داشته باشند:

1. آیا webhook path نهایی از posting pipeline تعریف شده؟
2. آیا REST APIها بر پایه read modelهای رسمی طراحی شده‌اند؟
3. آیا event bus / notification policy روشن شده؟
4. آیا import strategy مشخص شده؟
5. آیا print strategy رسمی شده؟
6. آیا cron strategy مشخص شده؟
7. آیا security/versioning/backward compatibility rules تعریف شده‌اند؟
8. آیا integration layer با ERP panel target هم‌راستاست؟
9. آیا rollback levels مشخص شده‌اند؟
10. آیا ambiguityهای فاز ۱۱ صریح ثبت شده‌اند؟

## 17.2 سناریوهای تست پیشنهادی

- read API contract compare old/new
- webhook payload validation
- external callback idempotency validation
- import dry-run to draft/command queue
- print/export reconciliation with reports
- cron reminder correctness from official read models
- notification dispatch after canonical posted events

---

# 18) ارزیابی انجام Taskهای Phase 11 نسبت به Roadmap

## 18.1 Taskهای Phase 11 در Roadmap

طبق `ERP_REFACTOR_ROADMAP.md`، Phase 11 شامل این موارد بود:
- تعیین مسیر نهایی Webhook events از posting pipeline
- تعیین contract نهایی REST API فقط روی read modelهای رسمی
- تعیین policy اعلان‌ها از event bus واحد
- تعیین Import strategy
- تعیین Print strategy
- تعیین Cron strategy

## 18.2 وضعیت این artefact

| Task | وضعیت |
|---|---|
| Webhook path | ✅ انجام شد |
| REST API contract strategy | ✅ انجام شد |
| notification/event bus policy | ✅ انجام شد |
| import strategy | ✅ انجام شد |
| print strategy | ✅ انجام شد |
| cron strategy | ✅ انجام شد |
| integration governance | ✅ انجام شد |
| rollback structure | ✅ انجام شد |
| ambiguity register | ✅ انجام شد |

## 18.3 Definition of Done Phase 11

Phase 11 زمانی Done تلقی می‌شود که:
1. integration layer فقط از canonical services/read models تغذیه شود ✅
2. هیچ integration مسیر داده موازی نسازد ✅
3. webhook/API/import/print/cron strategy مشخص شده باشد ✅
4. rollback strategy و compatibility policy مشخص شده باشد ✅
5. review ambiguityهای باز قبل از اجرا انجام شده باشد ⏳

### نتیجه
از منظر **مستندسازی معماری و برنامه‌ریزی integration**، Phase 11 در این artefact **شروع و تدوین شده است**؛  
اما از منظر **اجرای واقعی** هنوز نیازمند تصمیم روی چند ambiguity اجرایی، سطح versioning و mode بعضی import/notification contractها است.

---

# 19) Ambiguity Register فاز ۱۱

> این بخش باید قبل از اجرای واقعی integration cutover یا قبل از Phase 12 مرور شود.

## 19.1 آیا webhook payloadها full-detail باشند یا summary + fetch-link کافی است؟

### توضیح ساده
باید تصمیم بگیریم webhook داده‌ی کامل بفرستد یا فقط خلاصه و شناسه بدهد.

### وضعیت
**نیاز به تصمیم**

---

## 19.2 API versioning دقیقاً با route version انجام شود یا header/schema version metadata کافی است؟

### توضیح ساده
باید معلوم شود نسخه‌بندی API دقیقاً چطور انجام شود.

### وضعیت
**نیاز به تصمیم فنی**

---

## 19.3 import بعضی داده‌ها draft-based باشد یا command-queue-based؟

### توضیح ساده
برای بعضی importها هنوز باید تصمیم بگیریم داده اول draft شود یا مستقیم وارد صف command شود.

### وضعیت
**نیاز به تصمیم**

---

## 19.4 reminder notificationها real-time trigger داشته باشند یا فقط cron-based کافی است؟

### توضیح ساده
بعضی اعلان‌ها شاید لحظه‌ای لازم باشند، بعضی فقط روزانه/ساعتی کافی‌اند.

### وضعیت
**نیاز به تصمیم**

---

## 19.5 بعضی external callbackها بعد از validate شدن مستقیم posted command بسازند یا اول pending state بگیرند؟

### توضیح ساده
باید معلوم شود بعضی callbackهای بیرونی مستقیم سند مالی بسازند یا اول در وضعیت انتظار بروند.

### وضعیت
**نیاز به تصمیم**

---

## 19.6 print/export همزمان با هر report cutover release شود یا در release جدا؟

### توضیح ساده
هنوز باید تصمیم بگیریم print/export هر گزارش همان موج تغییر کند یا بعداً.

### وضعیت
**نیاز به تصمیم**

---

## 19.7 event bus implementation در اجرا synchronous باشد یا queue-based؟

### توضیح ساده
باید معلوم شود eventها همان لحظه اجرا شوند یا وارد صف شوند.

### وضعیت
**نیاز به تصمیم اجرایی**

---

# 20) جمع‌بندی نهایی Phase 11

مهم‌ترین خروجی Phase 11 این است که از اینجا به بعد، ارتباط سیستم با دنیای بیرون نباید از راه‌های پراکنده و قدیمی انجام شود.

### نتیجه‌های کلیدی
- webhook path نهایی بر پایه posting pipeline تعریف شد
- REST API روی read modelهای رسمی سوار شد
- notification policy از event bus واحد تعریف شد
- import strategy رسمی شد و direct write به Journal/GL ممنوع شد
- print strategy رسمی شد و source آن واحد شد
- cron strategy مشخص شد و parallel logic ممنوع شد
- governance و rollback structure برای integration layer تعریف شد
- ERP panel به‌عنوان UI هدف حفظ شد

### اصل نهایی این فاز

```text
External integrations may connect anywhere.
They must trust only the canonical accounting path.
```

و به زبان ساده‌تر:

```text
سیستم می‌تواند با بیرون از خودش زیاد ارتباط داشته باشد،
اما همه‌ی این ارتباط‌ها باید فقط به مسیر رسمی حسابداری وصل باشند.
```

---

**پایان گزارش Phase 11**
