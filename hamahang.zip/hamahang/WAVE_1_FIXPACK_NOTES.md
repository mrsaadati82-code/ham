# WAVE_1_FIXPACK_NOTES

> نسخه: 8.1.2  
> هدف: رفع باگ‌های بلوکه‌کننده‌ی Wave 1 بعد از تست staging/localhost

---

# باگ‌هایی که در این fix pack هدف گرفته شدند

## 1) خطای برگشت سند

### مشکل
روی دکمه «برگشت سند» خطای زیر دیده می‌شد:

- `Oe.reverseVoucher is not a function`

### علت
متد frontend برای `reverseVoucher` در bundle وجود نداشت، ولی UI آن را صدا می‌زد.

### اصلاح
- متد `reverseVoucher` به bridge frontend اضافه شد

---

## 2) انتخاب حساب در فرم سند جدید

### مشکل
در فرم ثبت سند، کاربر حساب را انتخاب می‌کرد ولی انتخاب پایدار نمی‌ماند.

### علت
به‌روزرسانی state ردیف‌های سند به شکل غیرتابعی انجام می‌شد و در بعضی تغییرهای پشت‌سرهم، مقدار قبلی overwrite می‌شد.

### اصلاح
- update state ردیف‌ها به شکل functional انجام شد

---

## 3) ناهماهنگی اسناد حسابداری و دفتر روزنامه

### مشکل
بعضی آیتم‌ها در Journal دیده می‌شدند ولی در Documents نه.

### علت
مسیر رسمی voucherها هنوز با `virtual / synthetic legacy vouchers` merge می‌شد و Journal/Reports روی داده‌های غیررسمی هم سوار می‌شدند.

### اصلاح
- merge شدن virtual legacy vouchers از مسیر رسمی `read_vouchers_from_table()` حذف شد
- از این به بعد مسیر رسمی ERP فقط voucherهای واقعی را می‌خواند

---

# چیزهایی که این fix pack عمداً حل نمی‌کند

این patch قرار نیست هنوز همه مسائل معماری را نهایی کند، از جمله:
- cutover کامل همه reportها به source جدید
- حذف کامل legacy pages
- نهایی‌سازی historical migration
- نهایی‌سازی UI refactor کامل

---

# نتیجه‌ی مورد انتظار بعد از نصب 8.1.1

بعد از نصب این نسخه روی staging/localhost باید دوباره این‌ها تست شوند:

1. دکمه برگشت سند کار کند
2. انتخاب حساب در ثبت سند جدید درست کار کند
3. Journal و Documents فقط روی voucherهای رسمی نزدیک‌تر و هماهنگ‌تر باشند
4. receipt/voucherهای جدید در ERP logic رسمی درست‌تر دیده شوند

---

# اگر هنوز صورت سود و زیان / ترازنامه صفر بود

اگر بعد از این fix pack هنوز P&L و Balance Sheet صفر بودند، باید بررسی شود:
- آیا voucherهای رسمی جدید واقعاً در source رسمی گزارش‌ها دیده می‌شوند؟
- آیا account mapping و account resolution کامل است؟
- آیا report UI هنوز از logic قدیمی client-side استفاده می‌کند؟

این بخش ممکن است نیازمند patch بعدی یا شروع wave بعدی مرتبط با cutover report باشد.

---

**پایان یادداشت Fix Pack**


## 4) سازگاری موقت write/read برای اسناد

### مشکل
در بعضی محیط‌ها سند با پیام موفق ثبت می‌شد ولی در UI رسمی دیده نمی‌شد.

### علت محتمل
مسیر staging هنوز ممکن بود در بعضی لحظه‌ها بین table path و legacy option path ناهماهنگ باشد.

### اصلاح
- shadow write موقت برای voucherها در option legacy نگه داشته شد
- مسیر خواندن voucherها table + shadow option را با اولویت table merge می‌کند
- approve/delete/unfinalize هم روی مسیر canonical-any سازگار شدند

### هدف
در دوره‌ی تثبیت Wave 1، UI دیگر نباید سند موفق‌ثبت‌شده را گم کند.
