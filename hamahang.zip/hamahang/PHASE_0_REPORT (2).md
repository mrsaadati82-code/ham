# PHASE_0_REPORT

> Phase 0 Execution Artifact  
> Program: ERP Refactor / Accounting Unification  
> Source references: `ACCOUNTING_SYSTEM_ANALYSIS.md`, `ERP_ARCHITECTURE.md`, `ERP_REFACTOR_ROADMAP.md`  
> Mode: **No code change / No behavior change / Baseline only**

---

# 0) هدف این گزارش

این گزارش، شروع اجرایی **Phase 0** است و فقط روی این موارد متمرکز است:

1. ثبت baseline فنی سیستم حسابداری موجود
2. ثبت snapshot ساختاری فایل‌های مالی/حسابداری
3. ثبت manifest یکپارچگی فایل‌ها (line count / size / SHA-256)
4. ثبت inventory مسیرهای ورود مالی (entry points)
5. ثبت matrix مشاهده‌پذیری و مقایسه قبل/بعد
6. مشخص‌کردن مواردی که برای تکمیل Phase 0 نیازمند runtime واقعی WordPress هستند

> این گزارش عمداً هیچ تغییری در کد، schema، query یا behavior سیستم ایجاد نمی‌کند.

---

# 1) وضعیت اجرای Phase 0

## 1.1 نتیجه فعلی

**Phase 0 آغاز شد** و بخش‌های مستنداتی/ساختاری آن در این workspace انجام شد.  
بخش‌های runtime/data snapshot که نیازمند محیط WordPress + DB واقعی + سناریوهای تستی هستند، در این workspace **قابل اجرا نبوده‌اند** و به‌عنوان pending ثبت شده‌اند.

## 1.2 وضعیت Phase 0 به تفکیک

| آیتم | وضعیت |
|---|---|
| Baseline ساختاری فایل‌ها | ✅ انجام شد |
| Manifest یکپارچگی فایل‌ها | ✅ انجام شد |
| Inventory entry pointها | ✅ انجام شد |
| Inventory hooks / triggers | ✅ انجام شد |
| Definition of comparison KPIs | ✅ انجام شد |
| Snapshot عددی runtime گزارش‌ها | ⏳ نیازمند محیط واقعی |
| Reconciliation اعداد در staging | ⏳ نیازمند محیط واقعی |
| Freeze policy پیشنهادی | ✅ انجام شد |
| Observability checklist | ✅ انجام شد |

---

# 2) دامنه‌ی Freeze در Phase 0

تا پایان Phase 0، در دامنه‌ی حسابداری باید این فایل‌ها **فقط خواندنی** تلقی شوند:

## 2.1 فایل‌های هسته مالی/حسابداری
- `client-project-tracker.php`
- `includes/class-cptt-core.php`
- `includes/class-cptt-admin.php`
- `includes/class-cptt-expert.php`
- `includes/class-cptt-finance.php`
- `includes/class-cptt-finance-erp.php`
- `includes/class-cptt-currency.php`
- `includes/class-cptt-payment.php`

## 2.2 فایل‌های UI legacy مالی
- `includes/finance/page-dashboard.php`
- `includes/finance/page-receivables.php`
- `includes/finance/page-payouts.php`
- `includes/finance/page-transactions.php`
- `includes/finance/page-treasury.php`
- `includes/finance/page-ledger.php`
- `includes/finance/page-categories.php`
- `assets/js/finance.js`
- `assets/css/finance.css`

## 2.3 فایل‌های ERP UI
- `assets/finance-ui/app.js`
- `assets/finance-ui/app.css`
- `assets/finance-ui/fonts.css`

---

# 3) Baseline Manifest — فایل‌ها و هش‌ها

> هدف این manifest: اگر در فازهای بعدی تغییری در فایل‌های حساس ایجاد شد، بتوان baseline را به‌صورت دقیق با وضعیت جدید مقایسه کرد.

| فایل | Lines | Size (bytes) | SHA-256 |
|---|---:|---:|---|
| `client-project-tracker.php` | 177 | 8,502 | `173fb5f0245decf50ab1c5e4ad249c7bf80de512898aec22cfb252241bf7e308` |
| `includes/class-cptt-core.php` | 534 | 23,730 | `9267f9a553bff7e611a5e831e34e733bd96c7fea0f84f4158893508e57137e48` |
| `includes/class-cptt-admin.php` | 2,395 | 173,342 | `d53af5332cb22f73787695c67a4f618754bd0b0849de45df38789b10f24780d0` |
| `includes/class-cptt-expert.php` | 5,074 | 291,537 | `627404f8288cee184736284c0a28635aab4b733e0ff3026be2d72e4721a5b4c7` |
| `includes/class-cptt-finance.php` | 822 | 36,096 | `e1087d1b9ed5b76d38a7d1b028368d938dac75b4dea252587901c66ce6ca80bc` |
| `includes/class-cptt-finance-erp.php` | 8,748 | 441,960 | `2d856f56f37b806a00933e904d7fb059b0bb5afe80e7d2f82227230dc0291fb4` |
| `includes/class-cptt-currency.php` | 163 | 7,531 | `00b1b7eae10024aabf4b89c031584fe32159e18a4eadd1f5bf38712e8d945f28` |
| `includes/class-cptt-payment.php` | 2,119 | 103,645 | `e0844f3a83bd2d9fc1f3d45e537191fc36f7b5cce9e6a80a2a0a78ba8d7262a0` |
| `includes/finance/page-dashboard.php` | 173 | 9,134 | `747153559eb323a07424b215abe58756a4ac2bcd061dbca064c391ed84b735a7` |
| `includes/finance/page-receivables.php` | 125 | 5,999 | `80080d74a6f824a8ade5c5dcc3271a1ed1d985dedda8e5d30d9884dbedad79ac` |
| `includes/finance/page-payouts.php` | 126 | 6,347 | `ea64d7702b32047b93e15997cac7a1f33f2cfc60b63e58b936d22b2d4b9d0582` |
| `includes/finance/page-transactions.php` | 165 | 9,280 | `4392d33e1d31ff86a7809d42dbed9639837f0d7545fd4faed93f652ab1b549ed` |
| `includes/finance/page-treasury.php` | 210 | 10,201 | `5a76db72e1b6da8b7aeae74ea38c25885e5d8192500ab9ed7569bfe62320ac16` |
| `includes/finance/page-ledger.php` | 154 | 7,717 | `14777d08928ab855c377a600dbe0f6bd6af0cd194c323cdccfa442ba47f85102` |
| `includes/finance/page-categories.php` | 75 | 3,317 | `e15720a5a8b89382ebce9f4f78f95c56a331563da7cf336840b16353cce92d61` |
| `assets/js/finance.js` | 637 | 24,935 | `a8e358d699b6bf9668b237dfb0c0f30d1d141e01f43ad58abb0810ac2e0e0ad0` |
| `assets/css/finance.css` | 567 | 21,609 | `6a53a73b2d749c51c32cc8cbe769c659f47e4c9e038ac29e0e83d70e3eac7b55` |
| `assets/finance-ui/app.js` | 127 | 446,056 | `7e68cfca347f608c3c4d1086c32012d6454c9bcc433da2d918a27ae0fc987d96` |
| `assets/finance-ui/app.css` | 3 | 64,640 | `10a6bbbe60ff22284657de9e6acef81df197a1bd6449a0dbc1eec332a428c59d` |
| `assets/finance-ui/fonts.css` | 41 | 1,434 | `b36a5b6c789c8e065e2d9f410673a1b7bbf6d946cb32830e7864d53d0dddb99e` |
| `ACCOUNTING_SYSTEM_ANALYSIS.md` | 2,083 | 70,615 | `5b3abb89d7793e02ab1edfb6f618f86f358f50776a5ea8a97f8820d1cf520e06` |
| `ERP_ARCHITECTURE.md` | 1,152 | 28,895 | `a677a3c564ba8c926823858b977c9e263fe22f38511fcd8241e2e0a9dec84db9` |
| `ERP_REFACTOR_ROADMAP.md` | 893 | 27,122 | `e2c955b10a41fdcae956a8bfad1ca3403c0743bf57f91fc12b77eb7fa41ffa17` |

---

# 4) Baseline فنی سیستم

## 4.1 نسخه فعلی افزونه
- **Plugin Version (code baseline):** `8.0.4`

## 4.2 ماژول‌های اصلی حسابداری

### لایه هسته/Operational
- `CPTT_Core`
- `CPTT_Admin`
- `CPTT_Expert`
- `CPTT_Payment`

### لایه مالی legacy
- `CPTT_Finance`
- صفحات `includes/finance/*`
- `assets/js/finance.js`
- `assets/css/finance.css`

### لایه ERP
- `CPTT_Finance_ERP`
- `assets/finance-ui/app.js`
- `assets/finance-ui/app.css`

## 4.3 شاخص‌های ساختاری baseline

| شاخص | مقدار فعلی |
|---|---:|
| فایل‌های اصلی مالی/حسابداری شناسایی‌شده | 20+ |
| کلاس‌های اصلی موثر بر حسابداری | 7 |
| Endpointهای AJAX در `CPTT_Finance` | 8 |
| Endpointهای AJAX در `CPTT_Finance_ERP` | 116 |
| Endpointهای AJAX در `CPTT_Admin` | 8 |
| Endpointهای AJAX در `CPTT_Payment` | 3 |
| `admin_post` در Payment | 8 |
| REST routeهای ERP | 8 |
| cron hookهای ERP | 2 |
| metadata observerهای ERP | 2 |
| domain hook producerها در Admin | 2+ |
| domain hook consumerها در Finance / ERP | 2 + 2 |

---

# 5) Snapshot ساختاری داده و منابع حقیقت

## 5.1 منابع حقیقت فعلی (As-Is SoT Snapshot)

| حوزه | SoT فعلی |
|---|---|
| واقعیت مالی پروژه | `_cptt_steps` |
| مطالبات مشتری | `_cptt_steps` |
| پرداخت/بدهی کارشناس | `_cptt_steps` + `wp_cptt_ledger` |
| موجودی خزانه | `wp_cptt_fin_accounts` + `wp_cptt_fin_ledger` |
| اسناد ERP | `wp_cptt_erp_vouchers` + `wp_cptt_erp_voucher_rows` |
| گزارش‌های استاندارد ERP | `vouchers + voucher_rows + COA` |
| KPI مالی legacy | `_cptt_steps` + `wp_cptt_fin_ledger` |
| فاکتور ERP | `wp_cptt_erp_invoices` + `wp_cptt_erp_invoice_rows` |
| تاریخچه برخی تسویه‌ها | `wp_cptt_ledger` |

## 5.2 وضعیت baseline بر اساس تحلیل
- **Single Source of Truth واحد وجود ندارد**
- **Dual Ledger** وجود دارد
- **Report Layer استاندارد server-side** هنوز برقرار نشده
- **Journal** مدل فیزیکی مستقل ندارد
- **General Ledger** به‌عنوان لایه حسابداری نهایی رسمی هنوز formalized نیست

---

# 6) Inventory مسیرهای ورود مالی (Financial Entry Points)

## 6.1 Entry Pointهای ERP

| نوع | endpoint / hook / entry |
|---|---|
| Manual Voucher | `cpttf_erp_voucher_save` |
| Approve Voucher | `cpttf_erp_voucher_approve` |
| Delete Voucher | `cpttf_erp_voucher_delete` |
| Reverse Voucher | `cpttf_erp_voucher_reverse` |
| Unfinalize Voucher | `cpttf_erp_voucher_unfinalize` |
| Save Income/Expense | `cpttf_erp_ie_save` |
| Delete Income/Expense | `cpttf_erp_ie_delete` |
| Treasury Deposit | `cpttf_erp_treasury_deposit` |
| Treasury Withdraw | `cpttf_erp_treasury_withdraw` |
| Treasury Transfer | `cpttf_erp_treasury_transfer` |
| Project Quick Pay | `cpttf_erp_project_quick_pay` |
| Expert Settlement (ERP) | `cpttf_erp_settle_steps` |
| Manual Expert Pay (ERP) | `cpttf_erp_settle_manual` |
| Payable Payment | `cpttf_erp_payable_pay` |
| Installment Receipt | `cpttf_erp_installment_pay` |
| Invoice To Voucher | `cpttf_erp_invoice_to_voucher` |
| FY Close | `cpttf_erp_fy_close_execute` |

## 6.2 Entry Pointهای Legacy/Classical

| نوع | endpoint / hook / entry |
|---|---|
| Customer Quick Pay | `cptt_quick_pay` |
| Expert Payout | `cptt_expert_payout` |
| Step Settlement | `cptt_step_settle` |
| Manual Expert Payment | `cptt_manual_expert_payment` |
| Payment Receipt Approval | `cptt_approve_receipt` |
| Payment Receipt Rejection | `cptt_reject_receipt` |
| Public Payment | `admin_post_cptt_submit_card_receipt` |

## 6.3 Hook-Based Financial Entry

| Hook | Producer | Consumer |
|---|---|---|
| `cptt_after_expert_payout` | Admin / ERP settlement flows | Finance ledger logger + ERP auto voucher |
| `cptt_after_manual_expert_payment` | Admin / ERP manual pay flows | Finance ledger logger + ERP auto voucher |
| `updated_post_meta(_cptt_steps)` | project/payment operations | ERP project sync observer |
| `added_post_meta(_cptt_steps)` | project/payment operations | ERP project sync observer |

---

# 7) Snapshot از Hookها و Triggerها

## 7.1 شمارش baseline

### `CPTT_Finance`
- `wp_ajax_*` = **8**
- domain consumer hooks = **2**

### `CPTT_Finance_ERP`
- `wp_ajax_*` = **116**
- REST routes = **8**
- cron hooks = **2**
- metadata observer hooks = **2**
- domain consumer hooks = **2**

### `CPTT_Admin`
- `wp_ajax_*` = **8**
- domain producer hooks = **2**
- additional producer path = metadata updates to `_cptt_steps`

### `CPTT_Payment`
- `wp_ajax_*` = **3**
- `admin_post*` = **8**
- write to `_cptt_steps` via `apply_payment_to_project()` = **1 critical path**

---

# 8) Baseline مقایسه‌ای قبل/بعد (Comparison Matrix)

> این بخش template مقایسه‌ی Phase 0 است.  
> در این workspace به DB واقعی و runtime production/staging دسترسی مستقیم وجود نداشته، بنابراین ستون «Baseline Value» فعلاً با وضعیت داده‌ای پر نشده و باید در محیط staging تکمیل شود.

## 8.1 معیارهای حسابداری اصلی

| Metric | Formula/Source expected | Baseline Value | وضعیت |
|---|---|---|---|
| Total Vouchers | count of ERP vouchers | نامشخص | نیازمند runtime |
| Total Voucher Rows | count of ERP voucher rows | نامشخص | نیازمند runtime |
| Draft Vouchers | vouchers where status=DRAFT | نامشخص | نیازمند runtime |
| Finalized Vouchers | vouchers where status=FINALIZED | نامشخص | نیازمند runtime |
| Journal Debit Total | sum journal debits | نامشخص | نیازمند runtime |
| Journal Credit Total | sum journal credits | نامشخص | نیازمند runtime |
| Trial Balance Debit | TB total debit | نامشخص | نیازمند runtime |
| Trial Balance Credit | TB total credit | نامشخص | نیازمند runtime |
| Income Statement Revenue | report value | نامشخص | نیازمند runtime |
| Income Statement Expense | report value | نامشخص | نیازمند runtime |
| Income Statement Profit | revenue-expense | نامشخص | نیازمند runtime |
| Balance Sheet Assets | report value | نامشخص | نیازمند runtime |
| Balance Sheet Liabilities | report value | نامشخص | نیازمند runtime |
| Balance Sheet Equity | report value | نامشخص | نیازمند runtime |
| Receivables Total | total customer receivables | نامشخص | نیازمند runtime |
| Expert Payable Total | total expert payable | نامشخص | نیازمند runtime |
| Treasury Balance Total | sum treasury balances | نامشخص | نیازمند runtime |

## 8.2 معیارهای سازگاری (Consistency Checks)

| Check | Expected Rule | Baseline Status |
|---|---|---|
| Journal Debit == Journal Credit | must be equal | نامشخص |
| Trial Balance Debit == Trial Balance Credit | must be equal | نامشخص |
| Assets == Liabilities + Equity | must hold | نامشخص |
| Documents count vs Journal distinct vouchers | must be explainable | نامشخص |
| Receivables report vs project meta total | must reconcile | نامشخص |
| Treasury total vs finance ledger total | must reconcile | نامشخص |
| Expert settlement history vs vouchers | must reconcile | نامشخص |

---

# 9) تست‌های Phase 0 که باید روی Staging اجرا شوند

## 9.1 سناریوهای عملیاتی ضروری

### سناریو A — ثبت سند دستی
- ایجاد یک JV متوازن
- تأیید نهایی سند
- بررسی نمایش در:
  - Documents
  - Journal
  - GL
  - Trial Balance

### سناریو B — دریافت از مشتری
- ثبت Quick Pay
- بررسی تاثیر روی:
  - `_cptt_steps`
  - vouchers
  - receivables
  - journal
  - income statement
  - balance sheet

### سناریو C — پرداخت به کارشناس
- پرداخت مرحله‌ای
- پرداخت دستی
- بررسی اثر روی:
  - `_cptt_steps`
  - `wp_cptt_ledger`
  - `wp_cptt_fin_ledger`
  - vouchers
  - party statement

### سناریو D — درآمد/هزینه مستقیم
- ثبت income
- ثبت expense
- بررسی اثر روی:
  - `wp_cptt_fin_ledger`
  - voucher
  - category breakdown
  - monthly series
  - P&L

### سناریو E — انتقال خزانه
- انتقال بین دو حساب
- بررسی balancing و linked_id و voucher TV

### سناریو F — دریافت قسط
- ایجاد plan
- دریافت قسط
- بررسی voucher RV و ledger

### سناریو G — پرداخت بدهی
- ایجاد payable
- پرداخت payable
- بررسی PV + ledger + report impact

### سناریو H — فاکتور → سند
- invoice_to_voucher
- بررسی voucher + linkage

### سناریو I — بستن سال مالی
- preview
- close execute
- CV / OV existence
- locks

---

# 10) Baseline Entry-Point Mapping برای آینده

## 10.1 اولویت‌دارترین مسیرهایی که باید بعداً trace شوند

| اولویت | مسیر | دلیل |
|---|---|---|
| P1 | `_cptt_steps` → receivables / KPI / profit | مهم‌ترین SoT عملیاتی فعلی |
| P1 | `cptt_fin_ledger` → treasury / monthly / categories | مهم‌ترین ledger مالی modern |
| P1 | `erp_vouchers + rows` → reports | منبع report رسمی فعلی ERP |
| P1 | `cptt_ledger` → expert settlement history | ledger موازی قدیمی |
| P2 | payment receipt → project update | مسیر مالی مهم ولی موازی |
| P2 | invoice → voucher | مسیر ERP تجاری |
| P2 | cheque status → vouchers/ledger | ریسک divergence |
| P2 | recurring / cron | hidden financial writer |

---

# 11) Observability Checklist برای فازهای بعد

## 11.1 چیزهایی که در شروع فازهای اجرایی باید قابل ردیابی باشند
- sourceType/sourceId هر Voucher
- relation between Voucher and Business Action
- relation between Voucher and Ledger Event (if ledger remains)
- financial dimension completeness:
  - projectId
  - party/customerId/expertId
  - costCenterId
  - fiscalYearId
- status transition logs
- posting timestamp
- reversal chain
- close/reopen fiscal year chain

## 11.2 چیزهایی که باید در تست‌ها log شوند
- before/after counts of vouchers
- before/after trial balance totals
- before/after receivables total
- before/after treasury total
- before/after expert payable total
- discrepancies per scenario

---

# 12) خروجی‌های تکمیلی مورد نیاز برای تکمیل واقعی Phase 0

این موارد هنوز باید در staging/production-like environment ثبت شوند:

## 12.1 Snapshot عددی DB
- row counts per financial table
- sample rows per event type
- aggregate sums

## 12.2 Snapshot UI reports
- screenshot baseline for:
  - Documents
  - Journal
  - General Ledger
  - Trial Balance
  - P&L
  - Balance Sheet
  - Treasury
  - Receivables

## 12.3 Snapshot variance list
- list of current mismatches between:
  - Documents and Journal
  - Journal and TB
  - TB and Statements
  - Project meta and Receivables
  - Treasury and Ledgers

---

# 13) ارزیابی Phase 0 نسبت به Roadmap

## 13.1 هدف Phase 0 در Roadmap
طبق `ERP_REFACTOR_ROADMAP.md`، هدف Phase 0 این بود:
- Baseline
- Freeze
- Observability
- Comparison KPIs
- Entry point inventory

## 13.2 تحقق فعلی

| Deliverable | وضعیت |
|---|---|
| Baseline structural inventory | ✅ |
| File manifest with hashes | ✅ |
| Entry point inventory | ✅ |
| Hook inventory | ✅ |
| Comparison KPI matrix | ✅ |
| Freeze scope | ✅ |
| Runtime numeric snapshot | ⏳ |
| Staging reconciliation | ⏳ |

## 13.3 نتیجه
**Phase 0 از منظر مستندسازی و baseline ساختاری شروع و تا حد زیادی انجام شده است،**  
اما برای بسته‌شدن کامل آن طبق Roadmap، هنوز به **یک اجرای staging/runtime** نیاز است.

---

# 14) Definition of Done برای بستن کامل Phase 0

Phase 0 زمانی کاملاً Done محسوب می‌شود که:

1. baseline structural manifest ثبت شده باشد ✅
2. freeze scope مشخص شده باشد ✅
3. entry point inventory کامل باشد ✅
4. comparison KPIs تعریف شده باشند ✅
5. runtime numeric snapshots از staging ثبت شده باشد ⏳
6. consistency baseline matrix با اعداد واقعی پر شده باشد ⏳
7. discrepancy list رسمی قبل از شروع فازهای refactor ثبت شده باشد ⏳

---

# 15) Rollback Plan مخصوص Phase 0

چون Phase 0 هیچ تغییری در code path ایجاد نمی‌کند، rollback آن ساده است:

- حذف artefactهای Phase 0 در صورت عدم نیاز
- بازگشت به baseline documentation قبلی
- عدم اثر روی schema، data یا behavior

در صورت انجام snapshot staging:
- حفظ snapshotها به‌عنوان immutable artifact
- عدم بازنویسی baseline اولیه

---

# 16) زمان تقریبی باقیمانده برای تکمیل کامل Phase 0

## بخش انجام‌شده در این workspace
- تقریباً **50% تا 65%** از Phase 0 (بخش مستندسازی/ساختاری)

## بخش باقی‌مانده در staging/runtime
- 1 تا 2 روز کاری برای گرفتن snapshot واقعی و reconciliation baseline

---

# 17) گام بعدی پیشنهادی

پس از این گزارش، برای بستن کامل Phase 0 باید این کارها در staging انجام شوند:

1. اجرای سناریوهای A تا I
2. ثبت اعداد baseline در comparison matrix
3. ثبت mismatch list رسمی
4. lock کردن baseline final
5. سپس ورود به Phase 1

---

**پایان گزارش Phase 0**
