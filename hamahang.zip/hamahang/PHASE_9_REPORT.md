# PHASE_9_REPORT

> Phase 9 Execution Artifact  
> Program: ERP Refactor / Accounting Unification  
> Source references: `ACCOUNTING_SYSTEM_ANALYSIS.md`, `ERP_ARCHITECTURE.md`, `ERP_REFACTOR_ROADMAP.md`, `ERP_UI_ARCHITECTURE_CURRENT.md`, `PHASE_0_REPORT.md`, `PHASE_1_REPORT.md`, `PHASE_2_REPORT.md`, `PHASE_3_REPORT.md`, `PHASE_4_REPORT.md`, `PHASE_5_REPORT.md`, `PHASE_6_REPORT.md`, `PHASE_7_REPORT.md`, `PHASE_8_REPORT.md`  
> Additional binding decisions: user-approved UI target = ERP Accounting Panel  
> Mode: **No code change / No schema change in this turn / UI Refactor Plan only**

---

# 0) اعلام صریح قبل از شروع

## 0.1 پاسخ کوتاه و ساده

**در این نوبت فقط فاز ۹ را به‌صورت گزارش معماری اجرا کرده‌ام و هیچ کد یا ظاهر پروژه را تغییر نداده‌ام.**

یعنی الان:
- هیچ فایل JS یا CSS ویرایش نشده
- هیچ route جدیدی ساخته نشده
- هیچ صفحه‌ای حذف یا جابه‌جا نشده
- هیچ APIای عوض نشده
- هیچ UI واقعی تغییر نکرده

## 0.2 اما اجرای واقعی این فاز چه می‌خواهد؟

اجرای واقعی Phase 9 حتماً نیاز دارد به:
- تغییر کد frontend
- احتمالاً تغییر contract بعضی endpointها
- بازسازی مسیر source-managed برای UI
- حذف محاسبات مالی از frontend
- تست visual regression
- تست contract بین UI و backend

### نتیجه عملی
**اجرای واقعی Phase 9 فقط باید روی staging و با backup کامل انجام شود.**

---

# 1) هدف این گزارش

این سند، شروع اجرایی **Phase 9 — UI Refactor Plan** است و فقط روی این موارد تمرکز دارد:

1. شناسایی همه بخش‌های UI که امروز محاسبه مالی انجام می‌دهند
2. تعریف contract جدید UI برای report pageهای اصلی
3. طراحی plan حذف `synthetic / virtual voucher generation` از frontend
4. طراحی plan حذف formulaهای client-side
5. تعیین تغییرات لازم در filter و pagination contractها
6. تعیین migration plan از bundle minified فعلی به **source-managed UI layer**
7. حفظ صریح این تصمیم که **رابط کاربری نهایی همان ERP Accounting Panel** بماند
8. ثبت **Ambiguity Register فاز ۹** برای تصمیم‌گیری قبل از فاز بعد

> این سند عمداً هیچ تغییری در کد، schema، query اجرایی، migration واقعی یا رفتار runtime ایجاد نمی‌کند.

---

# 2) تصمیم‌های قطعی که در فاز ۹ لازم‌الاجرا هستند

## 2.1 UI هدف
رابط کاربری هدف باید همین صفحه باشد:

- `wp-admin/admin.php?page=cptt-finance-erp`

## 2.2 حفظ ظاهر و تجربه فعلی
این فاز **redesign** پیشنهاد نمی‌دهد.  
هدف این نیست که UI جدید از صفر طراحی شود؛ هدف این است که:

- همان ERP UI بماند
- ولی logic مالی از frontend بیرون کشیده شود
- و frontend فقط مصرف‌کننده‌ی read modelهای رسمی باشد

## 2.3 source زنده‌ی UI فعلی
طبق `ERP_UI_ARCHITECTURE_CURRENT.md`:
- runtime واقعی UI از این فایل‌ها می‌آید:
  - `includes/class-cptt-finance-erp.php`
  - `assets/finance-ui/app.js`
  - `assets/finance-ui/app.css`
  - `assets/finance-ui/fonts.css`

## 2.4 وضعیت `ui-src/`
- source معتبر UI فعلی نیست
- مسیر runtime نیست
- ناقص بوده
- نباید دوباره به‌عنوان مسیر موازی معماری زنده شود

## 2.5 اصل مهم

```text
Keep the ERP UI.
Replace the accounting logic behind it.
```

---

# 3) معنی واقعی UI Refactor در این پروژه

## 3.1 UI Refactor در این پروژه یعنی چه؟

UI Refactor در این پروژه یعنی:
- حذف محاسبات مالی از frontend
- حذف ساخت objectهای synthetic در frontend
- خواندن داده آماده از backend
- نگه‌داشتن UI/UX ERP به‌عنوان مقصد نهایی
- آماده‌سازی codebase برای maintainability

## 3.2 UI Refactor در این پروژه یعنی چه نیست؟

UI Refactor در این پروژه یعنی نه:
- redesign کامل ظاهر
- تعویض route اصلی پنل ERP
- بازگشت به pageهای legacy
- افزودن مسیر موازی جدید و بی‌استفاده مثل `ui-src/` قبلی

## 3.3 اصل نهایی فاز ۹

```text
Frontend is a presenter.
Backend/report layer is the accounting brain.
```

---

# 4) Inventory بخش‌های UI که امروز محاسبه مالی انجام می‌دهند

## 4.1 منبع شناسایی

این inventory بر اساس reverse engineering انجام‌شده در:
- `ACCOUNTING_SYSTEM_ANALYSIS.md`
- `ERP_UI_ARCHITECTURE_CURRENT.md`
- تحلیل bundle فعلی `assets/finance-ui/app.js`

است.

## 4.2 Documents UI

### وضعیت فعلی
- از payload vouchers تغذیه می‌شود
- بخشی از aggregation و filtering در client انجام می‌شود
- در وضعیت فعلی حتی merge با virtual/synthetic legacy paths ممکن بوده

### مشکل
- source purity کامل نیست
- client باید کمتر درگیر interpretation شود

---

## 4.3 Journal UI

### component reverse-engineered
- `pj`

### وضعیت فعلی
- rows را در frontend flatten می‌کند
- total debit/credit را در frontend جمع می‌زند

### مشکل
- Journal نباید در UI ساخته شود
- باید از `Journal table` آماده بیاید

---

## 4.4 General Ledger UI

### component reverse-engineered
- `mh` with `mode='general'`

### وضعیت فعلی
- از voucher rows و account tree در client aggregation می‌سازد
- running balance logic و roll-up در client رخ می‌دهد

### مشکل
- دفتر کل نباید در frontend محاسبه شود
- source رسمی باید `GL` باشد

---

## 4.5 Subsidiary Ledger UI

### component reverse-engineered
- `mh` with `mode='subsidiary'`

### وضعیت فعلی
- dimension-aware roll-up در client انجام می‌شود

### مشکل
- دفتر معین باید از `GL + dimensions` server-side بیاید

---

## 4.6 Trial Balance UI

### component reverse-engineered
- `vj`

### وضعیت فعلی
- group-by accountId در frontend
- debit/credit aggregation در frontend
- balance calculation در frontend

### مشکل
- TB باید از read model رسمی بیاید

---

## 4.7 Income Statement UI

### component reverse-engineered
- `jj`

### وضعیت فعلی
- بر اساس prefix کد حساب در client محاسبه می‌شود
- revenue/expense/profit را frontend می‌سازد

### مشکل
- formulaهای رسمی نباید در client باشند
- statement باید server-side آماده باشد

---

## 4.8 Balance Sheet UI

### component reverse-engineered
- `bj`

### وضعیت فعلی
- assets/liabilities/equity را از voucher payload در frontend می‌سازد
- equation check در client رخ می‌دهد

### مشکل
- balance sheet باید read model رسمی داشته باشد

---

## 4.9 Dashboard Cards / KPI UI

### وضعیت فعلی
- بعضی KPIها از mixed sources و mixed logic آمده‌اند
- در تاریخچه پروژه، legacy KPI logic و project meta logic هم درگیر بوده‌اند

### مشکل
- dashboard باید فقط از report layer رسمی تغذیه شود

---

## 4.10 Filter Shell UI

### وضعیت فعلی
- shell filterهای گزارش‌ها بخشی از logic تطبیق/فیلتر را در frontend نگه می‌دارند

### مشکل
- filter state می‌تواند در UI بماند
- اما filter semantics و result correctness باید server-side باشد

---

## 4.11 Synthetic / Virtual Voucher Logic

### وضعیت فعلی
- قبلاً در frontend objectهای synthetic ساخته شده‌اند
- این منطق یکی از علت‌های divergence بوده

### مشکل
- object حسابداری نباید فقط در UI وجود داشته باشد

---

# 5) دسته‌بندی دقیق UI Surfaceها

## 5.1 Surfaceهای Report-Critical

این‌ها باید در اولویت refactor باشند:
- Documents
- Journal
- General Ledger
- Subsidiary Ledger
- Trial Balance
- Income Statement
- Balance Sheet
- Dashboard cards

## 5.2 Surfaceهای Supporting

این‌ها support/refinement لازم دارند:
- filter barها
- pagination controls
- export / print triggers
- detail drawers / modals
- account selectorها
- date range controls

## 5.3 Surfaceهای Transitional / Compatibility

این‌ها target نهایی نیستند:
- pageهای legacy read-only با برچسب `قدیمی`

---

# 6) Contractهای جدید UI برای صفحه‌های اصلی

## 6.1 اصل کلی Contractها

Contract هر صفحه باید طوری باشد که frontend فقط این کارها را انجام دهد:
1. فیلترها را بفرستد
2. response آماده بگیرد
3. render کند
4. state UI مثل loading/empty/error را مدیریت کند

Frontend نباید:
- گزارش بسازد
- rowها را برای accounting meaning دوباره جمع بزند
- statement formulaها را اعمال کند

---

## 6.2 Documents Page Contract

### Request responsibilities
- search text
- date range
- status
- voucherType
- project/party/cost center filters
- page/pageSize/sort

### Response responsibilities
- document items
- row counts
- debit/credit totals
- pagination metadata
- source metadata

### UI responsibilities
- render table/list
- render status badges
- render paging/sorting/search

### Forbidden in UI
- ساخت voucher synthetic
- جمع‌زدن accounting totals مستقل از response رسمی

---

## 6.3 Journal Page Contract

### Request responsibilities
- date range
- fiscalYear
- account/project/party/cost center filters
- page/pageSize

### Response responsibilities
- journal line items آماده
- debit total
- credit total
- pagination metadata
- as-of/source metadata

### UI responsibilities
- render lines
- render totals
- render filters

### Forbidden in UI
- flatten کردن voucher rows
- ساخت Journal line از روی voucher payload خام

---

## 6.4 General Ledger Page Contract

### Request responsibilities
- accountId
- date range
- dimensions
- page/pageSize/sort if paged

### Response responsibilities
- opening balance
- entries with running balance
- debit total
- credit total
- closing balance

### UI responsibilities
- render ledger lines
- render opening/closing summary

### Forbidden in UI
- running balance calculation
- roll-up حساب‌ها در سمت client

---

## 6.5 Subsidiary Ledger Page Contract

### Request responsibilities
- account/dimension filters
- date range
- page/pageSize

### Response responsibilities
- opening balance
- dimension-aware entries
- running balance
- closing balance

### UI responsibilities
- render grouped dimension lines
- render dimension context

### Forbidden in UI
- dimension aggregation logic
- cross-row accounting grouping

---

## 6.6 Trial Balance Page Contract

### Request responsibilities
- date scope / fiscal year
- account tree filters if needed

### Response responsibilities
- rows with account code/name
- debit total
- credit total
- balance per row
- metadata

### UI responsibilities
- render TB rows
- render equality state

### Forbidden in UI
- group-by accountId
- debit/credit calculation from raw rows

---

## 6.7 Income Statement Page Contract

### Request responsibilities
- fiscal/date scope
- optional segment filters

### Response responsibilities
- revenue section
- expense section
- profit fields
- generatedAt/source metadata

### UI responsibilities
- render sections and totals

### Forbidden in UI
- prefix-based formula calculation
- revenue/expense derivation from voucher rows

---

## 6.8 Balance Sheet Page Contract

### Request responsibilities
- fiscal/date scope
- optional segment filters

### Response responsibilities
- assets section
- liabilities section
- equity section
- equation check
- metadata

### UI responsibilities
- render sections
- render equality state

### Forbidden in UI
- assets/liabilities/equity construction from raw rows

---

## 6.9 Dashboard Cards Contract

### Request responsibilities
- dashboard scope / fiscal period / branch/company if needed

### Response responsibilities
- KPI-ready values
- freshness metadata
- source metadata per KPI
- drill-down links if needed

### UI responsibilities
- render cards/charts
- render freshness state

### Forbidden in UI
- mixed-source KPI construction
- project meta based final accounting KPI calculation

---

# 7) Plan حذف Synthetic / Virtual Voucher Generation از Frontend

## 7.1 مشکل فعلی

synthetic / virtual voucher در frontend باعث می‌شود:
- سندی دیده شود که source رسمی ندارد
- Journal و Documents از هم فاصله بگیرند
- P&L و BS روی داده‌ی غیررسمی سوار شوند

## 7.2 تصمیم Phase 9

Frontend از این به بعد نباید:
- voucher بسازد
- voucher حدسی ترکیب کند
- legacy rowها را تبدیل به object حسابداری نمایشی کند

## 7.3 برنامه حذف مرحله‌ای

### Step 1
شناسایی همه pathهایی که synthetic accounting object می‌سازند

### Step 2
جایگزینی source آن‌ها با response رسمی backend

### Step 3
خاموش‌کردن render path قدیمی پشت feature flag

### Step 4
حذف semantic dependence روی virtual voucherها

## 7.4 Rule مهم

اگر چیزی voucher است، باید از backend رسمی با traceability بیاید.  
اگر traceability ندارد، voucher UI-only محسوب می‌شود و باید حذف شود.

---

# 8) Plan حذف Client-Side Formulaها

## 8.1 Formulaهایی که باید از UI حذف شوند

- journal total calculation
- GL running balance calculation
- TB aggregation
- P&L formula
- BS formula
- mixed KPI calculations

## 8.2 روش حذف

### روش درست
- backend formula را اعمال کند
- frontend فقط render کند

### روش غلط
- frontend formula را نگه دارد و فقط source را عوض کند

## 8.3 Transition Strategy

### Phase A
responseهای backend طوری غنی شوند که frontend دیگر نیاز به calculation نداشته باشد

### Phase B
client formula paths زیر feature flag خاموش شوند

### Phase C
dead calculation code حذف یا decommission شود

## 8.4 Rule مهم

frontend ممکن است هنوز کارهای نمایشی انجام دهد، مثل:
- format currency
- sort visual state
- collapse/expand tree

اما accounting calculation نه.

---

# 9) Filter Contract Changes

## 9.1 اصل کلی

filter UI می‌تواند در client بماند، ولی **معنای مالی فیلتر** باید در backend enforce شود.

## 9.2 Filter Contract هدف

فیلترهای ERP باید به request رسمی تبدیل شوند:
- `fromDateFa`
- `toDateFa`
- `fiscalYearId`
- `companyId`
- `branchId`
- `status`
- `voucherType`
- `accountId`
- `projectId`
- `partyId`
- `partyRole`
- `costCenterId`
- `searchText`
- `page`
- `pageSize`
- `sortBy`
- `sortDirection`

## 9.3 تغییر مهم

filtering نهایی دیگر نباید روی payload بزرگ خام در browser انجام شود؛  
باید request-based و server-side باشد.

## 9.4 تاریخ و دامنه مالی

date filter فقط UI field نیست؛ باید با:
- fiscal year
- posted state
- lock semantics

هم‌راستا باشد.

---

# 10) Pagination Contract Changes

## 10.1 وضعیت مطلوب

pagination باید server-side باشد برای:
- Documents
- Journal
- GL
- Subsidiary Ledger

## 10.2 چرا مهم است؟

چون با Journal/GL فیزیکی و scale بیشتر:
- browser-side pagination روی payload کامل قابل اتکا نیست
- performance و memory مشکل‌دار می‌شود

## 10.3 Contract هدف

response باید شامل این‌ها باشد:
- `items`
- `totalCount`
- `page`
- `pageSize`
- `hasNext`
- `hasPrev`
- `sortBy`
- `sortDirection`

## 10.4 Rule مهم

client فقط state صفحه را نگه می‌دارد؛ data slicing واقعی باید backend انجام دهد.

---

# 11) Export / Print Trigger Contract در UI

## 11.1 اصل کلی

دکمه‌های export/print در UI باید از همان source رسمی گزارش استفاده کنند.

## 11.2 UI responsibilities
- ارسال filter scope
- گرفتن export/print artifact
- نمایش progress / error state

## 11.3 Forbidden in UI
- ساخت export از data قدیمی کش‌شده در browser
- چاپ گزارش از aggregation محلی متفاوت با source رسمی

## 11.4 وضعیت تصمیم

جزئیات cutover همزمان export/print با هر report هنوز ambiguity دارد و در انتهای سند ثبت می‌شود.

---

# 12) Migration Plan از Bundle Minified فعلی به Source-Managed UI Layer

## 12.1 مسئله فعلی

UI زنده‌ی فعلی در این فایل است:
- `assets/finance-ui/app.js`

و این فایل:
- minified است
- نگه‌داری و توسعه‌اش سخت است
- source structure رسمی و maintainable ندارد

## 12.2 هدف Phase 9

هدف این نیست که UI جدیدی اختراع کنیم.  
هدف این است که **همان UI ERP** را به یک source-managed مسیر قابل نگه‌داری منتقل کنیم.

## 12.3 Rule مهم

مسیر source-managed جدید باید:
- runtime target واقعی داشته باشد
- در نهایت خروجی‌اش جایگزین `assets/finance-ui/app.js` شود
- مسیر موازی مرده و بی‌استفاده نباشد

## 12.4 Migration Stages

### Stage 1 — Contract First
اول contract صفحه‌ها و reportها نهایی شود.

### Stage 2 — UI Surface Inventory
componentها، tabها، filter barها، actionها و render pathها inventory شوند.

### Stage 3 — Source Reconstruction Plan
برای هر surface مشخص شود:
- current behavior چیست
- target contract چیست
- visual parity requirement چیست

### Stage 4 — Source-Managed Shell
یک source-managed structure طراحی شود که:
- route ERP را نگه دارد
- same visual behavior را حفظ کند
- report data را از contract رسمی بگیرد

### Stage 5 — Incremental Page Refactor
صفحه به صفحه، surfaceها از bundle قدیمی به source-managed surface منتقل شوند.

### Stage 6 — Final Asset Replacement
در نهایت asset runtime رسمی از source-managed build تولید و جایگزین bundle قدیمی شود.

## 12.5 Rule مهم درباره `ui-src`

پوشه‌ی ناقص قبلی نباید دوباره بدون مرجع روشن برگردد.  
اگر source-managed layer ساخته می‌شود، باید:
- canonical باشد
- build path واقعی داشته باشد
- owner رسمی frontend شود

---

# 13) Visual Parity Rule

## 13.1 تصمیم قطعی کاربر

کاربر می‌خواهد UI و رابط کاربری همان پنل حسابداری ERP باشد.

## 13.2 نتیجه فنی

Refactor UI باید **visual parity** را حفظ کند.

### یعنی
- layout اصلی حفظ شود
- tabهای اصلی حفظ شوند
- تجربه‌ی کاربری کلی حفظ شود
- redesign سلیقه‌ای انجام نشود

## 13.3 چیزهایی که می‌توانند عوض شوند بدون شکستن parity
- source داده
- contract endpoint
- loading behavior بهتر
- error states بهتر
- source metadata / badgeها

## 13.4 چیزهایی که نباید بی‌دلیل عوض شوند
- route اصلی ERP
- structure کلی صفحات ERP
- منطق navigation کلی کاربر
- فرم کلی گزارش‌های اصلی

---

# 14) Feature Flag Strategy برای UI Refactor

## 14.1 اصل کلی

همان‌طور که در فاز ۸ برای report sourceها flag داشتیم، در UI Refactor هم باید flagهای page-level یا surface-level داشته باشیم.

## 14.2 Flagهای مفهومی پیشنهادی

| Flag | هدف |
|---|---|
| `cpttf_ui_documents_v2` | Documents UI روی contract رسمی جدید |
| `cpttf_ui_journal_v2` | Journal UI بدون flatten client-side |
| `cpttf_ui_gl_v2` | GL UI بدون aggregation client-side |
| `cpttf_ui_subsidiary_v2` | Subsidiary UI با contract رسمی |
| `cpttf_ui_tb_v2` | TB UI بدون formula client-side |
| `cpttf_ui_pl_v2` | P&L UI render-only |
| `cpttf_ui_bs_v2` | BS UI render-only |
| `cpttf_ui_dashboard_v2` | dashboard UI با KPI رسمی |
| `cpttf_ui_source_managed_runtime` | runtime asset از source-managed build |

## 14.3 Rule مهم

UI flagها نباید از report source flagها مستقل و بی‌ربط باشند.  
بین backend/report readiness و UI flag dependency باید هم‌راستایی وجود داشته باشد.

---

# 15) تست‌های لازم برای UI Refactor

## 15.1 Contract Tests

باید بررسی شود که:
- هر صفحه request درست می‌فرستد
- هر response را بدون محاسبه مالی اضافی render می‌کند
- با تغییر filter/page/sort رفتار درست دارد

## 15.2 Visual Regression Tests

باید بررسی شود که:
- ظاهر ERP panel بی‌دلیل عوض نشده
- tableها، summaryها، badges، tabs، cards و filters visual parity دارند

## 15.3 Cross-Report Consistency Tests

باید بررسی شود که:
- Documents ↔ Journal ↔ GL ↔ TB ↔ P&L ↔ BS ↔ Dashboard هم‌راستا هستند

## 15.4 Legacy Read-Only Verification

باید بررسی شود که:
- pageهای قدیمی write ندارند
- badge `قدیمی` دیده می‌شود
- کاربر آن‌ها را با source نهایی اشتباه نگیرد

---

# 16) ارتباط فاز ۹ با فازهای قبل و بعد

## 16.1 ارتباط با Phase 8

Phase 8 گفته بود report sourceها باید یکی‌یکی cutover شوند.  
Phase 9 می‌گوید frontend هر صفحه چطور باید آن source جدید را مصرف کند.

## 16.2 ارتباط با Phase 10

Phase 10 بعداً باید decommission plan را کامل کند.  
Phase 9 کمک می‌کند که:
- dependencyهای UI به مسیرهای قدیمی قطع شوند
- حذف legacy pages واقعی‌تر و کم‌ریسک‌تر شود

---

# 17) روش تست معماری Phase 9

## 17.1 Review Checklist

برای پذیرش این Phase باید این سوال‌ها پاسخ روشن داشته باشند:

1. آیا همه بخش‌های UI که محاسبه مالی می‌کنند شناسایی شده‌اند؟
2. آیا contract جدید هر صفحه تعریف شده است؟
3. آیا plan حذف synthetic/virtual voucherها مشخص شده؟
4. آیا plan حذف formulaهای client-side مشخص شده؟
5. آیا filter/pagination contractهای جدید تعریف شده‌اند؟
6. آیا plan migration از bundle minified به source-managed layer روشن شده؟
7. آیا target UI = ERP panel در کل طرح حفظ شده؟
8. آیا visual parity rule روشن شده؟
9. آیا UI feature flag strategy تعریف شده؟
10. آیا ambiguityهای فاز ۹ صریح ثبت شده‌اند؟

## 17.2 سناریوهای تست پیشنهادی

- Documents render without client accounting aggregation
- Journal render from physical journal source
- GL render with running balance from backend
- TB render without local formula
- P&L render without local prefix-based calculation
- BS render without local statement build
- Dashboard cards render from official KPI payload
- legacy pages show `قدیمی` and stay read-only
- ERP panel visual parity verification

---

# 18) ارزیابی انجام Taskهای Phase 9 نسبت به Roadmap

## 18.1 Taskهای Phase 9 در Roadmap

طبق `ERP_REFACTOR_ROADMAP.md`، Phase 9 شامل این موارد بود:
- شناسایی همه بخش‌های UI که محاسبه مالی می‌کنند
- تعریف contractهای جدید UI برای صفحه‌های اصلی
- طراحی plan حذف synthetic/virtual voucher generation از frontend
- طراحی plan حذف client-side formulas
- تعیین تغییرات مورد نیاز در filters و pagination contracts
- تعیین migration plan برای bundle minified فعلی → source-managed UI layer

## 18.2 وضعیت این artefact

| Task | وضعیت |
|---|---|
| شناسایی UI surfaces با محاسبه مالی | ✅ انجام شد |
| تعریف contract صفحه‌های اصلی | ✅ انجام شد |
| plan حذف synthetic voucher generation | ✅ انجام شد |
| plan حذف client-side formulas | ✅ انجام شد |
| filter/pagination contract changes | ✅ انجام شد |
| migration plan به source-managed UI layer | ✅ انجام شد |
| حفظ target UI = ERP panel | ✅ انجام شد |
| ambiguity register | ✅ انجام شد |

## 18.3 Definition of Done Phase 9

Phase 9 زمانی Done تلقی می‌شود که:
1. frontend target contracts مشخص شده باشند ✅
2. هیچ report page در طراحی target نیازمند accounting logic client-side نباشد ✅
3. plan مهاجرت به source-managed runtime مشخص شده باشد ✅
4. visual parity rule ثبت شده باشد ✅
5. review ambiguityهای باز قبل از اجرا انجام شده باشد ⏳

### نتیجه
از منظر **مستندسازی معماری و برنامه‌ریزی refactor UI**، Phase 9 در این artefact **شروع و تدوین شده است**؛  
اما از منظر **اجرای واقعی** هنوز نیازمند تصمیم روی چند ambiguity اجرایی، ابزار build و سطح patch لازم در UI فعلی است.

---

# 19) Ambiguity Register فاز ۹

> این بخش باید قبل از اجرای واقعی UI Refactor یا قبل از فاز بعدی مرور شود.

## 19.1 source-managed UI layer دقیقاً با چه تکنولوژی/ابزار build ساخته شود؟

### توضیح ساده
باید تصمیم بگیریم frontend جدیدِ قابل نگه‌داری با چه روش فنی ساخته شود، ولی بدون اینکه دوباره یک مسیر مرده و ناقص مثل `ui-src/` ایجاد شود.

### وضعیت
**نیاز به تصمیم فنی قبل از اجرا**

---

## 19.2 آیا برای بعضی صفحه‌ها response adapter کافی است یا UI patch واقعی هم لازم می‌شود؟

### توضیح ساده
ممکن است بعضی صفحه‌های ERP فعلی هنوز به شکل قدیمی فکر کنند و فقط عوض کردن API کافی نباشد.

### وضعیت
**نیاز به تصمیم اجرایی**

---

## 19.3 export/print surfaceها در همان موج UI refactor هر صفحه مهاجرت کنند یا موج جدا داشته باشند؟

### توضیح ساده
مثلاً وقتی Journal UI عوض می‌شود، چاپ و خروجی آن هم همان لحظه عوض شود یا بعداً؟

### وضعیت
**نیاز به تصمیم**

---

## 19.4 statement pageها در اولین UI cutover summary-only باشند یا full-detail/tree view هم همان‌جا منتقل شود؟

### توضیح ساده
باید معلوم شود صورت سود و زیان و ترازنامه در شروع چقدر جزئیات نشان دهند.

### وضعیت
**نیاز به تصمیم**

---

## 19.5 dashboard KPIهای operational و accounting آیا باید در UI از هم جدا برچسب بخورند؟

### توضیح ساده
بعضی کارت‌ها ممکن است مالی رسمی باشند و بعضی فقط مدیریتی. شاید لازم باشد در UI این تفاوت واضح شود.

### وضعیت
**نیاز به تصمیم**

---

## 19.6 badge و read-only state صفحه‌های legacy فقط در UI باشد یا در response metadata هم منعکس شود؟

### توضیح ساده
برای شفافیت بیشتر شاید backend هم بگوید این مسیر قدیمی است.

### وضعیت
**نیاز به تصمیم**

---

## 19.7 آیا first wave of source-managed runtime باید هم‌زمان همه صفحه‌های ERP را پوشش دهد یا page-by-page پیش برود؟

### توضیح ساده
باید تصمیم بگیریم UI جدیدِ قابل نگه‌داری را یک‌جا بسازیم یا صفحه‌به‌صفحه.

### وضعیت
**نیاز به تصمیم اجرایی**

---

# 20) جمع‌بندی نهایی Phase 9

مهم‌ترین خروجی Phase 9 این است که از اینجا به بعد، ERP UI نباید خودش حسابداری را محاسبه کند.

### نتیجه‌های کلیدی
- surfaceهای UI که محاسبه مالی انجام می‌دادند شناسایی شدند
- contractهای جدید برای Documents / Journal / GL / Subsidiary / TB / P&L / BS / Dashboard تعریف شدند
- plan حذف synthetic vouchers در frontend مشخص شد
- plan حذف client-side formulas مشخص شد
- filter و pagination contractهای جدید طراحی شد
- مسیر migration از bundle minified فعلی به source-managed runtime طراحی شد
- target UI = ERP Accounting Panel بدون redesign حفظ شد

### اصل نهایی این فاز

```text
Keep the ERP UI.
Remove accounting intelligence from the browser.
Make frontend maintainable.
```

و به زبان ساده‌تر:

```text
ظاهر ERP را نگه می‌داریم،
حسابداری را از داخل مرورگر بیرون می‌کشیم،
و UI را قابل نگه‌داری می‌کنیم.
```

---

**پایان گزارش Phase 9**
